# RFCD: Robustness–Fairness Co-Optimized Detection of AI-Generated Text

**Protecting ESL Students from Bias and Paraphrase Attacks**

This repository contains a complete, reproducible research pipeline for the study
*"Robustness-Fairness Co-Optimized Detection of AI-Generated Text: Protecting ESL
Students from Bias and Paraphrase Attacks."* It is designed to support an SCIE Q1-level
research paper.

## The core research question

Prior work studies two problems in isolation:

1. **Fairness** — AI-text detectors falsely flag non-native (ESL) writing as
   machine-generated at high rates.
2. **Robustness** — paraphrasing lets AI text evade detectors.

Existing fairness fixes are *post-hoc* (applied after training) and have **never**
been tested under paraphrase attack. RFCD is the first detector trained to jointly
optimize **classification accuracy**, **group fairness (ESL vs native)**, and
**paraphrase robustness** *during training*. The evaluation shifts the question from
*"Is it fair?"* or *"Is it robust?"* to **"Does fairness survive attacks?"**

## What the model does

`RFCD` fuses two views of a text:

- A **transformer encoder** (RoBERTa / DeBERTa) that reads the raw text.
- A **stylometric branch** that reads hand-crafted writing-style features
  (lexical richness, sentence structure, punctuation, function-word usage, etc.).

Training uses a **three-part co-optimized objective**:

```
L = L_classification
  + lambda_fair  * L_fairness      (adversarial group-invariance: ESL vs native)
  + lambda_robust * L_robustness   (consistency between clean and paraphrased text)
```

A **gradient-reversal adversary** tries to predict the writer's group (ESL/native)
from the shared representation; reversing its gradient pushes the encoder toward a
group-invariant representation. A **paraphrase-consistency loss** forces the model to
produce the same prediction for a text and its paraphrase, building robustness *into*
the representation rather than patching it afterward.

## Real datasets (downloaded from the internet)

| Role | Dataset | Source | Use |
|------|---------|--------|-----|
| AI-generated text | HC3 (`Hello-SimpleAI/HC3`) | Hugging Face | `chatgpt_answers` -> label = AI |
| Human, native-style | HC3 (`Hello-SimpleAI/HC3`) | Hugging Face | `human_answers` -> label = Human, group = native |
| Human, ESL | English learner essays (`KevSun/Engessay_grading_ML`) | Hugging Face | learner essays -> label = Human, group = ESL |

All datasets are fetched at run time via the Hugging Face `datasets` library. See
`SOURCES.md` for full attribution.

## Project layout

```
III-SEM Project/
├── requirements.txt
├── README.md
├── SOURCES.md
├── configs/
│   └── default.yaml           # all hyper-parameters
├── src/rfcd/
│   ├── config.py              # config loading
│   ├── data/
│   │   ├── download.py        # fetch real datasets from HF
│   │   ├── build_dataset.py   # unify into label + group table, splits
│   │   └── stylometry.py      # stylometric feature extractor
│   ├── attacks/
│   │   └── paraphrase.py      # paraphrase-attack generation
│   ├── models/
│   │   ├── rfcd_model.py      # transformer + stylometry fusion + GRL adversary
│   │   └── layers.py          # gradient reversal etc.
│   ├── train/
│   │   └── trainer.py         # co-optimized training loop
│   ├── eval/
│   │   └── metrics.py         # accuracy/F1/AUC + fairness + fairness-under-attack
│   └── utils.py
├── scripts/
│   ├── 01_prepare_data.py
│   ├── 02_train.py
│   ├── 03_evaluate.py
│   └── run_all.py             # end-to-end
└── results/                   # metrics, tables, figures (generated)
```

## Quick start

```bash
pip install -r requirements.txt

# 1. Download + build the unified dataset (real data from the internet)
python scripts/01_prepare_data.py

# 2. Train the RFCD model (and baselines)
python scripts/02_train.py

# 3. Evaluate: accuracy, fairness, robustness, fairness-under-attack
python scripts/03_evaluate.py

# ...or run everything:
python scripts/run_all.py
```

For a fast smoke test on CPU without downloading large data, run any script with
`--smoke` (uses a small synthetic-labelled subset drawn from the real corpora).

## Outputs for the paper

`results/` contains:
- `metrics.json` — all headline numbers.
- `fairness_under_attack.csv` — FPR gap for ESL vs native, before and after paraphrase.
- Figures: FPR-by-group bar chart, fairness-gap-under-attack plot, ROC curves.

## License / ethics

Datasets are used under their respective licenses (see `SOURCES.md`). This is a
defensive fairness/robustness study; it is intended to reduce harm to ESL writers,
not to help evade detection.
