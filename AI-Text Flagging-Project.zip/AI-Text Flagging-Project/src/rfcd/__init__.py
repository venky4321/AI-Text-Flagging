"""RFCD: Robustness-Fairness Co-Optimized Detector of AI-generated text."""

__version__ = "0.1.0"
