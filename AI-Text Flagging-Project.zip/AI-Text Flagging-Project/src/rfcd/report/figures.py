"""Paper figures: FPR-by-group, fairness-under-attack, and ROC curves.

Uses a non-interactive matplotlib backend so it runs headless.
"""
from __future__ import annotations

import os
from typing import Dict

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def _roc_points(scores, labels, n=100):
    scores = np.asarray(scores, dtype=float)
    labels = np.asarray(labels)
    thrs = np.linspace(0, 1, n)
    tpr, fpr = [], []
    P = max(1, int((labels == 1).sum()))
    N = max(1, int((labels == 0).sum()))
    for t in thrs:
        pred = scores >= t
        tpr.append(((pred == 1) & (labels == 1)).sum() / P)
        fpr.append(((pred == 1) & (labels == 0)).sum() / N)
    order = np.argsort(fpr)
    return np.array(fpr)[order], np.array(tpr)[order]


def fig_fpr_by_group(all_results: Dict, path: str):
    variants = list(all_results.keys())
    native = [all_results[v]["clean"].get("fpr_native", np.nan) for v in variants]
    esl = [all_results[v]["clean"].get("fpr_esl", np.nan) for v in variants]

    x = np.arange(len(variants))
    w = 0.38
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x - w / 2, native, w, label="Native (FPR)", color="#4C72B0")
    ax.bar(x + w / 2, esl, w, label="ESL (FPR)", color="#C44E52")
    ax.set_xticks(x)
    ax.set_xticklabels(variants, rotation=15)
    ax.set_ylabel("False Positive Rate (human flagged as AI)")
    ax.set_title("Human false-positive rate by group (clean test set)")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_fairness_under_attack(all_results: Dict, path: str):
    variants = list(all_results.keys())
    gap_clean = [all_results[v].get("clean", {}).get("fpr_gap", np.nan)
                 for v in variants]
    gap_att = [all_results[v].get("attacked", {}).get("fpr_gap", np.nan)
               for v in variants]

    x = np.arange(len(variants))
    w = 0.38
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x - w / 2, gap_clean, w, label="FPR gap (clean)", color="#55A868")
    ax.bar(x + w / 2, gap_att, w, label="FPR gap (paraphrased)", color="#CC8963")
    ax.axhline(0, color="k", linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(variants, rotation=15)
    ax.set_ylabel("ESL - Native FPR gap")
    ax.set_title("Does fairness survive paraphrase attacks?\n(lower gap = fairer; "
                 "compare clean vs attacked)")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_roc(all_results: Dict, labels, path: str):
    fig, ax = plt.subplots(figsize=(6, 6))
    for v, res in all_results.items():
        scores = res.get("_scores_clean")
        if scores is None:
            continue
        fpr, tpr = _roc_points(scores, labels)
        auc = res.get("clean", {}).get("auc", float("nan"))
        ax.plot(fpr, tpr, label=f"{v} (AUC={auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", alpha=0.4)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC curves (clean test set)")
    ax.legend(loc="lower right", fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def make_all_figures(all_results: Dict, labels, out_dir: str, suffix: str = ""):
    os.makedirs(out_dir, exist_ok=True)
    fig_fpr_by_group(all_results, os.path.join(out_dir, f"fpr_by_group{suffix}.png"))
    fig_fairness_under_attack(
        all_results, os.path.join(out_dir, f"fairness_under_attack{suffix}.png")
    )
    fig_roc(all_results, labels, os.path.join(out_dir, f"roc{suffix}.png"))
