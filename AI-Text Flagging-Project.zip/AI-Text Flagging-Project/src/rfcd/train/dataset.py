"""Torch Dataset + collator for RFCD.

Each item carries the raw text (so the collator can tokenize and, for training,
produce an on-the-fly paraphrased view), a class label (human/AI), a fairness
group id (native/ESL), and precomputed standardized stylometric features.
"""
from __future__ import annotations

from typing import List, Optional

import numpy as np
import torch
from torch.utils.data import Dataset

from ..data.stylometry import extract_features
from ..attacks.paraphrase import Paraphraser


class RFCDDataset(Dataset):
    def __init__(self, df, style_stats, paraphraser: Optional[Paraphraser] = None,
                 paraphrase_prob: float = 0.0):
        self.texts: List[str] = df["text"].tolist()
        self.labels = df["label"].astype(int).tolist()
        self.group_ids = df["group_id"].astype(int).tolist()
        self.groups = df["group"].tolist()
        self.style_stats = style_stats
        self.paraphraser = paraphraser
        self.paraphrase_prob = paraphrase_prob

    def __len__(self):
        return len(self.texts)

    def _style_vec(self, text: str) -> np.ndarray:
        raw = extract_features(text).reshape(1, -1)
        return self.style_stats.transform(raw)[0]

    def __getitem__(self, idx):
        text = self.texts[idx]
        item = {
            "text": text,
            "label": self.labels[idx],
            "group_id": self.group_ids[idx],
            "group": self.groups[idx],
            "style": self._style_vec(text),
        }
        # optional paraphrased view for robustness/consistency training
        if self.paraphraser is not None and self.paraphrase_prob > 0:
            para = self.paraphraser.paraphrase(text)
            item["text_para"] = para
            item["style_para"] = self._style_vec(para)
        return item


class Collator:
    """Tokenizes text (and paraphrase view) into model-ready tensors."""

    def __init__(self, tokenizer, max_length: int, with_paraphrase: bool = False):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.with_paraphrase = with_paraphrase

    def _tok(self, texts):
        return self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        )

    def __call__(self, batch):
        texts = [b["text"] for b in batch]
        enc = self._tok(texts)
        out = {
            "input_ids": enc["input_ids"],
            "attention_mask": enc["attention_mask"],
            "style_features": torch.tensor(
                np.stack([b["style"] for b in batch]), dtype=torch.float32
            ),
            "labels": torch.tensor([b["label"] for b in batch], dtype=torch.long),
            "group_ids": torch.tensor([b["group_id"] for b in batch], dtype=torch.long),
            "groups": [b["group"] for b in batch],
        }
        if self.with_paraphrase and "text_para" in batch[0]:
            enc_p = self._tok([b["text_para"] for b in batch])
            out["input_ids_para"] = enc_p["input_ids"]
            out["attention_mask_para"] = enc_p["attention_mask"]
            out["style_features_para"] = torch.tensor(
                np.stack([b["style_para"] for b in batch]), dtype=torch.float32
            )
        return out
