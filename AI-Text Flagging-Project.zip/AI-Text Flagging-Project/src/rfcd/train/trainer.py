"""Co-optimized training loop for RFCD.

Combined objective (per batch):

    L = L_cls
      + lambda_fair   * L_fair      (adversarial group-invariance via GRL)
      + lambda_robust * L_robust    (KL consistency between clean and paraphrased)

Ablation flags let the SAME code train the baselines used in the paper:

    use_fairness=False, use_robustness=False  -> "Vanilla" detector (backbone+style)
    use_fairness=True,  use_robustness=False  -> "Fairness-only" (adversarial debias)
    use_fairness=False, use_robustness=True   -> "Robustness-only" (adv. paraphrase)
    use_fairness=True,  use_robustness=True   -> "RFCD" (full co-optimization)

The GRL strength is ramped up over training (standard DANN schedule) for stability.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from ..utils import ensure_dir
from .dataset import RFCDDataset, Collator


@dataclass
class VariantConfig:
    name: str
    use_fairness: bool
    use_robustness: bool


VARIANTS = {
    "vanilla": VariantConfig("vanilla", False, False),
    "fairness_only": VariantConfig("fairness_only", True, False),
    "robustness_only": VariantConfig("robustness_only", False, True),
    "rfcd": VariantConfig("rfcd", True, True),
}


def _grl_schedule(step: int, total: int, max_lambda: float) -> float:
    """DANN-style ramp: 0 -> max_lambda following 2/(1+exp(-10p)) - 1."""
    if total <= 0:
        return max_lambda
    p = min(1.0, step / total)
    return float(max_lambda * (2.0 / (1.0 + np.exp(-10 * p)) - 1.0))


class RFCDTrainer:
    def __init__(self, cfg, model, tokenizer, variant: VariantConfig, device,
                 paraphraser=None):
        self.cfg = cfg
        self.model = model.to(device)
        self.tokenizer = tokenizer
        self.variant = variant
        self.device = device
        self.paraphraser = paraphraser

        # separate LR for the (small) stylometry + heads vs the transformer
        enc_params, other_params = [], []
        for name, p in model.named_parameters():
            if name.startswith("encoder."):
                enc_params.append(p)
            else:
                other_params.append(p)
        self.optimizer = torch.optim.AdamW(
            [
                {"params": enc_params, "lr": cfg.train.lr},
                {"params": other_params, "lr": cfg.train.stylometry_lr},
            ],
            weight_decay=cfg.train.weight_decay,
        )
        self.cls_loss = nn.CrossEntropyLoss()
        self.grp_loss = nn.CrossEntropyLoss()

    def _make_loader(self, df, train: bool):
        want_para = train and (self.variant.use_robustness)
        ds = RFCDDataset(
            df,
            style_stats=self.style_stats,
            paraphraser=self.paraphraser if want_para else None,
            paraphrase_prob=self.cfg.train.paraphrase_prob if want_para else 0.0,
        )
        collator = Collator(self.tokenizer, self.cfg.model.max_length,
                            with_paraphrase=want_para)
        return DataLoader(
            ds,
            batch_size=self.cfg.train.batch_size,
            shuffle=train,
            collate_fn=collator,
            num_workers=0,
        )

    def fit(self, train_df, val_df, style_stats):
        self.style_stats = style_stats
        loader = self._make_loader(train_df, train=True)
        total_steps = len(loader) * self.cfg.train.epochs

        scheduler = None
        try:
            from transformers import get_linear_schedule_with_warmup

            warmup = int(self.cfg.train.warmup_ratio * total_steps)
            scheduler = get_linear_schedule_with_warmup(
                self.optimizer, warmup, total_steps
            )
        except Exception:
            pass

        step = 0
        history = []
        for epoch in range(self.cfg.train.epochs):
            self.model.train()
            running = {"loss": 0.0, "cls": 0.0, "fair": 0.0, "robust": 0.0}
            for batch in loader:
                step += 1
                grl_lambda = (
                    _grl_schedule(step, total_steps, self.cfg.train.grl_lambda)
                    if self.variant.use_fairness else 0.0
                )
                logs = self._train_step(batch, grl_lambda)
                for k in running:
                    running[k] += logs[k]
                if step % self.cfg.logging.log_every == 0:
                    denom = self.cfg.logging.log_every
                    print(
                        f"[{self.variant.name}] epoch {epoch+1} step {step} "
                        f"loss={running['loss']/denom:.4f} "
                        f"cls={running['cls']/denom:.4f} "
                        f"fair={running['fair']/denom:.4f} "
                        f"robust={running['robust']/denom:.4f} "
                        f"grl={grl_lambda:.3f}"
                    )
                    running = {k: 0.0 for k in running}
                if scheduler is not None:
                    scheduler.step()

            val_acc = self._quick_eval(val_df)
            print(f"[{self.variant.name}] epoch {epoch+1} val_acc={val_acc:.4f}")
            history.append({"epoch": epoch + 1, "val_acc": val_acc})
        return history

    def _train_step(self, batch, grl_lambda) -> Dict[str, float]:
        self.optimizer.zero_grad()
        input_ids = batch["input_ids"].to(self.device)
        attn = batch["attention_mask"].to(self.device)
        style = batch["style_features"].to(self.device)
        labels = batch["labels"].to(self.device)
        group_ids = batch["group_ids"].to(self.device)

        out = self.model(input_ids, attn, style, grl_lambda=grl_lambda)
        loss_cls = self.cls_loss(out.logits, labels)
        loss = loss_cls
        loss_fair = torch.tensor(0.0, device=self.device)
        loss_robust = torch.tensor(0.0, device=self.device)

        # -- Fairness: adversary tries to predict group; GRL already reversed grad.
        # Only human samples carry a meaningful native/ESL group; mask AI out.
        if self.variant.use_fairness:
            human_mask = labels == 0
            if human_mask.any():
                loss_fair = self.grp_loss(
                    out.group_logits[human_mask], group_ids[human_mask]
                )
                loss = loss + self.cfg.train.lambda_fair * loss_fair

        # -- Robustness: prediction consistency between clean and paraphrased view.
        if self.variant.use_robustness and "input_ids_para" in batch:
            ids_p = batch["input_ids_para"].to(self.device)
            attn_p = batch["attention_mask_para"].to(self.device)
            style_p = batch["style_features_para"].to(self.device)
            out_p = self.model(ids_p, attn_p, style_p, grl_lambda=grl_lambda)
            # symmetric KL between clean and paraphrased class distributions
            p = F.log_softmax(out.logits, dim=-1)
            q = F.log_softmax(out_p.logits, dim=-1)
            loss_robust = 0.5 * (
                F.kl_div(p, q.exp(), reduction="batchmean")
                + F.kl_div(q, p.exp(), reduction="batchmean")
            )
            # also classify the paraphrased view correctly
            loss_robust = loss_robust + self.cls_loss(out_p.logits, labels)
            loss = loss + self.cfg.train.lambda_robust * loss_robust

        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.train.grad_clip)
        self.optimizer.step()
        return {
            "loss": float(loss.item()),
            "cls": float(loss_cls.item()),
            "fair": float(loss_fair.item()),
            "robust": float(loss_robust.item()),
        }

    @torch.no_grad()
    def _quick_eval(self, df) -> float:
        self.model.eval()
        loader = self._make_loader(df, train=False)
        correct, total = 0, 0
        for batch in loader:
            input_ids = batch["input_ids"].to(self.device)
            attn = batch["attention_mask"].to(self.device)
            style = batch["style_features"].to(self.device)
            labels = batch["labels"].to(self.device)
            out = self.model(input_ids, attn, style, grl_lambda=0.0)
            pred = out.logits.argmax(dim=-1)
            correct += int((pred == labels).sum().item())
            total += labels.numel()
        self.model.train()
        return correct / max(1, total)

    def save(self, path: str):
        ensure_dir(os.path.dirname(path))
        torch.save(
            {
                "model_state": self.model.state_dict(),
                "variant": self.variant.name,
                "style_stats": self.style_stats.to_dict(),
                "config": dict(self.cfg),
            },
            path,
        )
        print(f"[train] Saved checkpoint to {path}")
