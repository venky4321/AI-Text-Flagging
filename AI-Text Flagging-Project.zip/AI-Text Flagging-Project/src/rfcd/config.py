"""Configuration loading utilities."""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict

import yaml


class Config(dict):
    """Dict with attribute access and nested-safe .get."""

    def __getattr__(self, item):
        try:
            value = self[item]
        except KeyError as exc:
            raise AttributeError(item) from exc
        if isinstance(value, dict) and not isinstance(value, Config):
            value = Config(value)
            self[item] = value
        return value

    def __setattr__(self, key, value):
        self[key] = value


def load_config(path: str = None) -> Config:
    """Load YAML config, defaulting to configs/default.yaml at repo root."""
    if path is None:
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.abspath(os.path.join(here, "..", ".."))
        path = os.path.join(root, "configs", "default.yaml")
    with open(path, "r", encoding="utf-8") as fh:
        raw: Dict[str, Any] = yaml.safe_load(fh)
    return Config(raw)


def repo_root() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.abspath(os.path.join(here, "..", ".."))


def _deep_update(base: dict, override: dict) -> None:
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_update(base[k], v)
        else:
            base[k] = v


def apply_smoke(cfg: Config) -> Config:
    """Merge the `smoke` override block into the top-level config, in place."""
    smoke = cfg.get("smoke")
    if smoke:
        _deep_update(cfg, dict(smoke))
    return cfg
