"""Paraphrase-attack generation.

Paraphrasing is the standard evasion attack against AI-text detectors: reword the
machine text so surface statistics change while meaning is preserved. We implement
several lightweight, deterministic paraphrase transforms that require no GPU and no
external service, so the whole pipeline is reproducible:

    - synonym          : replace a fraction of content words with WordNet synonyms
                         (falls back to a built-in synonym table if WordNet is absent)
    - sentence_reorder : shuffle sentence order (meaning-preserving at doc level)
    - backtranslation_sim : simulate MT round-trip artifacts (light reordering +
                         function-word / contraction rewrites)

`Paraphraser` composes these. It is used two ways:
    1. During training: adversarially paraphrase part of each batch so the model
       learns a paraphrase-consistent representation (robustness term).
    2. During evaluation: paraphrase the whole test set to measure whether accuracy
       and, crucially, fairness survive the attack.
"""
from __future__ import annotations

import random
import re
from typing import Dict, List, Optional

_WORD_RE = re.compile(r"[A-Za-z]+|[^A-Za-z\s]|\s+")
_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")

# Minimal fallback synonym table (used if WordNet is unavailable).
_FALLBACK_SYNONYMS: Dict[str, List[str]] = {
    "important": ["significant", "crucial", "vital", "key"],
    "big": ["large", "sizable", "substantial"],
    "small": ["tiny", "little", "modest"],
    "good": ["fine", "solid", "strong"],
    "bad": ["poor", "weak", "negative"],
    "make": ["create", "produce", "generate"],
    "use": ["employ", "utilize", "apply"],
    "help": ["assist", "aid", "support"],
    "show": ["demonstrate", "reveal", "indicate"],
    "many": ["numerous", "several", "various"],
    "people": ["individuals", "persons", "folks"],
    "problem": ["issue", "challenge", "difficulty"],
    "different": ["distinct", "varied", "diverse"],
    "increase": ["raise", "boost", "grow"],
    "reduce": ["lower", "decrease", "cut"],
    "think": ["believe", "consider", "reckon"],
    "however": ["nevertheless", "nonetheless", "yet"],
    "because": ["since", "as", "given that"],
    "very": ["highly", "extremely", "quite"],
    "result": ["outcome", "consequence", "effect"],
}

_CONTRACTIONS = {
    "do not": "don't", "does not": "doesn't", "did not": "didn't",
    "is not": "isn't", "are not": "aren't", "was not": "wasn't",
    "cannot": "can't", "will not": "won't", "it is": "it's",
    "they are": "they're", "we are": "we're", "you are": "you're",
    "that is": "that's", "there is": "there's",
}
_EXPANSIONS = {v: k for k, v in _CONTRACTIONS.items()}

_STOPWORDS = {
    "the", "a", "an", "of", "to", "in", "is", "was", "and", "or", "for", "on",
    "at", "by", "with", "as", "it", "this", "that", "be", "are", "were", "has",
    "have", "had", "not", "but", "from", "they", "we", "you", "i", "he", "she",
}


class _WordNet:
    """Lazy WordNet wrapper with graceful degradation."""

    def __init__(self):
        self._wn = None
        self._ok = None

    def available(self) -> bool:
        if self._ok is not None:
            return self._ok
        try:
            import nltk
            from nltk.corpus import wordnet as wn

            try:
                wn.synsets("test")
            except LookupError:
                nltk.download("wordnet", quiet=True)
                nltk.download("omw-1.4", quiet=True)
            self._wn = wn
            _ = wn.synsets("test")
            self._ok = True
        except Exception:
            self._ok = False
        return self._ok

    def synonyms(self, word: str) -> List[str]:
        if not self.available():
            return _FALLBACK_SYNONYMS.get(word.lower(), [])
        out = []
        for syn in self._wn.synsets(word):
            for lemma in syn.lemmas():
                name = lemma.name().replace("_", " ")
                if name.lower() != word.lower() and " " not in name and name.isalpha():
                    out.append(name)
        # de-dup, keep order
        seen, uniq = set(), []
        for w in out:
            if w.lower() not in seen:
                seen.add(w.lower())
                uniq.append(w)
        return uniq[:5] or _FALLBACK_SYNONYMS.get(word.lower(), [])


_WN = _WordNet()


def _match_case(src: str, repl: str) -> str:
    if src.isupper():
        return repl.upper()
    if src[:1].isupper():
        return repl[:1].upper() + repl[1:]
    return repl


def synonym_substitute(text: str, rate: float, rng: random.Random) -> str:
    """Replace ~rate of content words with synonyms."""
    tokens = _WORD_RE.findall(text)
    out = []
    for tok in tokens:
        if tok.isalpha() and len(tok) > 3 and tok.lower() not in _STOPWORDS:
            if rng.random() < rate:
                syns = _WN.synonyms(tok)
                if syns:
                    out.append(_match_case(tok, rng.choice(syns)))
                    continue
        out.append(tok)
    return "".join(out)


def sentence_reorder(text: str, rng: random.Random) -> str:
    sents = [s for s in _SENT_SPLIT.split(text.strip()) if s]
    if len(sents) < 3:
        return text
    # local shuffle: swap adjacent-ish sentences to preserve some coherence
    idx = list(range(len(sents)))
    for i in range(0, len(idx) - 1, 2):
        if rng.random() < 0.5:
            idx[i], idx[i + 1] = idx[i + 1], idx[i]
    return " ".join(sents[i] for i in idx)


def backtranslation_sim(text: str, rng: random.Random) -> str:
    """Simulate MT round-trip artifacts: contraction flips + minor rephrasing."""
    out = text
    # randomly expand or contract
    table = _EXPANSIONS if rng.random() < 0.5 else _CONTRACTIONS
    for src, tgt in table.items():
        if src in out and rng.random() < 0.5:
            out = out.replace(src, tgt)
            out = out.replace(src.capitalize(), tgt.capitalize())
    # light synonym pass to mimic lexical drift of MT
    out = synonym_substitute(out, rate=0.15, rng=rng)
    return out


class Paraphraser:
    """Compose paraphrase transforms into a single attack."""

    def __init__(self, methods: Optional[List[str]] = None, synonym_rate: float = 0.25,
                 seed: int = 42):
        self.methods = methods or ["synonym", "backtranslation_sim", "sentence_reorder"]
        self.synonym_rate = synonym_rate
        self.rng = random.Random(seed)

    def paraphrase(self, text: str) -> str:
        out = text
        if "synonym" in self.methods:
            out = synonym_substitute(out, self.synonym_rate, self.rng)
        if "backtranslation_sim" in self.methods:
            out = backtranslation_sim(out, self.rng)
        if "sentence_reorder" in self.methods:
            out = sentence_reorder(out, self.rng)
        return out

    def paraphrase_batch(self, texts: List[str]) -> List[str]:
        return [self.paraphrase(t) for t in texts]
