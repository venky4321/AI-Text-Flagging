"""RFCD model: transformer + stylometry fusion with a fairness adversary.

Architecture
------------
                 text ---> [Transformer encoder] --> h_text (D_t)
    stylometry vector ---> [MLP branch]          --> h_style (D_s)
                                    |
                       concat -> [fusion MLP] -> z  (shared representation)
                                    |
              +---------------------+----------------------+
              |                                            |
      [classifier head]                        [GRL -> group adversary]
      human / AI logits                        native / ESL logits

Losses (combined in the trainer):
    - classification: cross-entropy on human/AI
    - fairness:       adversary tries to predict group from z; gradient reversal
                      pushes z to be group-invariant
    - robustness:     consistency between z(clean) and z(paraphrased) (handled by
                      trainer, which calls the model twice)

Setting `backbone=None` (or when transformers/torch are unavailable at import time)
is handled by the trainer choosing an appropriate path; this module assumes torch +
transformers are installed at runtime.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn

from .layers import gradient_reversal


@dataclass
class RFCDOutput:
    logits: torch.Tensor            # [B, num_classes] class logits (human/AI)
    group_logits: torch.Tensor      # [B, num_groups] adversary logits
    representation: torch.Tensor    # [B, fusion_hidden] shared rep z


class StylometryBranch(nn.Module):
    def __init__(self, n_features: int, hidden: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_features, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden),
            nn.GELU(),
        )

    def forward(self, x):
        return self.net(x)


class RFCDModel(nn.Module):
    def __init__(
        self,
        backbone: str = "roberta-base",
        n_style_features: int = 24,
        stylometry_hidden: int = 64,
        fusion_hidden: int = 256,
        num_classes: int = 2,
        num_groups: int = 2,
        dropout: float = 0.2,
    ):
        super().__init__()
        from transformers import AutoModel, AutoConfig

        self.encoder_config = AutoConfig.from_pretrained(backbone)
        self.encoder = AutoModel.from_pretrained(backbone)
        d_text = self.encoder_config.hidden_size

        self.style_branch = StylometryBranch(n_style_features, stylometry_hidden, dropout)

        self.fusion = nn.Sequential(
            nn.Linear(d_text + stylometry_hidden, fusion_hidden),
            nn.LayerNorm(fusion_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.classifier = nn.Sequential(
            nn.Linear(fusion_hidden, fusion_hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(fusion_hidden // 2, num_classes),
        )

        # Fairness adversary (fed through gradient reversal in forward()).
        self.group_adversary = nn.Sequential(
            nn.Linear(fusion_hidden, fusion_hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(fusion_hidden // 2, num_groups),
        )

    def _pool(self, encoder_out, attention_mask):
        last_hidden = encoder_out.last_hidden_state  # [B, T, D]
        mask = attention_mask.unsqueeze(-1).type_as(last_hidden)
        summed = (last_hidden * mask).sum(dim=1)
        counts = mask.sum(dim=1).clamp(min=1e-6)
        return summed / counts  # mean pooling over valid tokens

    def encode(self, input_ids, attention_mask, style_features):
        enc = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        h_text = self._pool(enc, attention_mask)
        h_style = self.style_branch(style_features)
        fused = torch.cat([h_text, h_style], dim=-1)
        z = self.fusion(fused)
        return z

    def forward(
        self,
        input_ids,
        attention_mask,
        style_features,
        grl_lambda: float = 1.0,
    ) -> RFCDOutput:
        z = self.encode(input_ids, attention_mask, style_features)
        logits = self.classifier(z)
        z_rev = gradient_reversal(z, grl_lambda)
        group_logits = self.group_adversary(z_rev)
        return RFCDOutput(logits=logits, group_logits=group_logits, representation=z)


def build_model(cfg, n_style_features: int) -> "RFCDModel":
    m = cfg.model
    return RFCDModel(
        backbone=m.backbone,
        n_style_features=n_style_features,
        stylometry_hidden=m.stylometry_hidden,
        fusion_hidden=m.fusion_hidden,
        num_classes=m.num_classes,
        num_groups=m.num_groups,
        dropout=m.dropout,
    )
