"""Custom layers: gradient reversal for adversarial fairness."""
from __future__ import annotations

import torch
from torch.autograd import Function


class _GradientReversalFn(Function):
    @staticmethod
    def forward(ctx, x, lambda_):
        ctx.lambda_ = lambda_
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.lambda_, None


def gradient_reversal(x: torch.Tensor, lambda_: float = 1.0) -> torch.Tensor:
    """Identity in forward pass; negates and scales gradient in backward pass.

    Placing this before the group-adversary makes the shared encoder learn a
    representation from which the writer's group (native/ESL) cannot be predicted
    -> group-invariant features -> fairness.
    """
    return _GradientReversalFn.apply(x, lambda_)


class GradientReversal(torch.nn.Module):
    def __init__(self, lambda_: float = 1.0):
        super().__init__()
        self.lambda_ = lambda_

    def forward(self, x):
        return gradient_reversal(x, self.lambda_)
