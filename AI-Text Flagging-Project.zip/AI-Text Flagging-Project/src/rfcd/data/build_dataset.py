"""Build the unified RFCD dataset from real sources and split it.

Produces a single DataFrame with columns:
    text   : str
    label  : int  (0 human, 1 AI)
    group  : str  ("native", "esl", "ai")
    group_id : int (0 native, 1 esl)  -- fairness group for HUMAN samples
    domain : str
    split  : str  ("train" | "val" | "test")

Design notes
------------
* The fairness comparison is native-human vs ESL-human. AI text is assigned
  group_id via a round-robin so the adversary sees AI in both groups and does not
  simply learn "AI == one group".
* Splits are stratified on (label, group) so every split contains AI, native and
  ESL text in comparable proportions.
"""
from __future__ import annotations

import os
from typing import Tuple

import numpy as np
import pandas as pd

from .download import load_hc3, load_esl


def _filter_length(df: pd.DataFrame, min_words: int, max_words: int) -> pd.DataFrame:
    n = df["text"].str.split().apply(len)
    keep = (n >= min_words)
    df = df.loc[keep].copy()
    # truncate long texts to max_words (word-level) for balance
    def trunc(t):
        parts = t.split()
        return " ".join(parts[:max_words]) if len(parts) > max_words else t
    df["text"] = df["text"].apply(trunc)
    return df.reset_index(drop=True)


def _cap(df: pd.DataFrame, n: int, seed: int) -> pd.DataFrame:
    if n and len(df) > n:
        return df.sample(n=n, random_state=seed).reset_index(drop=True)
    return df


def build_unified(cfg, smoke: bool = False) -> pd.DataFrame:
    """Download, unify and balance the three sources into one table."""
    seed = cfg.seed
    d = cfg.data

    max_ai = 300 if smoke else d.max_ai
    max_native = 300 if smoke else d.max_human_native
    max_esl = 250 if smoke else d.max_human_esl

    print("[data] Loading HC3 (AI + native human) ...")
    hc3 = load_hc3(d.hc3_dataset, d.hc3_config, seed=seed)
    hc3 = _filter_length(hc3, d.min_words, d.max_words)

    ai = _cap(hc3[hc3.label == 1].copy(), max_ai, seed)
    native = _cap(hc3[hc3.label == 0].copy(), max_native, seed)

    print("[data] Loading ESL learner essays ...")
    esl = load_esl(d.esl_dataset, list(d.esl_fallbacks), seed=seed)
    esl = _filter_length(esl, d.min_words, d.max_words)
    esl = _cap(esl, max_esl, seed)

    df = pd.concat([ai, native, esl], ignore_index=True)
    df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)

    # fairness group id: humans -> native(0)/esl(1); AI round-robined across groups
    def group_id(row, counter=[0]):  # noqa: B006 - intentional shared counter
        if row["group"] == "native":
            return 0
        if row["group"] == "esl":
            return 1
        counter[0] += 1
        return counter[0] % 2

    df["group_id"] = df.apply(group_id, axis=1)

    print(
        f"[data] Unified: {len(df)} rows | AI={int((df.label==1).sum())} "
        f"native={(df.group=='native').sum()} esl={(df.group=='esl').sum()}"
    )
    return df


def stratified_split(df: pd.DataFrame, val_size: float, test_size: float,
                     seed: int) -> pd.DataFrame:
    """Assign a 'split' column, stratified on (label, group)."""
    rng = np.random.default_rng(seed)
    df = df.copy()
    df["split"] = "train"
    strata_key = df["label"].astype(str) + "_" + df["group"].astype(str)
    for _, idx in df.groupby(strata_key).groups.items():
        idx = np.array(list(idx))
        rng.shuffle(idx)
        n = len(idx)
        n_test = int(round(n * test_size))
        n_val = int(round(n * val_size))
        test_idx = idx[:n_test]
        val_idx = idx[n_test:n_test + n_val]
        df.loc[test_idx, "split"] = "test"
        df.loc[val_idx, "split"] = "val"
    return df


def build_and_save(cfg, smoke: bool = False) -> Tuple[pd.DataFrame, str]:
    df = build_unified(cfg, smoke=smoke)
    df = stratified_split(df, cfg.data.val_size, cfg.data.test_size, cfg.seed)

    out_dir = cfg.paths.processed_dir
    os.makedirs(out_dir, exist_ok=True)
    suffix = "_smoke" if smoke else ""
    path = os.path.join(out_dir, f"rfcd_dataset{suffix}.parquet")
    try:
        df.to_parquet(path, index=False)
    except Exception:  # pyarrow may be missing; fall back to csv
        path = os.path.join(out_dir, f"rfcd_dataset{suffix}.csv")
        df.to_csv(path, index=False)
    print(f"[data] Saved dataset to {path}")

    for sp in ("train", "val", "test"):
        sub = df[df.split == sp]
        print(
            f"[data]   {sp:5s}: {len(sub):5d} "
            f"(AI={int((sub.label==1).sum())}, "
            f"native={(sub.group=='native').sum()}, esl={(sub.group=='esl').sum()})"
        )
    return df, path


def load_saved(cfg, smoke: bool = False) -> pd.DataFrame:
    out_dir = cfg.paths.processed_dir
    suffix = "_smoke" if smoke else ""
    pq = os.path.join(out_dir, f"rfcd_dataset{suffix}.parquet")
    csv = os.path.join(out_dir, f"rfcd_dataset{suffix}.csv")
    if os.path.exists(pq):
        return pd.read_parquet(pq)
    if os.path.exists(csv):
        return pd.read_csv(csv)
    raise FileNotFoundError(
        f"No processed dataset found. Run scripts/01_prepare_data.py first "
        f"(looked for {pq} / {csv})."
    )
