"""Stylometric feature extraction.

Hand-crafted writing-style features that complement the transformer's semantic
view. These capture surface signals that differ between AI and human text, and
between native and ESL writing (lexical richness, sentence structure, punctuation,
function-word usage, readability).

The extractor is deterministic and dependency-light (pure Python + numpy), so it
runs anywhere. Output is a fixed-length float vector; FEATURE_NAMES documents it.
"""
from __future__ import annotations

import math
import re
from typing import List

import numpy as np

# Common English function words (closed-class). Frequency of these is a classic
# stylometric signal and tends to differ for non-native writers.
_FUNCTION_WORDS = [
    "the", "of", "and", "a", "to", "in", "is", "was", "he", "for", "it", "with",
    "as", "his", "on", "be", "at", "by", "i", "this", "had", "not", "are", "but",
    "from", "or", "have", "an", "they", "which", "one", "you", "were", "her",
    "all", "she", "there", "would", "their", "we", "him", "been", "has", "when",
    "who", "will", "more", "no", "if", "out", "so", "said", "what", "up", "its",
    "about", "into", "than", "them", "can", "only", "other", "new", "some",
]

_WORD_RE = re.compile(r"[A-Za-z']+")
_SENT_RE = re.compile(r"[.!?]+")

FEATURE_NAMES: List[str] = [
    "n_chars",
    "n_words",
    "n_sentences",
    "avg_word_len",
    "std_word_len",
    "avg_sentence_len",
    "std_sentence_len",
    "type_token_ratio",          # lexical diversity
    "hapax_ratio",               # share of words used exactly once
    "long_word_ratio",           # words >= 7 chars
    "short_word_ratio",          # words <= 3 chars
    "punct_ratio",
    "comma_ratio",
    "period_ratio",
    "question_ratio",
    "exclaim_ratio",
    "uppercase_ratio",
    "digit_ratio",
    "stopword_ratio",
    "function_word_ratio",
    "flesch_reading_ease",
    "avg_syllables_per_word",
    "unique_bigram_ratio",
    "repeated_word_ratio",
]

N_FEATURES = len(FEATURE_NAMES)


def _count_syllables(word: str) -> int:
    word = word.lower()
    vowels = "aeiouy"
    count, prev_vowel = 0, False
    for ch in word:
        is_vowel = ch in vowels
        if is_vowel and not prev_vowel:
            count += 1
        prev_vowel = is_vowel
    if word.endswith("e") and count > 1:
        count -= 1
    return max(1, count)


def extract_features(text: str) -> np.ndarray:
    """Return a fixed-length float32 feature vector for a single text."""
    text = text or ""
    n_chars = len(text)
    words = _WORD_RE.findall(text)
    n_words = len(words)
    sentences = [s for s in _SENT_RE.split(text) if s.strip()]
    n_sentences = max(1, len(sentences))

    if n_words == 0:
        return np.zeros(N_FEATURES, dtype=np.float32)

    word_lens = np.array([len(w) for w in words], dtype=np.float32)
    lower_words = [w.lower() for w in words]

    # sentence lengths in words
    sent_lens = []
    for s in sentences:
        sw = _WORD_RE.findall(s)
        if sw:
            sent_lens.append(len(sw))
    sent_lens = np.array(sent_lens or [n_words], dtype=np.float32)

    # lexical
    unique = set(lower_words)
    type_token_ratio = len(unique) / n_words
    counts = {}
    for w in lower_words:
        counts[w] = counts.get(w, 0) + 1
    hapax = sum(1 for c in counts.values() if c == 1)
    hapax_ratio = hapax / n_words
    repeated = sum(c for c in counts.values() if c > 1)
    repeated_word_ratio = repeated / n_words

    long_word_ratio = float(np.mean(word_lens >= 7))
    short_word_ratio = float(np.mean(word_lens <= 3))

    # punctuation
    n_punct = sum(1 for ch in text if ch in ",.;:!?\"'()-")
    punct_ratio = n_punct / max(1, n_chars)
    comma_ratio = text.count(",") / n_words
    period_ratio = text.count(".") / n_words
    question_ratio = text.count("?") / n_words
    exclaim_ratio = text.count("!") / n_words
    uppercase_ratio = sum(1 for ch in text if ch.isupper()) / max(1, n_chars)
    digit_ratio = sum(1 for ch in text if ch.isdigit()) / max(1, n_chars)

    # function / stop words
    fw_set = set(_FUNCTION_WORDS)
    fw_hits = sum(1 for w in lower_words if w in fw_set)
    function_word_ratio = fw_hits / n_words
    stopword_ratio = function_word_ratio  # proxy; same closed-class list

    # readability (Flesch)
    syllables = [_count_syllables(w) for w in words]
    avg_syllables = float(np.mean(syllables))
    words_per_sentence = n_words / n_sentences
    flesch = 206.835 - 1.015 * words_per_sentence - 84.6 * avg_syllables
    flesch = max(-100.0, min(120.0, flesch))

    # bigram diversity
    bigrams = list(zip(lower_words[:-1], lower_words[1:]))
    unique_bigram_ratio = (len(set(bigrams)) / len(bigrams)) if bigrams else 0.0

    feats = [
        n_chars,
        n_words,
        n_sentences,
        float(np.mean(word_lens)),
        float(np.std(word_lens)),
        float(np.mean(sent_lens)),
        float(np.std(sent_lens)),
        type_token_ratio,
        hapax_ratio,
        long_word_ratio,
        short_word_ratio,
        punct_ratio,
        comma_ratio,
        period_ratio,
        question_ratio,
        exclaim_ratio,
        uppercase_ratio,
        digit_ratio,
        stopword_ratio,
        function_word_ratio,
        flesch,
        avg_syllables,
        unique_bigram_ratio,
        repeated_word_ratio,
    ]
    return np.array(feats, dtype=np.float32)


def extract_matrix(texts: List[str]) -> np.ndarray:
    """Feature matrix [N, N_FEATURES] for a list of texts."""
    return np.stack([extract_features(t) for t in texts], axis=0)


class StandardizerStats:
    """Column mean/std for standardizing stylometric features (fit on train)."""

    def __init__(self, mean: np.ndarray, std: np.ndarray):
        self.mean = mean
        self.std = std

    @classmethod
    def fit(cls, matrix: np.ndarray) -> "StandardizerStats":
        mean = matrix.mean(axis=0)
        std = matrix.std(axis=0)
        std[std < 1e-6] = 1.0
        return cls(mean.astype(np.float32), std.astype(np.float32))

    def transform(self, matrix: np.ndarray) -> np.ndarray:
        return ((matrix - self.mean) / self.std).astype(np.float32)

    def to_dict(self):
        return {"mean": self.mean.tolist(), "std": self.std.tolist()}

    @classmethod
    def from_dict(cls, d):
        return cls(np.array(d["mean"], np.float32), np.array(d["std"], np.float32))
