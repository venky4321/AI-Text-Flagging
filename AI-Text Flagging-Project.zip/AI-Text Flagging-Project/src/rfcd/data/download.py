"""Download real datasets from the internet (Hugging Face Hub).

Three sources are unified into one table with columns:
    text  : str
    label : int   (0 = human, 1 = AI-generated)
    group : str   ("native" or "esl")   -- only meaningful for human text
    domain: str   (source / topic tag)

AI text and native-human text come from HC3 (Hello-SimpleAI/HC3).
ESL human text comes from an English-learner essay corpus.

The functions are defensive: if a dataset/config is unavailable, they try
fallbacks and finally raise a clear error telling the user what happened.
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional

import pandas as pd


# --------------------------------------------------------------------------- #
# HC3: AI (chatgpt) + native human text
# --------------------------------------------------------------------------- #
def load_hc3(dataset: str, config: str, seed: int = 42) -> pd.DataFrame:
    """Return a DataFrame with columns [text, label, group, domain] from HC3.

    label 1 rows are chatgpt answers; label 0 rows are human answers, tagged
    group='native'.

    HC3 ships a (now-unsupported) loading script, so we read the raw JSONL files
    directly from the Hub. `config` selects the file (e.g. 'all' -> all.jsonl).
    """
    import json

    from huggingface_hub import hf_hub_download

    filename = f"{config}.jsonl"
    path = hf_hub_download(repo_id=dataset, filename=filename, repo_type="dataset")

    rows: List[Dict] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            ex = json.loads(line)
            domain = ex.get("source", config) or config
            for human in _as_list(ex.get("human_answers")):
                text = _clean(human)
                if text:
                    rows.append({"text": text, "label": 0, "group": "native",
                                 "domain": domain})
            for ai in _as_list(ex.get("chatgpt_answers")):
                text = _clean(ai)
                if text:
                    rows.append({"text": text, "label": 1, "group": "ai",
                                 "domain": domain})
    df = pd.DataFrame(rows)
    return df.sample(frac=1.0, random_state=seed).reset_index(drop=True)


# --------------------------------------------------------------------------- #
# ESL human essays
# --------------------------------------------------------------------------- #
def load_esl(primary: str, fallbacks: Optional[List[str]] = None, seed: int = 42) -> pd.DataFrame:
    """Return a DataFrame [text, label(=0), group('esl'), domain] of ESL essays.

    Tries the primary dataset, then each fallback. Auto-detects the text column.
    """
    from datasets import load_dataset

    candidates = [primary] + list(fallbacks or [])
    last_err = None
    for name in candidates:
        try:
            df = _load_esl_one(load_dataset, name)
            if df is not None and len(df) > 0:
                df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
                print(f"[data] Loaded {len(df)} ESL essays from '{name}'.")
                return df
        except Exception as exc:  # noqa: BLE001 - we intentionally try fallbacks
            last_err = exc
            print(f"[data] ESL source '{name}' failed: {exc}")
    raise RuntimeError(
        f"Could not load any ESL dataset from {candidates}. Last error: {last_err}"
    )


def _load_esl_one(load_dataset, name: str) -> Optional[pd.DataFrame]:
    try:
        ds = load_dataset(name)
        split = "train" if "train" in ds else list(ds.keys())[0]
        data = ds[split]
        text_col = _detect_text_column(list(data.column_names), data)
        if text_col is None:
            return None
        raw = pd.DataFrame({text_col: data[text_col]})
    except Exception as exc:  # script-based dataset or other load error
        msg = str(exc).lower()
        if "script" in msg or "no longer supported" in msg or "trust_remote_code" in msg:
            raw = _load_tabular_from_hub(name)
            if raw is None:
                raise
            text_col = _detect_text_column_df(raw)
            if text_col is None:
                return None
        else:
            raise

    rows = []
    for text in raw[text_col].tolist():
        clean = _clean(text)
        if clean:
            rows.append({"text": clean, "label": 0, "group": "esl",
                         "domain": f"esl:{name}"})
    return pd.DataFrame(rows)


def _load_tabular_from_hub(name: str) -> Optional[pd.DataFrame]:
    """Fetch parquet/csv/jsonl data files directly from a dataset repo."""
    from huggingface_hub import HfApi, hf_hub_download

    api = HfApi()
    files = api.list_repo_files(repo_id=name, repo_type="dataset")
    exts = (".parquet", ".csv", ".jsonl", ".json")
    data_files = [f for f in files if f.lower().endswith(exts)]
    # prefer train files, then any
    data_files.sort(key=lambda f: (0 if "train" in f.lower() else 1, f))
    frames = []
    for f in data_files:
        try:
            local = hf_hub_download(repo_id=name, filename=f, repo_type="dataset")
            if f.lower().endswith(".parquet"):
                frames.append(pd.read_parquet(local))
            elif f.lower().endswith(".csv"):
                frames.append(pd.read_csv(local))
            else:
                frames.append(pd.read_json(local, lines=f.lower().endswith(".jsonl")))
        except Exception:
            continue
        if frames:  # one good file is enough
            break
    if not frames:
        return None
    return frames[0]


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
_TEXT_COL_PRIORITY = [
    "full_text", "text", "essay", "content", "answer", "response",
    "sentence", "document", "body", "input",
]


def _detect_text_column(columns: List[str], data) -> Optional[str]:
    lower = {c.lower(): c for c in columns}
    for cand in _TEXT_COL_PRIORITY:
        if cand in lower:
            return lower[cand]
    # otherwise pick the string column with the longest average content
    best, best_len = None, -1.0
    sample = data.select(range(min(50, len(data))))
    for c in columns:
        vals = [v for v in sample[c] if isinstance(v, str)]
        if not vals:
            continue
        avg = sum(len(v) for v in vals) / max(1, len(vals))
        if avg > best_len:
            best, best_len = c, avg
    return best


def _detect_text_column_df(df: pd.DataFrame) -> Optional[str]:
    lower = {c.lower(): c for c in df.columns}
    for cand in _TEXT_COL_PRIORITY:
        if cand in lower:
            return lower[cand]
    best, best_len = None, -1.0
    sample = df.head(50)
    for c in df.columns:
        vals = [v for v in sample[c].tolist() if isinstance(v, str)]
        if not vals:
            continue
        avg = sum(len(v) for v in vals) / max(1, len(vals))
        if avg > best_len:
            best, best_len = c, avg
    return best


def _as_list(value) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple)):
        return [v for v in value if isinstance(v, str)]
    return []


def _clean(text) -> str:
    if not isinstance(text, str):
        return ""
    return " ".join(text.split()).strip()
