"""Evaluation: accuracy/robustness metrics, fairness metrics, and the central
"does fairness survive attacks?" analysis.

Definitions
-----------
Positive class = AI-generated (label 1). A *false positive* is a human text flagged
as AI -- the harm this paper targets, especially for ESL writers.

Standard detection metrics:
    accuracy, precision, recall, F1, ROC-AUC  (overall)

Fairness metrics (native vs ESL, computed on HUMAN samples):
    FPR_native, FPR_esl        : rate of humans wrongly flagged as AI, per group
    fpr_gap = FPR_esl - FPR_native   (the bias: positive = ESL over-flagged)
    demographic_parity_gap     : difference in P(pred=AI) across groups
    equalized_odds_gap         : max group difference in TPR and FPR

Robustness metrics:
    everything above recomputed on the PARAPHRASED test set.

Fairness-under-attack (the contribution):
    fpr_gap_clean, fpr_gap_attacked, and
    fairness_survival = fpr_gap_attacked - fpr_gap_clean
    -> if paraphrasing widens the gap, fairness did NOT survive the attack.

A shared decision threshold is calibrated on the clean test set so that the native
human false-positive rate equals `fpr_target`. The SAME threshold is reused on the
attacked set, so any change in fairness is attributable to the attack, not
re-tuning.
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np


# --------------------------------------------------------------------------- #
# core helpers
# --------------------------------------------------------------------------- #
def _safe_div(a, b):
    return float(a) / float(b) if b else 0.0


def calibrate_threshold(scores: np.ndarray, labels: np.ndarray,
                        groups: np.ndarray, fpr_target: float,
                        ref_group: str = "native") -> float:
    """Pick threshold on AI-probability so that ref-group human FPR ~= fpr_target."""
    mask = (labels == 0) & (groups == ref_group)
    human_scores = scores[mask]
    if human_scores.size == 0:
        human_scores = scores[labels == 0]
    if human_scores.size == 0:
        return 0.5
    # threshold = the (1 - fpr_target) quantile of reference-group human scores
    thr = float(np.quantile(human_scores, 1.0 - fpr_target))
    return min(max(thr, 1e-4), 1 - 1e-4)


def detection_metrics(scores: np.ndarray, labels: np.ndarray,
                      threshold: float) -> Dict[str, float]:
    preds = (scores >= threshold).astype(int)
    tp = int(((preds == 1) & (labels == 1)).sum())
    tn = int(((preds == 0) & (labels == 0)).sum())
    fp = int(((preds == 1) & (labels == 0)).sum())
    fn = int(((preds == 0) & (labels == 1)).sum())
    acc = _safe_div(tp + tn, tp + tn + fp + fn)
    prec = _safe_div(tp, tp + fp)
    rec = _safe_div(tp, tp + fn)
    f1 = _safe_div(2 * prec * rec, prec + rec)
    return {
        "accuracy": acc, "precision": prec, "recall": rec, "f1": f1,
        "tp": tp, "tn": tn, "fp": fp, "fn": fn,
        "auc": roc_auc(scores, labels),
    }


def roc_auc(scores: np.ndarray, labels: np.ndarray) -> float:
    """ROC-AUC via rank statistic (no sklearn dependency)."""
    pos = scores[labels == 1]
    neg = scores[labels == 0]
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    order = np.argsort(scores)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(scores) + 1)
    # average ranks for ties
    sorted_scores = scores[order]
    i = 0
    while i < len(sorted_scores):
        j = i
        while j + 1 < len(sorted_scores) and sorted_scores[j + 1] == sorted_scores[i]:
            j += 1
        if j > i:
            avg = (ranks[order[i]] + ranks[order[j]]) / 2.0
            for k in range(i, j + 1):
                ranks[order[k]] = avg
        i = j + 1
    sum_pos = ranks[labels == 1].sum()
    n_pos, n_neg = pos.size, neg.size
    return float((sum_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def group_fpr(scores: np.ndarray, labels: np.ndarray, groups: np.ndarray,
              threshold: float) -> Dict[str, float]:
    """False-positive rate (human flagged as AI) per group."""
    out = {}
    for g in ("native", "esl"):
        mask = (labels == 0) & (groups == g)
        if mask.sum() == 0:
            out[g] = float("nan")
            continue
        preds = (scores[mask] >= threshold).astype(int)
        out[g] = float(preds.mean())  # fraction predicted AI
    return out


def fairness_metrics(scores: np.ndarray, labels: np.ndarray, groups: np.ndarray,
                     threshold: float) -> Dict[str, float]:
    fpr = group_fpr(scores, labels, groups, threshold)
    fpr_native, fpr_esl = fpr.get("native", float("nan")), fpr.get("esl", float("nan"))
    fpr_gap = fpr_esl - fpr_native

    # demographic parity: P(pred=AI) among humans, per group
    dp = {}
    for g in ("native", "esl"):
        mask = (labels == 0) & (groups == g)
        dp[g] = float((scores[mask] >= threshold).mean()) if mask.sum() else float("nan")
    dp_gap = abs(dp["esl"] - dp["native"])

    # equalized odds: max gap of TPR and FPR across groups (humans have no TPR,
    # so TPR is measured on AI text attributed to each group)
    tpr = {}
    for g in ("native", "esl"):
        mask = (labels == 1) & (groups == g)
        tpr[g] = float((scores[mask] >= threshold).mean()) if mask.sum() else float("nan")
    tpr_gap = abs((tpr["esl"] - tpr["native"])) if not (
        np.isnan(tpr["esl"]) or np.isnan(tpr["native"])) else float("nan")
    eo_gap = np.nanmax([abs(fpr_gap), tpr_gap])

    return {
        "fpr_native": fpr_native,
        "fpr_esl": fpr_esl,
        "fpr_gap": float(fpr_gap),
        "demographic_parity_gap": float(dp_gap),
        "equalized_odds_gap": float(eo_gap),
    }


def evaluate_split(scores_clean, scores_attacked, labels, groups,
                   fpr_target: float = 0.05) -> Dict:
    """Full evaluation: clean, attacked, and fairness-under-attack.

    All arrays are aligned numpy arrays for the same test rows.
    """
    labels = np.asarray(labels)
    groups = np.asarray(groups)
    scores_clean = np.asarray(scores_clean, dtype=float)

    thr = calibrate_threshold(scores_clean, labels, groups, fpr_target)

    clean_det = detection_metrics(scores_clean, labels, thr)
    clean_fair = fairness_metrics(scores_clean, labels, groups, thr)

    result = {
        "threshold": thr,
        "fpr_target": fpr_target,
        "clean": {**clean_det, **clean_fair},
    }

    if scores_attacked is not None:
        scores_attacked = np.asarray(scores_attacked, dtype=float)
        att_det = detection_metrics(scores_attacked, labels, thr)
        att_fair = fairness_metrics(scores_attacked, labels, groups, thr)
        result["attacked"] = {**att_det, **att_fair}

        # ---- the contribution: does fairness survive the attack? ----
        gap_clean = clean_fair["fpr_gap"]
        gap_att = att_fair["fpr_gap"]
        # AI recall under attack drop = robustness of detection itself
        result["fairness_under_attack"] = {
            "fpr_gap_clean": gap_clean,
            "fpr_gap_attacked": gap_att,
            "fairness_survival": float(gap_att - gap_clean),  # >0 => fairness eroded
            "ai_recall_clean": clean_det["recall"],
            "ai_recall_attacked": att_det["recall"],
            "recall_drop_under_attack": float(clean_det["recall"] - att_det["recall"]),
            "esl_fpr_clean": clean_fair["fpr_esl"],
            "esl_fpr_attacked": att_fair["fpr_esl"],
        }
    return result


def summarize_for_paper(all_variant_results: Dict[str, Dict]) -> List[Dict]:
    """Flatten per-variant results into rows for a results table."""
    rows = []
    for variant, res in all_variant_results.items():
        clean = res.get("clean", {})
        att = res.get("attacked", {})
        fua = res.get("fairness_under_attack", {})
        rows.append({
            "variant": variant,
            "acc": round(clean.get("accuracy", float("nan")), 4),
            "f1": round(clean.get("f1", float("nan")), 4),
            "auc": round(clean.get("auc", float("nan")), 4),
            "fpr_native": round(clean.get("fpr_native", float("nan")), 4),
            "fpr_esl": round(clean.get("fpr_esl", float("nan")), 4),
            "fpr_gap_clean": round(clean.get("fpr_gap", float("nan")), 4),
            "acc_attacked": round(att.get("accuracy", float("nan")), 4),
            "ai_recall_attacked": round(att.get("recall", float("nan")), 4),
            "fpr_gap_attacked": round(att.get("fpr_gap", float("nan")), 4),
            "fairness_survival": round(fua.get("fairness_survival", float("nan")), 4),
        })
    return rows
