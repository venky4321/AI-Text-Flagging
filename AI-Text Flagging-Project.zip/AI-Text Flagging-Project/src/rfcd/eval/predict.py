"""Run a trained RFCD model over a dataframe to produce AI-probability scores."""
from __future__ import annotations

from typing import List, Optional

import numpy as np
import torch
from torch.utils.data import DataLoader

from ..train.dataset import RFCDDataset, Collator
from ..attacks.paraphrase import Paraphraser


@torch.no_grad()
def score_dataframe(model, tokenizer, df, style_stats, cfg, device,
                    paraphraser: Optional[Paraphraser] = None) -> np.ndarray:
    """Return P(AI) for each row. If paraphraser given, score paraphrased text."""
    model.eval()
    frame = df.copy()
    if paraphraser is not None:
        frame["text"] = [paraphraser.paraphrase(t) for t in frame["text"].tolist()]
    ds = RFCDDataset(frame, style_stats=style_stats, paraphraser=None,
                     paraphrase_prob=0.0)
    collator = Collator(tokenizer, cfg.model.max_length, with_paraphrase=False)
    loader = DataLoader(ds, batch_size=cfg.train.batch_size, shuffle=False,
                        collate_fn=collator, num_workers=0)
    probs: List[np.ndarray] = []
    for batch in loader:
        input_ids = batch["input_ids"].to(device)
        attn = batch["attention_mask"].to(device)
        style = batch["style_features"].to(device)
        out = model(input_ids, attn, style, grl_lambda=0.0)
        p_ai = torch.softmax(out.logits, dim=-1)[:, 1]
        probs.append(p_ai.cpu().numpy())
    return np.concatenate(probs, axis=0)
