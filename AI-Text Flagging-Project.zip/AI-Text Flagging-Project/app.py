"""RFCD GUI — a Gradio app to run the whole pipeline from a browser.

Tabs:
  1. Data       : download real datasets (HC3 + ELLIPSE ESL) and build splits.
  2. Train      : train RFCD and ablation baselines (vanilla / fairness / robust).
  3. Evaluate   : compute accuracy, fairness (ESL vs native FPR gap), and the
                  fairness-under-attack analysis; show the paper table + figures.
  4. Try it     : paste text, get a Human/AI verdict, with a paraphrase-attack
                  toggle to see robustness live.

Run:
    pip install -r requirements.txt
    python app.py
Then open the printed local URL (http://127.0.0.1:7860).

Tip: tick "Fast smoke mode" for a quick CPU demo (tiny backbone, small data).
Untick it for a full research-grade run (roberta-base; slow on CPU, fast on GPU).
"""
from __future__ import annotations

import os
import sys
import traceback

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

import gradio as gr  # noqa: E402
import pandas as pd  # noqa: E402

from rfcd.config import load_config, apply_smoke  # noqa: E402
from rfcd.utils import set_seed, get_device, ensure_dir, save_json  # noqa: E402

os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

VARIANT_CHOICES = ["vanilla", "fairness_only", "robustness_only", "rfcd"]


# --------------------------------------------------------------------------- #
# shared state helpers
# --------------------------------------------------------------------------- #
def _cfg(smoke: bool):
    cfg = load_config()
    if smoke:
        apply_smoke(cfg)
    set_seed(cfg.seed)
    return cfg


def _suffix(smoke: bool) -> str:
    return "_smoke" if smoke else ""


# --------------------------------------------------------------------------- #
# 1. DATA
# --------------------------------------------------------------------------- #
def do_prepare(smoke):
    try:
        from rfcd.data.build_dataset import build_and_save

        cfg = _cfg(smoke)
        df, path = build_and_save(cfg, smoke=smoke)
        counts = (
            df.groupby(["split", "group"]).size().unstack(fill_value=0).reset_index()
        )
        msg = f"Saved dataset to {path}\nTotal rows: {len(df)}"
        return msg, counts
    except Exception:
        return f"ERROR:\n{traceback.format_exc()}", None


# --------------------------------------------------------------------------- #
# 2. TRAIN
# --------------------------------------------------------------------------- #
def do_train(smoke, variants, progress=gr.Progress()):
    try:
        if not variants:
            return "Select at least one variant to train."
        from rfcd.data.build_dataset import load_saved
        from rfcd.data.stylometry import extract_matrix, StandardizerStats, N_FEATURES
        from rfcd.attacks.paraphrase import Paraphraser
        from rfcd.models.rfcd_model import build_model
        from rfcd.train.trainer import RFCDTrainer, VARIANTS
        from transformers import AutoTokenizer

        cfg = _cfg(smoke)
        device = get_device()
        suffix = _suffix(smoke)

        df = load_saved(cfg, smoke=smoke)
        train_df = df[df.split == "train"].reset_index(drop=True)
        val_df = df[df.split == "val"].reset_index(drop=True)

        progress(0.05, desc="Fitting stylometry standardizer")
        style_stats = StandardizerStats.fit(extract_matrix(train_df["text"].tolist()))

        tokenizer = AutoTokenizer.from_pretrained(cfg.model.backbone)
        paraphraser = Paraphraser(
            methods=list(cfg.attacks.methods),
            synonym_rate=cfg.attacks.synonym_rate,
            seed=cfg.seed,
        )
        ckpt_dir = ensure_dir(cfg.paths.checkpoint_dir)

        log = [f"device={device}  backbone={cfg.model.backbone}"]
        for i, vname in enumerate(variants):
            progress((i + 0.5) / len(variants), desc=f"Training {vname}")
            set_seed(cfg.seed)
            model = build_model(cfg, n_style_features=N_FEATURES)
            trainer = RFCDTrainer(cfg, model, tokenizer, VARIANTS[vname], device,
                                  paraphraser=paraphraser)
            hist = trainer.fit(train_df, val_df, style_stats)
            trainer.save(os.path.join(ckpt_dir, f"{vname}{suffix}.pt"))
            last = hist[-1]["val_acc"] if hist else float("nan")
            log.append(f"[{vname}] done — final val_acc={last:.4f}")

        return "\n".join(log)
    except Exception:
        return f"ERROR:\n{traceback.format_exc()}"


# --------------------------------------------------------------------------- #
# 3. EVALUATE
# --------------------------------------------------------------------------- #
def do_evaluate(smoke, progress=gr.Progress()):
    try:
        import torch
        from rfcd.data.build_dataset import load_saved
        from rfcd.data.stylometry import StandardizerStats, N_FEATURES
        from rfcd.attacks.paraphrase import Paraphraser
        from rfcd.models.rfcd_model import build_model
        from rfcd.eval.predict import score_dataframe
        from rfcd.eval.metrics import evaluate_split, summarize_for_paper
        from rfcd.report.figures import make_all_figures
        from transformers import AutoTokenizer

        cfg = _cfg(smoke)
        device = get_device()
        suffix = _suffix(smoke)

        df = load_saved(cfg, smoke=smoke)
        test_df = df[df.split == "test"].reset_index(drop=True)
        labels = test_df["label"].to_numpy()
        groups = test_df["group"].to_numpy()

        tokenizer = AutoTokenizer.from_pretrained(cfg.model.backbone)
        paraphraser = Paraphraser(methods=list(cfg.attacks.methods),
                                  synonym_rate=cfg.attacks.synonym_rate,
                                  seed=cfg.seed + 1)

        ckpt_dir = cfg.paths.checkpoint_dir
        variants = sorted(
            f[: -len(suffix + ".pt")] if suffix else f[:-3]
            for f in os.listdir(ckpt_dir)
            if f.endswith(f"{suffix}.pt") and (suffix or "_smoke" not in f)
        )
        if not variants:
            return "No checkpoints found. Train a model first.", None, [], None

        all_results = {}
        for i, vname in enumerate(variants):
            progress((i + 0.5) / len(variants), desc=f"Evaluating {vname}")
            ckpt = torch.load(os.path.join(ckpt_dir, f"{vname}{suffix}.pt"),
                              map_location=device, weights_only=False)
            style_stats = StandardizerStats.from_dict(ckpt["style_stats"])
            model = build_model(cfg, n_style_features=N_FEATURES).to(device)
            model.load_state_dict(ckpt["model_state"])
            sc_clean = score_dataframe(model, tokenizer, test_df, style_stats, cfg,
                                       device, paraphraser=None)
            sc_att = score_dataframe(model, tokenizer, test_df, style_stats, cfg,
                                     device, paraphraser=paraphraser)
            res = evaluate_split(sc_clean, sc_att, labels, groups,
                                 fpr_target=cfg.eval.fpr_target)
            res["_scores_clean"] = sc_clean.tolist()
            all_results[vname] = res

        results_dir = ensure_dir(cfg.paths.results_dir)
        clean = {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")}
                 for k, v in all_results.items()}
        save_json(clean, os.path.join(results_dir, f"metrics{suffix}.json"))
        summary = pd.DataFrame(summarize_for_paper(clean))
        summary.to_csv(os.path.join(results_dir, f"summary{suffix}.csv"), index=False)

        fig_dir = ensure_dir(os.path.join(results_dir, "figures"))
        make_all_figures(all_results, labels, fig_dir, suffix)
        imgs = [
            os.path.join(fig_dir, f"fpr_by_group{suffix}.png"),
            os.path.join(fig_dir, f"fairness_under_attack{suffix}.png"),
            os.path.join(fig_dir, f"roc{suffix}.png"),
        ]
        imgs = [p for p in imgs if os.path.exists(p)]

        # a short narrative on whether fairness survived the attack
        notes = []
        for v, r in clean.items():
            fua = r.get("fairness_under_attack", {})
            if fua:
                notes.append(
                    f"{v}: FPR gap clean={fua['fpr_gap_clean']:+.3f} -> "
                    f"attacked={fua['fpr_gap_attacked']:+.3f} "
                    f"(survival Δ={fua['fairness_survival']:+.3f}); "
                    f"AI recall {fua['ai_recall_clean']:.2f}->"
                    f"{fua['ai_recall_attacked']:.2f}"
                )
        return "Evaluation complete.\n" + "\n".join(notes), summary, imgs, summary
    except Exception:
        return f"ERROR:\n{traceback.format_exc()}", None, [], None


# --------------------------------------------------------------------------- #
# 4. TRY IT
# --------------------------------------------------------------------------- #
_LOADED = {"key": None, "model": None, "tokenizer": None, "stats": None, "cfg": None}


def _load_for_inference(smoke, variant):
    import torch
    from rfcd.data.stylometry import StandardizerStats, N_FEATURES
    from rfcd.models.rfcd_model import build_model
    from transformers import AutoTokenizer

    cfg = _cfg(smoke)
    suffix = _suffix(smoke)
    key = f"{variant}{suffix}"
    if _LOADED["key"] == key and _LOADED["model"] is not None:
        return _LOADED
    ckpt_path = os.path.join(cfg.paths.checkpoint_dir, f"{key}.pt")
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"No checkpoint {ckpt_path}. Train '{variant}' first.")
    device = get_device()
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    stats = StandardizerStats.from_dict(ckpt["style_stats"])
    model = build_model(cfg, n_style_features=N_FEATURES).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    tok = AutoTokenizer.from_pretrained(cfg.model.backbone)
    _LOADED.update(key=key, model=model, tokenizer=tok, stats=stats, cfg=cfg)
    return _LOADED


def do_predict(text, smoke, variant, attack):
    try:
        if not text or not text.strip():
            return "Enter some text first."
        import numpy as np
        import torch
        from rfcd.data.stylometry import extract_features
        from rfcd.attacks.paraphrase import Paraphraser

        st = _load_for_inference(smoke, variant)
        model, tok, stats, cfg = st["model"], st["tokenizer"], st["stats"], st["cfg"]
        device = get_device()

        used = text
        if attack:
            used = Paraphraser(methods=list(cfg.attacks.methods),
                               synonym_rate=cfg.attacks.synonym_rate,
                               seed=7).paraphrase(text)

        style = stats.transform(extract_features(used).reshape(1, -1))
        enc = tok([used], truncation=True, max_length=cfg.model.max_length,
                  return_tensors="pt")
        with torch.no_grad():
            out = model(enc["input_ids"].to(device),
                        enc["attention_mask"].to(device),
                        torch.tensor(style, dtype=torch.float32).to(device),
                        grl_lambda=0.0)
            p_ai = float(torch.softmax(out.logits, dim=-1)[0, 1].item())

        verdict = "AI-generated" if p_ai >= 0.5 else "Human-written"
        lines = [
            f"Verdict: {verdict}",
            f"P(AI) = {p_ai:.3f}   P(Human) = {1 - p_ai:.3f}",
            f"Model: {variant}   Attack applied: {bool(attack)}",
        ]
        if attack:
            lines.append("")
            lines.append("Paraphrased text scored:")
            lines.append(used[:500] + ("..." if len(used) > 500 else ""))
        return "\n".join(lines)
    except Exception:
        return f"ERROR:\n{traceback.format_exc()}"


# --------------------------------------------------------------------------- #
# UI
# --------------------------------------------------------------------------- #
def build_ui():
    with gr.Blocks(title="RFCD — Robustness-Fairness Co-Optimized Detector") as demo:
        gr.Markdown(
            "# RFCD — Robustness-Fairness Co-Optimized Detection of AI-Generated Text\n"
            "Protecting ESL students from bias and paraphrase attacks. "
            "Run the full research pipeline below."
        )
        smoke = gr.Checkbox(
            value=True,
            label="Fast smoke mode (tiny backbone + small data — quick CPU demo). "
                  "Uncheck for full roberta-base run (slow on CPU).",
        )

        with gr.Tab("1. Data"):
            gr.Markdown("Download real datasets (HC3 + ELLIPSE ESL essays) and build "
                        "stratified train/val/test splits.")
            data_btn = gr.Button("Prepare data", variant="primary")
            data_out = gr.Textbox(label="Log", lines=4)
            data_tbl = gr.Dataframe(label="Rows per split × group")
            data_btn.click(do_prepare, [smoke], [data_out, data_tbl])

        with gr.Tab("2. Train"):
            gr.Markdown("Train RFCD and its ablation baselines. `rfcd` = full "
                        "co-optimization (classification + fairness + robustness).")
            var_sel = gr.CheckboxGroup(VARIANT_CHOICES, value=["vanilla", "rfcd"],
                                       label="Variants to train")
            train_btn = gr.Button("Train", variant="primary")
            train_out = gr.Textbox(label="Training log", lines=12)
            train_btn.click(do_train, [smoke, var_sel], [train_out])

        with gr.Tab("3. Evaluate"):
            gr.Markdown("Evaluate all trained checkpoints on clean and "
                        "paraphrase-attacked test data. The key question: "
                        "**does fairness survive the attack?**")
            eval_btn = gr.Button("Evaluate", variant="primary")
            eval_out = gr.Textbox(label="Summary", lines=8)
            eval_tbl = gr.Dataframe(label="Paper results table")
            eval_gallery = gr.Gallery(label="Figures", columns=3, height="auto")
            eval_state = gr.State()
            eval_btn.click(do_evaluate, [smoke],
                           [eval_out, eval_tbl, eval_gallery, eval_state])

        with gr.Tab("4. Try it"):
            gr.Markdown("Paste text and get a Human/AI verdict. Toggle the "
                        "paraphrase attack to see robustness live.")
            in_text = gr.Textbox(label="Text to classify", lines=8,
                                 placeholder="Paste an essay or answer here...")
            with gr.Row():
                which = gr.Dropdown(VARIANT_CHOICES, value="rfcd", label="Model")
                atk = gr.Checkbox(value=False, label="Apply paraphrase attack")
            pred_btn = gr.Button("Classify", variant="primary")
            pred_out = gr.Textbox(label="Result", lines=10)
            pred_btn.click(do_predict, [in_text, smoke, which, atk], [pred_out])

        gr.Markdown(
            "---\nWorkflow: **Data → Train → Evaluate**, then explore in **Try it**. "
            "Keep the same smoke setting across tabs so checkpoints match."
        )
    return demo


if __name__ == "__main__":
    build_ui().launch()
