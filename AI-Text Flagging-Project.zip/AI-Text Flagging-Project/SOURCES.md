# Data Sources and Attribution

All datasets are downloaded from the internet at run time via the Hugging Face
`datasets` library. They are used for training, validation and testing under their
respective licenses.

## 1. HC3 — Human ChatGPT Comparison Corpus
- Hugging Face: `Hello-SimpleAI/HC3` (config `all`, split `train`)
- Paper: Guo et al., "How Close is ChatGPT to Human Experts? Comparison Corpus,
  Evaluation, and Detection," arXiv:2301.07597 (2023).
- Repo: https://github.com/Hello-SimpleAI/chatgpt-comparison-detection
- Schema used: `human_answers` (list[str]) as human text, `chatgpt_answers`
  (list[str]) as AI-generated text, `source` as domain.
- Role in this project:
  - `chatgpt_answers` -> label = AI (1)
  - `human_answers`  -> label = Human (0), demographic group = **native**

## 2. English Learner Essays (ESL) — ELLIPSE corpus
- Hugging Face: `tcapelle/feedback-prize-english-language-learning-fluency`
  (parquet mirror of the ELLIPSE / Feedback Prize "English Language Learning"
  corpus). License: apache-2.0 on the mirror.
- Argumentative essays written by English language learners (grades 8–12),
  scored on analytic traits: cohesion, syntax, vocabulary, phraseology, grammar,
  conventions. The `full_text` field is used as the ESL writing sample.
- Role in this project: learner essays -> label = Human (0), group = **ESL**.
- Fallback ESL sources (auto-tried if the primary is unavailable):
  - `KevSun/Engessay_grading_ML` (English-learner essays, gated)
  - `nusnlp/NUCLE` (NUS Corpus of Learner English)

## Notes on fairness framing
"Group" here is a proxy for native vs non-native (ESL) English writing, derived from
the dataset of origin. This mirrors the setup used in prior detector-fairness studies
where writing samples from language-learner corpora represent the ESL population.

## Compliance
Content from these sources is summarized/paraphrased in code and documentation.
No dataset content is redistributed in this repository; it is fetched at run time.
