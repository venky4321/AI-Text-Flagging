"""
Decision analytics for the JIDMIS research article (real data).

Produces results/decision_analytics.json with:
  * cost-optimal threshold chosen on CALIBRATION split, evaluated on TEST
  * abstention bands: rate, group FPR, AI recall, expected cost
  * cost-ratio sensitivity: optimal threshold + group FPRs at 1:1:1, 1:1:2, 1:1:5
  * TOPSIS ranking of detectors over {accuracy, fairness, robustness, cost}

Data: HC3 (human+AI) + ELLIPSE (learner). Detectors: supervised DistilBERT,
GPT-2 perplexity, stylometry+LR. Everything measured. Run: python scripts/run_decision_analytics.py [--full]
"""
import argparse, json, os, sys, math, warnings, random
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"]="1"
import numpy as np, pandas as pd, torch
from rfcd.data.stylometry import extract_matrix, extract_features, StandardizerStats
from rfcd.attacks.paraphrase import Paraphraser

ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
RES=os.path.join(ROOT,"results"); os.makedirs(RES,exist_ok=True)
DEV="cuda" if torch.cuda.is_available() else "cpu"
SEED=42

def _clean(t): return " ".join(str(t).split()).strip() if isinstance(t,str) else ""
def load_hc3(n):
    import json as _j; from huggingface_hub import hf_hub_download
    p=hf_hub_download("Hello-SimpleAI/HC3","all.jsonl",repo_type="dataset")
    ai,nat=[],[]
    for line in open(p,encoding="utf-8"):
        line=line.strip()
        if not line: continue
        ex=_j.loads(line)
        for h in ex.get("human_answers",[]) or []:
            t=_clean(h)
            if len(t.split())>=40: nat.append(t)
        for a in ex.get("chatgpt_answers",[]) or []:
            t=_clean(a)
            if len(t.split())>=40: ai.append(t)
    r=random.Random(SEED); r.shuffle(ai); r.shuffle(nat); return ai[:n],nat[:n]
def load_ellipse(n):
    from huggingface_hub import hf_hub_download, HfApi
    repo="tcapelle/feedback-prize-english-language-learning-fluency"
    files=HfApi().list_repo_files(repo_id=repo,repo_type="dataset")
    pq=[f for f in files if f.lower().endswith(".parquet")]; pq.sort(key=lambda f:(0 if "train" in f.lower() else 1,f))
    df=pd.read_parquet(hf_hub_download(repo,pq[0],repo_type="dataset"))
    tcol="full_text" if "full_text" in df.columns else df.columns[1]
    df["text"]=df[tcol].map(_clean)
    df=df[df["text"].str.split().map(len)>=40].reset_index(drop=True)
    return df.sample(min(n,len(df)),random_state=SEED).reset_index(drop=True)[["text"]]

def build(smoke):
    n=400 if smoke else 2000
    ai,nat=load_hc3(n); esl=load_ellipse(n)
    rows=[{"text":t,"label":1,"group":"ai"} for t in ai]
    rows+=[{"text":t,"label":0,"group":"native"} for t in nat]
    rows+=[{"text":t,"label":0,"group":"esl"} for t in esl.text]
    df=pd.DataFrame(rows).sample(frac=1.0,random_state=SEED).reset_index(drop=True)
    df["split"]="train"; rng=np.random.default_rng(SEED)
    for _,idx in df.groupby(["label","group"]).groups.items():
        idx=np.array(list(idx)); rng.shuffle(idx); m=len(idx)
        df.loc[idx[:int(m*.25)],"split"]="test"; df.loc[idx[int(m*.25):int(m*.45)],"split"]="cal"
    return df

def rank01(x):
    x=np.asarray(x,float); o=x.argsort(); r=np.empty_like(o,float); r[o]=np.linspace(0,1,len(x)); return r

# detectors (reuse minimal versions)
class Sup:
    def __init__(s,ep): s.ep=ep
    def fit(s,tx,lb):
        from transformers import AutoTokenizer, AutoModelForSequenceClassification
        from torch.utils.data import DataLoader, TensorDataset
        torch.manual_seed(SEED)
        s.tok=AutoTokenizer.from_pretrained("distilbert-base-uncased")
        s.m=AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased",num_labels=2).to(DEV)
        enc=s.tok(list(tx),truncation=True,max_length=192,padding=True,return_tensors="pt")
        dl=DataLoader(TensorDataset(enc["input_ids"],enc["attention_mask"],torch.tensor(lb)),batch_size=8,shuffle=True)
        opt=torch.optim.AdamW(s.m.parameters(),lr=2e-5); s.m.train()
        for _ in range(s.ep):
            for i,a,y in dl:
                opt.zero_grad(); s.m(input_ids=i.to(DEV),attention_mask=a.to(DEV),labels=y.to(DEV)).loss.backward(); opt.step()
        return s
    @torch.no_grad()
    def score(s,tx):
        from torch.utils.data import DataLoader, TensorDataset
        s.m.eval(); enc=s.tok(list(tx),truncation=True,max_length=192,padding=True,return_tensors="pt")
        dl=DataLoader(TensorDataset(enc["input_ids"],enc["attention_mask"]),batch_size=16); o=[]
        for i,a in dl: o.append(torch.softmax(s.m(input_ids=i.to(DEV),attention_mask=a.to(DEV)).logits,-1)[:,1].cpu().numpy())
        return np.concatenate(o)
class Ppl:
    def fit(s,*a,**k):
        from transformers import AutoTokenizer, AutoModelForCausalLM
        s.tok=AutoTokenizer.from_pretrained("gpt2"); s.m=AutoModelForCausalLM.from_pretrained("gpt2").to(DEV).eval(); return s
    @torch.no_grad()
    def nll(s,t):
        ids=s.tok(t,return_tensors="pt",truncation=True,max_length=192).input_ids.to(DEV)
        if ids.shape[1]<2: return 5.0
        return float(s.m(ids,labels=ids).loss.item())
    def score(s,tx): return -np.array([s.nll(t) for t in tx])
class Sty:
    def fit(s,tx,lb):
        from sklearn.linear_model import LogisticRegression
        X=extract_matrix(list(tx)); s.st=StandardizerStats.fit(X)
        s.c=LogisticRegression(max_iter=1000).fit(s.st.transform(X),lb); return s
    def score(s,tx): return s.c.predict_proba(s.st.transform(extract_matrix(list(tx))))[:,1]

def expected_cost(scores,y,grp,thr, cFN, cFPL, cFPN):
    """per-case expected cost with empirical base rates."""
    N=len(y); pAI=(y==1).mean()
    flag=scores>=thr
    miss=((~flag)&(y==1)).sum()
    fpL=((flag)&(y==0)&(grp=="esl")).sum()
    fpN=((flag)&(y==0)&(grp=="native")).sum()
    return float((cFN*miss + cFPL*fpL + cFPN*fpN)/N)

def group_fpr(scores,y,grp,thr,g):
    m=(y==0)&(grp==g); 
    return float((scores[m]>=thr).mean()) if m.sum() else float("nan")

def recall(scores,y,thr):
    m=y==1; return float((scores[m]>=thr).mean()) if m.sum() else float("nan")

def main(smoke):
    print(f"[da] device={DEV} smoke={smoke}")
    df=build(smoke)
    tr=df[df.split=="train"]; cal=df[df.split=="cal"]; te=df[df.split=="test"].reset_index(drop=True)
    print(f"[da] train={len(tr)} cal={len(cal)} test={len(te)}")
    para=Paraphraser(seed=SEED+5)

    dets={"supervised":Sup(1 if smoke else 2),"perplexity":Ppl(),"stylometry":Sty()}
    out={"design":{"n_train":len(tr),"n_cal":len(cal),"n_test":len(te),
                   "n_esl_test":int((te.group=="esl").sum()),
                   "n_native_test":int((te.group=="native").sum()),
                   "n_ai_test":int((te.label==1).sum())},
         "detectors":{}}
    ratios={"1:1:1":(1,1,1),"1:1:2":(1,1,2),"1:1:5":(1,1,5)}

    metrics_for_topsis={}
    for name,det in dets.items():
        det.fit(tr.text.tolist(),tr.label.values)
        sc_cal=np.asarray(det.score(cal.text.tolist()),float)
        sc_te=np.asarray(det.score(te.text.tolist()),float)
        srt=None
        if name=="perplexity":
            # calibrate a rank mapping on CAL raw scores; apply same map to TEST
            srt=np.sort(sc_cal)
            sc_cal = np.interp(sc_cal, srt, np.linspace(0,1,len(srt)))
            sc_te  = np.interp(sc_te,  srt, np.linspace(0,1,len(srt)))
        yC=cal.label.values; gC=cal.group.values
        yT=te.label.values; gT=te.group.values

        det_out={}
        # cost-ratio sensitivity: choose threshold on CAL minimising expected cost, eval on TEST
        grid=np.linspace(0.05,0.995,190)
        sens={}
        for rk,(cFN,cFPN,cFPL) in ratios.items():
            costs=[expected_cost(sc_cal,yC,gC,t,cFN,cFPL,cFPN) for t in grid]
            thr=float(grid[int(np.argmin(costs))])
            sens[rk]={"threshold_on_cal":thr,
                      "test_cost":expected_cost(sc_te,yT,gT,thr,cFN,cFPL,cFPN),
                      "fpr_esl":group_fpr(sc_te,yT,gT,thr,"esl"),
                      "fpr_native":group_fpr(sc_te,yT,gT,thr,"native"),
                      "ai_recall":recall(sc_te,yT,thr)}
        det_out["cost_sensitivity"]=sens

        # abstention bands around the 1:1:2 cost-optimal threshold
        base_thr=sens["1:1:2"]["threshold_on_cal"]
        bands={}
        for w in (0.0,0.05,0.10):
            lo=base_thr-w; hi=base_thr+w
            abstain=(sc_te>=lo)&(sc_te<hi)
            decided=~abstain
            flag=(sc_te>=hi)
            # on decided set
            dmaskL=(yT==0)&(gT=="esl")&decided
            dmaskN=(yT==0)&(gT=="native")&decided
            fprL=float((flag[dmaskL]).mean()) if dmaskL.sum() else float("nan")
            fprN=float((flag[dmaskN]).mean()) if dmaskN.sum() else float("nan")
            rec=float((flag[(yT==1)&decided]).mean()) if ((yT==1)&decided).sum() else float("nan")
            bands[f"band_pm{w:.2f}"]={"abstain_rate":float(abstain.mean()),
                "abstain_rate_esl":float((abstain&(gT=="esl")).sum()/max(1,(gT=="esl").sum())),
                "abstain_rate_native":float((abstain&(gT=="native")).sum()/max(1,(gT=="native").sum())),
                "fpr_esl_decided":fprL,"fpr_native_decided":fprN,"ai_recall_decided":rec}
        det_out["abstention"]=bands

        # headline metrics at 1:1:2 for TOPSIS
        s2=sens["1:1:2"]
        # accuracy at that threshold
        acc=float(((sc_te>=s2["threshold_on_cal"]).astype(int)==yT).mean())
        # robustness: AI recall drop under A1 attack on AI texts
        ai_idx=np.where(yT==1)[0]
        att=list(te.text)
        for i in ai_idx: att[i]=para.paraphrase(att[i])
        sca=np.asarray(det.score(att),float)
        if name=="perplexity" and srt is not None:
            sca=np.interp(sca, srt, np.linspace(0,1,len(srt)))
        rec_att=recall(sca,yT,s2["threshold_on_cal"])
        robustness=1.0-abs(s2["ai_recall"]-rec_att)  # 1 = no drop
        fairness=1.0-abs(s2["fpr_esl"]-s2["fpr_native"])  # 1 = equal FPR
        cost=s2["test_cost"]
        metrics_for_topsis[name]={"accuracy":acc,"fairness":fairness,
                                   "robustness":robustness,"neg_cost":-cost}
        det_out["headline@1:1:2"]={"accuracy":acc,"fairness_gap":abs(s2["fpr_esl"]-s2["fpr_native"]),
                                   "ai_recall":s2["ai_recall"],"ai_recall_attacked":rec_att,
                                   "test_cost":cost}
        out["detectors"][name]=det_out
        print(f"[da] {name}: 1:1:2 thr={s2['threshold_on_cal']:.3f} fprL={s2['fpr_esl']:.3f} "
              f"fprN={s2['fpr_native']:.3f} rec={s2['ai_recall']:.3f} cost={cost:.3f} acc={acc:.3f}")
        del det
        if DEV=="cuda": torch.cuda.empty_cache()

    # TOPSIS over detectors: criteria accuracy, fairness, robustness, neg_cost (all benefit)
    names=list(metrics_for_topsis.keys())
    crit=["accuracy","fairness","robustness","neg_cost"]
    Mx=np.array([[metrics_for_topsis[n][c] for c in crit] for n in names],float)
    # normalise (vector), equal weights
    norm=Mx/np.sqrt((Mx**2).sum(axis=0,keepdims=True)+1e-12)
    w=np.array([0.25,0.25,0.25,0.25]); V=norm*w
    ideal=V.max(axis=0); anti=V.min(axis=0)
    dp=np.sqrt(((V-ideal)**2).sum(axis=1)); dn=np.sqrt(((V-anti)**2).sum(axis=1))
    cc=dn/(dp+dn+1e-12)
    topsis={names[i]:{"closeness":float(cc[i])} for i in range(len(names))}
    ranked=sorted(topsis,key=lambda k:-topsis[k]["closeness"])
    out["topsis"]={"criteria":crit,"weights":w.tolist(),"scores":topsis,"ranking":ranked,
                   "raw_metrics":metrics_for_topsis}
    print("[da] TOPSIS ranking:",ranked)

    path=os.path.join(RES,"decision_analytics.json")
    json.dump(out,open(path,"w"),indent=2,default=float)
    print(f"[da] saved {path}")

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--full",action="store_true")
    a=ap.parse_args(); main(smoke=not a.full)
