"""End-to-end runner: prepare data -> train all variants -> evaluate.

Usage:
    python scripts/run_all.py            # full experiment
    python scripts/run_all.py --smoke    # fast end-to-end sanity run
"""
import argparse
import subprocess
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))


def run(script, extra):
    cmd = [sys.executable, os.path.join(_HERE, script)] + extra
    print(f"\n>>> {' '.join(cmd)}\n")
    subprocess.check_call(cmd)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    extra = ["--smoke"] if args.smoke else []

    run("01_prepare_data.py", extra)
    run("02_train.py", extra)
    run("03_evaluate.py", extra)
    print("\nAll done. See results/ for metrics, tables, and figures.")


if __name__ == "__main__":
    main()
