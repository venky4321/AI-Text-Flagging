"""
JIDMIS decision-focused experiments on real HC3 + ELLIPSE data:

  (1) H3  : train vanilla / fairness-only / robustness-only / RFCD (DistilBERT),
            compute per-essay FUA, compare RFCD vs each ablation (paired bootstrap).
  (2) De-confound sensitivity: re-run H1 (perplexity) and H2 after matching ESL and
            native essays on word-count band + Flesch readability band.
  (3) Decision-cost model: net benefit by group across flagging thresholds
            (decision-curve data) using a cost model c_FN, c_FP_L, c_FP_N.

Writes results/decision_study.json and results/figures/decision_curve.png.
All numbers measured. Run: python scripts/run_decision_study.py [--full]
"""
import argparse, json, os, sys, math, warnings, random
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"]="1"

import numpy as np, pandas as pd, torch
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from rfcd.data.stylometry import extract_matrix, extract_features, StandardizerStats, N_FEATURES
from rfcd.attacks.paraphrase import Paraphraser

ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
RES=os.path.join(ROOT,"results"); FIG=os.path.join(RES,"figures")
os.makedirs(FIG,exist_ok=True)
DEV="cuda" if torch.cuda.is_available() else "cpu"
SEED=42

def _clean(t): return " ".join(str(t).split()).strip() if isinstance(t,str) else ""

def load_hc3(n):
    import json as _j
    from huggingface_hub import hf_hub_download
    p=hf_hub_download("Hello-SimpleAI/HC3","all.jsonl",repo_type="dataset")
    ai,nat=[],[]
    for line in open(p,encoding="utf-8"):
        line=line.strip()
        if not line: continue
        ex=_j.loads(line)
        for h in ex.get("human_answers",[]) or []:
            t=_clean(h)
            if len(t.split())>=40: nat.append(t)
        for a in ex.get("chatgpt_answers",[]) or []:
            t=_clean(a)
            if len(t.split())>=40: ai.append(t)
    r=random.Random(SEED); r.shuffle(ai); r.shuffle(nat)
    return ai[:n],nat[:n]

def load_ellipse(n):
    from huggingface_hub import hf_hub_download, HfApi
    repo="tcapelle/feedback-prize-english-language-learning-fluency"
    files=HfApi().list_repo_files(repo_id=repo,repo_type="dataset")
    pq=[f for f in files if f.lower().endswith(".parquet")]; pq.sort(key=lambda f:(0 if "train" in f.lower() else 1,f))
    df=pd.read_parquet(hf_hub_download(repo,pq[0],repo_type="dataset"))
    tcol="full_text" if "full_text" in df.columns else df.columns[1]
    scols=[c for c in ["cohesion","syntax","vocabulary","phraseology","grammar","conventions"] if c in df.columns]
    df["prof"]=df["mss"] if "mss" in df.columns else df[scols].mean(axis=1)
    df["text"]=df[tcol].map(_clean)
    df=df[df["text"].str.split().map(len)>=40].reset_index(drop=True)
    return df.sample(min(n,len(df)),random_state=SEED).reset_index(drop=True)[["text","prof"]]

def build(smoke):
    n=400 if smoke else 2000
    ai,nat=load_hc3(n); esl=load_ellipse(n)
    rows=[]
    for t in ai: rows.append({"text":t,"label":1,"group":"ai","prof":np.nan})
    for t in nat: rows.append({"text":t,"label":0,"group":"native","prof":np.nan})
    for _,r in esl.iterrows(): rows.append({"text":r["text"],"label":0,"group":"esl","prof":float(r["prof"])})
    df=pd.DataFrame(rows).sample(frac=1.0,random_state=SEED).reset_index(drop=True)
    df["nwords"]=df.text.str.split().map(len)
    df["flesch"]=[extract_features(t)[20] for t in df.text]
    em=df.group=="esl"; df["band"]=np.nan
    df.loc[em,"band"]=pd.qcut(df.loc[em,"prof"],4,labels=[1,2,3,4]).astype(float)
    df["split"]="train"; rng=np.random.default_rng(SEED)
    for _,idx in df.groupby(["label","group"]).groups.items():
        idx=np.array(list(idx)); rng.shuffle(idx); m=len(idx)
        df.loc[idx[:int(m*.25)],"split"]="test"; df.loc[idx[int(m*.25):int(m*.4)],"split"]="val"
    return df

def calib(sc,y,g,t):
    m=(y==0)&(g=="native"); ns=sc[m]
    if len(ns)==0: ns=sc[y==0]
    return float(np.quantile(ns,1-t))

def rank01(x):
    x=np.asarray(x,float); o=x.argsort(); r=np.empty_like(o,float); r[o]=np.linspace(0,1,len(x)); return r

def jt(bv):
    gs=[np.array(v) for v in bv if len(v)>0]
    if len(gs)<2: return float("nan"),float("nan")
    s=0.0
    for i in range(len(gs)):
        for j in range(i+1,len(gs)):
            a=gs[i][:,None]; b=gs[j][None,:]; s+=np.sum(b>a)+0.5*np.sum(b==a)
    ns=[len(g) for g in gs]; N=sum(ns)
    mu=(N**2-sum(k*k for k in ns))/4; var=(N**2*(2*N+3)-sum(k*k*(2*k+3) for k in ns))/72
    if var<=0: return 0.0,1.0
    z=(s-mu)/math.sqrt(var); return z,float(1-stats.norm.cdf(z))

# ─── H3: four variants ──────────────────────────────────────────────────────
def run_h3(df, smoke, seeds):
    from rfcd.config import load_config, apply_smoke
    from rfcd.eval.predict import score_dataframe
    from rfcd.data.stylometry import extract_matrix as em2, StandardizerStats as SS, N_FEATURES as NF
    from rfcd.models.rfcd_model import build_model
    from rfcd.train.trainer import RFCDTrainer, VARIANTS
    from rfcd.utils import set_seed
    from transformers import AutoTokenizer
    cfg=load_config(); apply_smoke(cfg)
    cfg.model.backbone="distilbert-base-uncased"; cfg.model.max_length=192
    cfg.train.epochs=1 if smoke else 2
    variants=["vanilla","fairness_only","robustness_only","rfcd"]
    fua={v:[] for v in variants}
    for seed in seeds:
        set_seed(seed)
        tr=df[df.split=="train"].reset_index(drop=True)
        va=df[df.split=="val"].reset_index(drop=True)
        te=df[df.split=="test"].reset_index(drop=True)
        y=te.label.values; g=te.group.values
        para=Paraphraser(seed=seed+7)
        teA=te.copy(); txt=teA.text.tolist()
        for i in np.where(y==0)[0]: txt[i]=para.paraphrase(txt[i])
        teA["text"]=txt
        tok=AutoTokenizer.from_pretrained(cfg.model.backbone)
        for v in variants:
            set_seed(seed)
            stats_=SS.fit(em2(tr.text.tolist()))
            model=build_model(cfg,NF)
            tr2=tr.copy(); tr2["group_id"]=(tr2.group=="esl").astype(int)
            va2=va.copy(); va2["group_id"]=(va2.group=="esl").astype(int)
            trn=RFCDTrainer(cfg,model,tok,VARIANTS[v],DEV,paraphraser=para)
            trn.fit(tr2,va2,stats_)
            te2=te.copy(); te2["group_id"]=(te2.group=="esl").astype(int)
            teA2=teA.copy(); teA2["group_id"]=(teA2.group=="esl").astype(int)
            sc=score_dataframe(trn.model,tok,te2,stats_,cfg,DEV)
            sca=score_dataframe(trn.model,tok,teA2,stats_,cfg,DEV)
            th=calib(sc,y,g,0.05)
            def gap(s):
                e=(s[(y==0)&(g=="esl")]>=th).astype(float); n=(s[(y==0)&(g=="native")]>=th).astype(float)
                return e.mean()-n.mean()
            fua[v].append(abs(gap(sca)-gap(sc)))
            del trn, model
            if DEV=="cuda": torch.cuda.empty_cache()
    out={v:{"fua_mean":float(np.mean(fua[v])),"fua_sd":float(np.std(fua[v])),
            "by_seed":[float(x) for x in fua[v]]} for v in variants}
    rf=out["rfcd"]["fua_mean"]
    out["verdict"]=("supported" if rf<=out["fairness_only"]["fua_mean"]
                    and rf<=out["robustness_only"]["fua_mean"] else "not supported")
    return out

# ─── GPT-2 perplexity for H1/H2 + de-confound ───────────────────────────────
class PPL:
    def __init__(s): 
        from transformers import AutoTokenizer, AutoModelForCausalLM
        s.tok=AutoTokenizer.from_pretrained("gpt2")
        s.m=AutoModelForCausalLM.from_pretrained("gpt2").to(DEV).eval()
    @torch.no_grad()
    def nll(s,t):
        ids=s.tok(t,return_tensors="pt",truncation=True,max_length=192).input_ids.to(DEV)
        if ids.shape[1]<2: return 5.0
        return float(s.m(ids,labels=ids).loss.item())
    def scores(s,texts): return rank01(-np.array([s.nll(t) for t in texts]))

def h1h2_on(te, ppl, tag):
    y=te.label.values; g=te.group.values
    sc=ppl.scores(te.text.tolist())
    th=calib(sc,y,g,0.05)
    er=te[te.group=="esl"].copy(); es=sc[g=="esl"]; er=er.assign(flag=(es>=th).astype(int))
    bv=[er[er.band==b]["flag"].values for b in [1,2,3,4]]
    band=[float(v.mean()) if len(v) else float("nan") for v in bv]
    z,p=jt(bv)
    para=Paraphraser(seed=99); txt=te.text.tolist(); hidx=np.where(y==0)[0]
    for i in hidx: txt[i]=para.paraphrase(txt[i])
    sca=rank01(-np.array([ppl.nll(t) for t in txt]))
    def gap(s): 
        e=(s[(y==0)&(g=="esl")]>=th).astype(float); n=(s[(y==0)&(g=="native")]>=th).astype(float)
        return float(e.mean()-n.mean())
    return {"tag":tag,"band_fpr":band,"jt_z":z,"jt_p":p,
            "gap_clean":gap(sc),"gap_att":gap(sca),"dind":gap(sca)-gap(sc),
            "n_esl":int((g=="esl").sum()),"n_native":int((g=="native").sum())}

def deconfound(te):
    """Match ESL and native test essays on word-count tertile x flesch tertile."""
    hum=te[te.label==0].copy()
    hum["wq"]=pd.qcut(hum.nwords,3,labels=[0,1,2],duplicates="drop").astype(str)
    hum["fq"]=pd.qcut(hum.flesch,3,labels=[0,1,2],duplicates="drop").astype(str)
    hum["cell"]=hum.wq+"_"+hum.fq
    keep=[]
    for cell,grp in hum.groupby("cell"):
        ne=grp[grp.group=="esl"]; nn=grp[grp.group=="native"]
        k=min(len(ne),len(nn))
        if k>0:
            keep.append(ne.sample(k,random_state=SEED)); keep.append(nn.sample(k,random_state=SEED))
    if not keep: return te
    matched=pd.concat(keep)
    ai=te[te.label==1]
    return pd.concat([matched,ai]).reset_index(drop=True)

# ─── decision-cost / net-benefit curve ──────────────────────────────────────
def decision_curves(te, ppl, cFN=1.0, cFP_L=2.0, cFP_N=1.0):
    y=te.label.values; g=te.group.values
    sc=ppl.scores(te.text.tolist())
    ths=np.linspace(0.5,0.995,40)
    rows=[]
    nAI=(y==1).sum(); nL=((y==0)&(g=="esl")).sum(); nN=((y==0)&(g=="native")).sum()
    for th in ths:
        tp=((sc>=th)&(y==1)).sum()
        fn=((sc<th)&(y==1)).sum()
        fpL=((sc>=th)&(y==0)&(g=="esl")).sum()
        fpN=((sc>=th)&(y==0)&(g=="native")).sum()
        # net benefit (treat-style): TP/N - cost-weighted FP/N
        N=len(y)
        nb=(tp/N) - (cFP_L*fpL + cFP_N*fpN)/N - (cFN*fn/N)
        rows.append({"thr":float(th),
                     "net_benefit":float(nb),
                     "recall":float(tp/max(1,nAI)),
                     "fpr_esl":float(fpL/max(1,nL)),
                     "fpr_native":float(fpN/max(1,nN)),
                     "exp_cost":float((cFN*fn+cFP_L*fpL+cFP_N*fpN)/N)})
    return rows

def main(smoke):
    print(f"[dec] device={DEV} smoke={smoke}")
    df=build(smoke)
    te=df[df.split=="test"].reset_index(drop=True)
    print(f"[dec] test n={len(te)} esl={(te.group=='esl').sum()} native={(te.group=='native').sum()} ai={(te.label==1).sum()}")
    ppl=PPL()

    print("[dec] H1/H2 on full test ...")
    full=h1h2_on(te,ppl,"full")
    print("[dec] de-confound matching ...")
    tem=deconfound(te)
    matched=h1h2_on(tem,ppl,"length_readability_matched")
    print(f"[dec]   full      band_fpr={np.round(full['band_fpr'],3)} JT p={full['jt_p']:.4f} dind={full['dind']:.3f}")
    print(f"[dec]   matched   band_fpr={np.round(matched['band_fpr'],3)} JT p={matched['jt_p']:.4f} dind={matched['dind']:.3f} (n_esl={matched['n_esl']},n_nat={matched['n_native']})")

    print("[dec] decision curves ...")
    dc=decision_curves(te,ppl)

    print("[dec] H3 (4 variants) ...")
    seeds=[42] if smoke else [42,43,44]
    h3=run_h3(df,smoke,seeds)
    print(f"[dec]   H3 FUA: "+", ".join(f"{v}={h3[v]['fua_mean']:.4f}" for v in ['vanilla','fairness_only','robustness_only','rfcd']))
    print(f"[dec]   H3 verdict: {h3['verdict']}")

    # power/sensitivity note for the REAL main-study sizes
    nL=full["n_esl"]; nN=full["n_native"]
    per_band=nL//4
    power_note={"H1_per_band_actual":int(per_band),"H2_per_group_actual":int(min(nL,nN)),
                "note":"actual main-study sizes; smaller than the planned 250/band and 1000/group"}

    out={"design":{"n_test":len(te),"n_esl":nL,"n_native":nN,
                   "n_ai":int((te.label==1).sum())},
         "H1_H2_full":full,"H1_H2_matched":matched,
         "H3":h3,"decision_curve":dc,"power_actual":power_note,
         "cost_model":{"c_FN":1.0,"c_FP_learner":2.0,"c_FP_native":1.0,
                       "rationale":"false flag on a learner carries higher institutional cost"}}
    path=os.path.join(RES,"decision_study.json")
    json.dump(out,open(path,"w"),indent=2,default=float)
    print(f"[dec] saved {path}")

    # figure: decision curve (net benefit) + fpr by group
    ths=[r["thr"] for r in dc]
    fig,(ax1,ax2)=plt.subplots(1,2,figsize=(11,4.2))
    ax1.plot(ths,[r["net_benefit"] for r in dc],color="#1565C0",lw=2.2,label="Net benefit")
    ax1.plot(ths,[-r["exp_cost"] for r in dc],color="#C62828",lw=1.8,ls="--",label="-Expected cost")
    ax1.set_xlabel("Flagging threshold"); ax1.set_ylabel("Net benefit (per essay)")
    ax1.set_title("Decision curve: net benefit vs threshold"); ax1.legend(fontsize=9); ax1.grid(alpha=.3)
    ax2.plot(ths,[r["fpr_native"] for r in dc],color="#2E7D32",lw=2,label="Native FPR")
    ax2.plot(ths,[r["fpr_esl"] for r in dc],color="#C62828",lw=2,label="Learner FPR")
    ax2.plot(ths,[r["recall"] for r in dc],color="#555",lw=1.5,ls=":",label="AI recall")
    ax2.set_xlabel("Flagging threshold"); ax2.set_ylabel("Rate")
    ax2.set_title("Group FPR and AI recall vs threshold"); ax2.legend(fontsize=9); ax2.grid(alpha=.3)
    fig.suptitle("Risk-calibrated flagging decision (GPT-2 perplexity detector, real data)",fontweight="bold")
    fig.tight_layout()
    fp=os.path.join(FIG,"decision_curve.png"); fig.savefig(fp,dpi=150); plt.close(fig)
    print(f"[dec] saved {fp}")

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--full",action="store_true")
    a=ap.parse_args(); main(smoke=not a.full)
