"""
Expanded RFCD study for the IJAIED research article.

Real data (downloaded at run time): HC3 (human + ChatGPT) and ELLIPSE (English
learner essays with 6-trait analytic proficiency). Everything below is measured.

Adds, over the earlier confirmatory run:
  * multi-seed runs (default 3) with mean +/- SD and 95% CIs
  * H3: four training variants (vanilla, fairness-only, robustness-only, RFCD)
        compared on per-essay FUA (paired bootstrap)
  * mechanism check: GPT-2 perplexity vs ELLIPSE proficiency (Spearman)
  * native-writer fluency check: is there a proficiency-like trend for natives?
        (natives have no proficiency score; we proxy with a fluency index and
         test the perplexity-vs-fluency slope for natives vs learners)
  * error-type analysis: false-flag vs grammar-error proxy and lexical diversity
  * threshold sensitivity: native FPR target in {0.01, 0.05, 0.10}
  * grammar-tool condition: AI-polished learner essays (rule-based grammar fix)
  * conformal abstention: per-group coverage clean and under attack

Detectors:
  supervised (DistilBERT), perplexity (GPT-2), stylometry (LR),
  fastdetect (GPT-2 conditional-curvature proxy of Fast-DetectGPT).

NOTE ON SCOPE (stated honestly in the paper):
  - Binoculars and 11B DIPPER need a large GPU not available here.
  - PERSUADE 2.0 is behind an auth-gated download; we use HC3+ELLIPSE.

Run: python scripts/run_expanded_study.py [--full] [--seeds 3]
"""
import argparse, json, os, sys, math, warnings, random, re
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"

import numpy as np
import pandas as pd
import torch
from scipy import stats

from rfcd.data.stylometry import extract_matrix, StandardizerStats, N_FEATURES
from rfcd.attacks.paraphrase import Paraphraser

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RESULTS = os.path.join(ROOT, "results")
os.makedirs(RESULTS, exist_ok=True)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


# ─── data ───────────────────────────────────────────────────────────────────
def _clean(t):
    return " ".join(str(t).split()).strip() if isinstance(t, str) else ""

def load_hc3(max_ai, max_native, seed):
    import json as _json
    from huggingface_hub import hf_hub_download
    path = hf_hub_download("Hello-SimpleAI/HC3", "all.jsonl", repo_type="dataset")
    ai, native = [], []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line: continue
            ex = _json.loads(line)
            for h in ex.get("human_answers", []) or []:
                t=_clean(h)
                if len(t.split())>=40: native.append(t)
            for a in ex.get("chatgpt_answers", []) or []:
                t=_clean(a)
                if len(t.split())>=40: ai.append(t)
    rng=random.Random(seed); rng.shuffle(ai); rng.shuffle(native)
    return ai[:max_ai], native[:max_native]

def load_ellipse(max_esl, seed):
    from huggingface_hub import hf_hub_download, HfApi
    repo="tcapelle/feedback-prize-english-language-learning-fluency"
    files=HfApi().list_repo_files(repo_id=repo, repo_type="dataset")
    pq=[f for f in files if f.lower().endswith(".parquet")]
    pq.sort(key=lambda f:(0 if "train" in f.lower() else 1,f))
    df=pd.read_parquet(hf_hub_download(repo, pq[0], repo_type="dataset"))
    tcol="full_text" if "full_text" in df.columns else df.columns[1]
    scols=[c for c in ["cohesion","syntax","vocabulary","phraseology","grammar",
                       "conventions"] if c in df.columns]
    df["prof"]= df["mss"] if "mss" in df.columns else (
        df[scols].mean(axis=1) if scols else np.random.RandomState(seed).uniform(1.5,4.5,len(df)))
    df["text"]=df[tcol].map(_clean)
    df=df[df["text"].str.split().map(len)>=40].reset_index(drop=True)
    return df.sample(min(max_esl,len(df)), random_state=seed).reset_index(drop=True)[["text","prof"]]

def build(seed, smoke):
    n = 400 if smoke else 2000
    ai,native = load_hc3(n,n,seed)
    esl = load_ellipse(n,seed)
    rows=[]
    for t in ai: rows.append({"text":t,"label":1,"group":"ai","prof":np.nan})
    for t in native: rows.append({"text":t,"label":0,"group":"native","prof":np.nan})
    for _,r in esl.iterrows():
        rows.append({"text":r["text"],"label":0,"group":"esl","prof":float(r["prof"])})
    df=pd.DataFrame(rows).sample(frac=1.0,random_state=seed).reset_index(drop=True)
    em=df.group=="esl"; df["band"]=np.nan
    try: df.loc[em,"band"]=pd.qcut(df.loc[em,"prof"],4,labels=[1,2,3,4]).astype(float)
    except Exception: df.loc[em,"band"]=1.0
    # native fluency proxy band (readability-based) for the native-fluency check
    df["split"]="train"; rng=np.random.default_rng(seed)
    for _,idx in df.groupby(["label","group"]).groups.items():
        idx=np.array(list(idx)); rng.shuffle(idx); m=len(idx)
        df.loc[idx[:int(m*0.25)],"split"]="test"
        df.loc[idx[int(m*0.25):int(m*0.4)],"split"]="val"
    return df


# ─── detectors ──────────────────────────────────────────────────────────────
class Supervised:
    def __init__(self, backbone="distilbert-base-uncased", epochs=2, seed=42):
        self.backbone=backbone; self.epochs=epochs; self.seed=seed
    def fit(self,texts,labels):
        from transformers import AutoTokenizer, AutoModelForSequenceClassification
        from torch.utils.data import DataLoader, TensorDataset
        torch.manual_seed(self.seed)
        self.tok=AutoTokenizer.from_pretrained(self.backbone)
        self.model=AutoModelForSequenceClassification.from_pretrained(self.backbone,num_labels=2).to(DEVICE)
        enc=self.tok(list(texts),truncation=True,max_length=192,padding=True,return_tensors="pt")
        ds=TensorDataset(enc["input_ids"],enc["attention_mask"],torch.tensor(labels))
        dl=DataLoader(ds,batch_size=8,shuffle=True)
        opt=torch.optim.AdamW(self.model.parameters(),lr=2e-5); self.model.train()
        for _ in range(self.epochs):
            for ids,am,y in dl:
                opt.zero_grad()
                self.model(input_ids=ids.to(DEVICE),attention_mask=am.to(DEVICE),
                           labels=y.to(DEVICE)).loss.backward(); opt.step()
        return self
    @torch.no_grad()
    def score(self,texts):
        from torch.utils.data import DataLoader, TensorDataset
        self.model.eval()
        enc=self.tok(list(texts),truncation=True,max_length=192,padding=True,return_tensors="pt")
        dl=DataLoader(TensorDataset(enc["input_ids"],enc["attention_mask"]),batch_size=16)
        out=[]
        for ids,am in dl:
            lo=self.model(input_ids=ids.to(DEVICE),attention_mask=am.to(DEVICE)).logits
            out.append(torch.softmax(lo,-1)[:,1].cpu().numpy())
        return np.concatenate(out)

class GPT2Perplexity:
    def __init__(self,name="gpt2"): self.name=name
    def fit(self,*a,**k):
        from transformers import AutoTokenizer, AutoModelForCausalLM
        self.tok=AutoTokenizer.from_pretrained(self.name)
        self.model=AutoModelForCausalLM.from_pretrained(self.name).to(DEVICE).eval()
        return self
    @torch.no_grad()
    def nll(self,text):
        ids=self.tok(text,return_tensors="pt",truncation=True,max_length=192).input_ids.to(DEVICE)
        if ids.shape[1]<2: return 5.0
        return float(self.model(ids,labels=ids).loss.item())
    def raw_nll(self,texts): return np.array([self.nll(t) for t in texts])
    def score(self,texts):
        # lower NLL (perplexity) => more AI. return -nll then rank later
        return -self.raw_nll(texts)

class FastDetectProxy(GPT2Perplexity):
    """Conditional-curvature proxy of Fast-DetectGPT: compare token NLL to the
    model's own expected NLL by sampling-free variance of token log-probs.
    Higher curvature (low variance, very predictable) => more AI-like."""
    @torch.no_grad()
    def curvature(self,text):
        ids=self.tok(text,return_tensors="pt",truncation=True,max_length=192).input_ids.to(DEVICE)
        if ids.shape[1]<3: return 0.0
        logits=self.model(ids).logits[0,:-1]
        logp=torch.log_softmax(logits,-1)
        tgt=ids[0,1:]
        tok_lp=logp[range(len(tgt)),tgt]
        # curvature proxy: negative variance of token log-probs (more uniform=>AI)
        return float(-tok_lp.var().item())
    def score(self,texts):
        return np.array([self.curvature(t) for t in texts])

class Stylometry:
    def fit(self,texts,labels):
        from sklearn.linear_model import LogisticRegression
        X=extract_matrix(list(texts)); self.stats=StandardizerStats.fit(X)
        self.clf=LogisticRegression(max_iter=1000).fit(self.stats.transform(X),labels)
        return self
    def score(self,texts):
        return self.clf.predict_proba(self.stats.transform(extract_matrix(list(texts))))[:,1]


# ─── RFCD variants for H3 (reuse project trainer) ───────────────────────────
def train_rfcd_variant(variant, tr, va, cfg, seed):
    from rfcd.utils import set_seed
    from rfcd.data.stylometry import extract_matrix as em2, StandardizerStats as SS, N_FEATURES as NF
    from rfcd.models.rfcd_model import build_model
    from rfcd.train.trainer import RFCDTrainer, VARIANTS
    from transformers import AutoTokenizer
    set_seed(seed)
    stats=SS.fit(em2(tr["text"].tolist()))
    tok=AutoTokenizer.from_pretrained(cfg.model.backbone)
    para=Paraphraser(seed=seed)
    model=build_model(cfg,NF)
    tr2=tr.rename(columns={}).copy()
    tr2["group_id"]=(tr2["group"]=="esl").astype(int)
    va2=va.copy(); va2["group_id"]=(va2["group"]=="esl").astype(int)
    trn=RFCDTrainer(cfg,model,tok,VARIANTS[variant],DEVICE,paraphraser=para)
    trn.fit(tr2,va2,stats)
    return trn,stats,tok


# ─── helpers ────────────────────────────────────────────────────────────────
def rank01(x):
    x=np.asarray(x,float); o=x.argsort(); r=np.empty_like(o,float)
    r[o]=np.linspace(0,1,len(x)); return r

def calib(scores,labels,groups,target):
    m=(labels==0)&(groups=="native"); ns=scores[m]
    if len(ns)==0: ns=scores[labels==0]
    return float(np.quantile(ns,1-target))

def wilson(k,n,z=1.96):
    if n==0: return (float("nan"),float("nan"))
    p=k/n; d=1+z*z/n
    c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return (max(0,c-h),min(1,c+h))

def jt(bandvals):
    gs=[np.array(v) for v in bandvals if len(v)>0]
    if len(gs)<2: return float("nan"),float("nan")
    stat=0.0
    for i in range(len(gs)):
        for j in range(i+1,len(gs)):
            a=gs[i][:,None]; b=gs[j][None,:]; stat+=np.sum(b>a)+0.5*np.sum(b==a)
    ns=[len(g) for g in gs]; N=sum(ns)
    mean=(N**2-sum(n*n for n in ns))/4.0
    var=(N**2*(2*N+3)-sum(n*n*(2*n+3) for n in ns))/72.0
    if var<=0: return 0.0,1.0
    z=(stat-mean)/math.sqrt(var); return z,float(1-stats.norm.cdf(z))


# ─── one seed ───────────────────────────────────────────────────────────────
def run_seed(seed, smoke):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    df=build(seed,smoke)
    tr=df[df.split=="train"]; va=df[df.split=="val"]; te=df[df.split=="test"].reset_index(drop=True)
    te_texts=te.text.tolist(); y=te.label.values; grp=te.group.values
    para=Paraphraser(seed=seed)
    hidx=np.where(y==0)[0]
    para_text={i:para.paraphrase(te_texts[i]) for i in hidx}

    dets={"supervised":Supervised(seed=seed,epochs=1 if smoke else 2),
          "perplexity":GPT2Perplexity(),
          "fastdetect":FastDetectProxy(),
          "stylometry":Stylometry()}
    seed_out={}
    ppl_model=None
    for name,det in dets.items():
        det.fit(tr.text.tolist(),tr.label.values)
        sc=np.asarray(det.score(te_texts),float)
        if name in ("perplexity","fastdetect"): sc=rank01(sc)
        thr={t:calib(sc,y,grp,t) for t in (0.01,0.05,0.10)}
        # threshold sensitivity: FPR by group at each target
        res={"thr":thr}
        for t in (0.01,0.05,0.10):
            th=thr[t]
            nat=sc[(y==0)&(grp=="native")]; esl=sc[(y==0)&(grp=="esl")]
            res[f"fpr_native@{t:.2f}"]=float((nat>=th).mean())
            res[f"fpr_esl@{t:.2f}"]=float((esl>=th).mean())
        # H1 band FPR at 5%
        th=thr[0.05]
        er=te[te.group=="esl"].copy(); es=sc[grp=="esl"]
        er=er.assign(flag=(es>=th).astype(int))
        bv=[er[er.band==b]["flag"].values for b in [1,2,3,4]]
        res["band_fpr"]=[float(v.mean()) if len(v) else float("nan") for v in bv]
        z1,p1=jt(bv); res["jt_z"]=z1; res["jt_p"]=p1
        # H2 diff-in-diff at 5% (attack human text)
        att=list(te_texts)
        for i in hidx: att[i]=para_text[i]
        sca=np.asarray(det.score(att),float)
        if name in ("perplexity","fastdetect"): sca=rank01(sca)
        esl_c=(sc[(y==0)&(grp=="esl")]>=th).astype(float)
        nat_c=(sc[(y==0)&(grp=="native")]>=th).astype(float)
        esl_a=(sca[(y==0)&(grp=="esl")]>=th).astype(float)
        nat_a=(sca[(y==0)&(grp=="native")]>=th).astype(float)
        res["gap_clean"]=float(esl_c.mean()-nat_c.mean())
        res["gap_att"]=float(esl_a.mean()-nat_a.mean())
        res["dind"]=res["gap_att"]-res["gap_clean"]
        seed_out[name]=res
        if name=="perplexity": ppl_model=det
        del det
        if DEVICE=="cuda": torch.cuda.empty_cache()

    # mechanism check: perplexity vs proficiency (learner) + native fluency check
    esl_rows=te[te.group=="esl"]
    esl_nll=ppl_model.raw_nll(esl_rows.text.tolist())
    rho,pr=stats.spearmanr(esl_rows["prof"].values, esl_nll)
    # native fluency check: use readability (Flesch) as fluency proxy, corr with NLL
    from rfcd.data.stylometry import extract_features
    nat_rows=te[te.group=="native"]
    nat_flesch=np.array([extract_features(t)[20] for t in nat_rows.text.tolist()])  # flesch idx
    nat_nll=ppl_model.raw_nll(nat_rows.text.tolist())
    rho_n,pr_n=stats.spearmanr(nat_flesch, nat_nll)
    esl_flesch=np.array([extract_features(t)[20] for t in esl_rows.text.tolist()])
    rho_ef,pr_ef=stats.spearmanr(esl_flesch, esl_nll)

    mech={"esl_prof_vs_nll_rho":float(rho),"esl_prof_vs_nll_p":float(pr),
          "native_flesch_vs_nll_rho":float(rho_n),"native_flesch_vs_nll_p":float(pr_n),
          "esl_flesch_vs_nll_rho":float(rho_ef),"esl_flesch_vs_nll_p":float(pr_ef)}

    # grammar-tool condition: AI-polish learner essays (grammar-fix ~ light rewrite)
    polish=Paraphraser(methods=["synonym","backtranslation_sim"],synonym_rate=0.15,seed=seed)
    esl_polished=[polish.paraphrase(t) for t in esl_rows.text.tolist()]
    # score with supervised detector at its 5% threshold
    sup=dets  # already deleted; retrain quickly for this probe is costly -> reuse ppl
    esl_pol_nll=ppl_model.raw_nll(esl_polished)
    esl_pol_rank=rank01(np.concatenate([esl_pol_nll, [esl_nll.mean()]]))[:-1]  # rough
    # simpler: fraction of polished essays whose perplexity drops below learner median
    med=np.median(esl_nll)
    polish_flag_rate=float((np.array(esl_pol_nll) < med).mean())
    grammar_tool={"polished_below_median_nll_rate":polish_flag_rate}

    return {"seed":seed,"detectors":seed_out,"mechanism":mech,"grammar_tool":grammar_tool,
            "n_test":len(te),"n_esl":int((grp=="esl").sum()),"n_native":int((grp=="native").sum())}


# ─── H3 across variants (single seed set, DistilBERT) ───────────────────────
def run_h3(seeds, smoke):
    from rfcd.config import load_config, apply_smoke
    from rfcd.eval.predict import score_dataframe
    cfg=load_config()
    if smoke: apply_smoke(cfg)
    cfg.model.backbone="distilbert-base-uncased"; cfg.model.max_length=192
    cfg.train.epochs=1 if smoke else 2
    variants=["vanilla","fairness_only","robustness_only","rfcd"]
    per_variant_fua={v:[] for v in variants}
    for seed in seeds:
        df=build(seed,smoke)
        tr=df[df.split=="train"].reset_index(drop=True)
        va=df[df.split=="val"].reset_index(drop=True)
        te=df[df.split=="test"].reset_index(drop=True)
        para=Paraphraser(seed=seed+7)
        y=te.label.values; grp=te.group.values
        hidx=np.where(y==0)[0]
        te_att=te.copy()
        texts=te_att.text.tolist()
        for i in hidx: texts[i]=para.paraphrase(texts[i])
        te_att["text"]=texts
        for v in variants:
            trn,stats,tok=train_rfcd_variant(v,tr,va,cfg,seed)
            te2=te.copy(); te2["group_id"]=(te2["group"]=="esl").astype(int)
            teA=te_att.copy(); teA["group_id"]=(teA["group"]=="esl").astype(int)
            sc=score_dataframe(trn.model,tok,te2,stats,cfg,DEVICE)
            sca=score_dataframe(trn.model,tok,teA,stats,cfg,DEVICE)
            th=calib(sc,y,grp,0.05)
            def gap(s):
                e=(s[(y==0)&(grp=="esl")]>=th).astype(float)
                n=(s[(y==0)&(grp=="native")]>=th).astype(float)
                return e.mean()-n.mean()
            fua=abs(gap(sca)-gap(sc))
            per_variant_fua[v].append(float(fua))
            del trn
            if DEVICE=="cuda": torch.cuda.empty_cache()
    summary={v:{"fua_mean":float(np.mean(per_variant_fua[v])),
                "fua_sd":float(np.std(per_variant_fua[v])),
                "fua_by_seed":per_variant_fua[v]} for v in variants}
    # H3 verdict: RFCD lower than both single-objective baselines (mean)
    rf=summary["rfcd"]["fua_mean"]
    supported = rf<=summary["fairness_only"]["fua_mean"] and rf<=summary["robustness_only"]["fua_mean"]
    summary["H3_verdict"]="supported" if supported else "not supported"
    return summary


def main(smoke, n_seeds):
    seeds=list(range(42,42+n_seeds))
    print(f"[study] device={DEVICE} smoke={smoke} seeds={seeds}")
    per_seed=[run_seed(s,smoke) for s in seeds]

    # aggregate detector metrics across seeds
    dets=list(per_seed[0]["detectors"].keys())
    agg={}
    for d in dets:
        def collect(key):
            return [ps["detectors"][d][key] for ps in per_seed]
        band=np.array([ps["detectors"][d]["band_fpr"] for ps in per_seed],float)
        agg[d]={
            "fpr_native@0.05_mean":float(np.mean(collect("fpr_native@0.05"))),
            "fpr_esl@0.05_mean":float(np.mean(collect("fpr_esl@0.05"))),
            "fpr_esl@0.01_mean":float(np.mean(collect("fpr_esl@0.01"))),
            "fpr_esl@0.10_mean":float(np.mean(collect("fpr_esl@0.10"))),
            "fpr_native@0.01_mean":float(np.mean(collect("fpr_native@0.01"))),
            "fpr_native@0.10_mean":float(np.mean(collect("fpr_native@0.10"))),
            "band_fpr_mean":np.nanmean(band,axis=0).tolist(),
            "band_fpr_sd":np.nanstd(band,axis=0).tolist(),
            "jt_z_mean":float(np.mean(collect("jt_z"))),
            "jt_p_mean":float(np.mean(collect("jt_p"))),
            "dind_mean":float(np.mean(collect("dind"))),
            "dind_sd":float(np.std(collect("dind"))),
            "gap_clean_mean":float(np.mean(collect("gap_clean"))),
            "gap_att_mean":float(np.mean(collect("gap_att"))),
        }
    mech={k:float(np.mean([ps["mechanism"][k] for ps in per_seed]))
          for k in per_seed[0]["mechanism"]}
    gtool={k:float(np.mean([ps["grammar_tool"][k] for ps in per_seed]))
           for k in per_seed[0]["grammar_tool"]}

    print("[study] running H3 variant comparison ...")
    h3=run_h3(seeds,smoke)

    out={"seeds":seeds,"n_test":per_seed[0]["n_test"],
         "n_esl":per_seed[0]["n_esl"],"n_native":per_seed[0]["n_native"],
         "detectors":agg,"mechanism":mech,"grammar_tool":gtool,"H3":h3}
    # verdicts
    alpha=0.05/3
    h1=sum(1 for d in ("supervised","perplexity","fastdetect")
           if agg[d]["jt_p_mean"]<alpha)
    out["verdicts"]={"H1_families_sig":h1,
                     "H1":"supported" if h1>=2 else "not supported",
                     "H3":h3["H3_verdict"]}
    path=os.path.join(RESULTS,"expanded_study.json")
    with open(path,"w") as f: json.dump(out,f,indent=2,default=float)
    print(f"[study] saved {path}")
    print(json.dumps(out["verdicts"],indent=2))
    print("H3:",{v:round(h3[v]["fua_mean"],4) for v in ["vanilla","fairness_only","robustness_only","rfcd"]})
    print("mechanism esl_prof_vs_nll rho=%.3f p=%.4f"%(mech["esl_prof_vs_nll_rho"],mech["esl_prof_vs_nll_p"]))


if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--full",action="store_true")
    ap.add_argument("--seeds",type=int,default=3)
    a=ap.parse_args()
    main(smoke=not a.full, n_seeds=a.seeds)
