"""Make the real fluency-penalty figure from confirmatory.json."""
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
with open(os.path.join(ROOT, "results", "confirmatory.json")) as f:
    R = json.load(f)

bands = ["Q1\n(Low)", "Q2\n(Med-Low)", "Q3\n(Med-High)", "Q4\n(High)"]
x = np.arange(4)
colors = {"supervised": "#C62828", "perplexity": "#1565C0", "stylometry": "#2E7D32"}
markers = {"supervised": "o", "perplexity": "D", "stylometry": "^"}
names = {"supervised": "Supervised (RoBERTa/DistilBERT)",
         "perplexity": "Zero-shot perplexity (GPT-2)",
         "stylometry": "Stylometry + logistic reg."}

fig, ax = plt.subplots(figsize=(8, 5))
for det, d in R["detectors"].items():
    y = d["H1_band_fpr"]
    p = d["H1_jt_p_onesided"]
    ax.plot(x, y, marker=markers[det], color=colors[det], lw=2.2, markersize=8,
            label=f"{names[det]} (JT p={p:.3f})")
ax.axhline(0.05, color="grey", lw=1, ls=":", label="5% native FPR target")
ax.set_xticks(x); ax.set_xticklabels(bands, fontsize=10)
ax.set_ylabel("False-positive rate (ESL essay flagged as AI)", fontsize=11)
ax.set_xlabel("ESL writing-proficiency quartile (ELLIPSE analytic score)", fontsize=11)
ax.set_title("Fluency penalty on real data (n=500 ESL test essays)\n"
             "HC3 + ELLIPSE; threshold calibrated to 5% native FPR", fontsize=12)
ax.legend(fontsize=9); ax.grid(alpha=0.3); ax.set_ylim(-0.02, 0.32)
fig.tight_layout()
out = os.path.join(ROOT, "results", "figures", "fluency_penalty_confirmatory.png")
fig.savefig(out, dpi=150)
print("saved", out)
