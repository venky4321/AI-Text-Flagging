"""Step 2: train RFCD and its ablation baselines on the prepared data.

Trains four variants by default (vanilla, fairness_only, robustness_only, rfcd),
each saved as a checkpoint under checkpoints/. Stylometry standardizer stats are
fit on the training split and reused everywhere.

Usage:
    python scripts/02_train.py                       # all variants, full data
    python scripts/02_train.py --smoke               # tiny/fast
    python scripts/02_train.py --variants rfcd vanilla
"""
import argparse
import os

import _bootstrap  # noqa: F401

from rfcd.config import load_config, apply_smoke
from rfcd.utils import set_seed, get_device, ensure_dir, save_json
from rfcd.data.build_dataset import load_saved
from rfcd.data.stylometry import extract_matrix, StandardizerStats
from rfcd.attacks.paraphrase import Paraphraser
from rfcd.models.rfcd_model import build_model
from rfcd.train.trainer import RFCDTrainer, VARIANTS


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--variants", nargs="*", default=list(VARIANTS.keys()))
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.smoke:
        apply_smoke(cfg)
    set_seed(cfg.seed)
    device = get_device()
    print(f"[train] device={device} backbone={cfg.model.backbone}")

    df = load_saved(cfg, smoke=args.smoke)
    train_df = df[df.split == "train"].reset_index(drop=True)
    val_df = df[df.split == "val"].reset_index(drop=True)

    # fit stylometry standardizer on TRAIN texts only
    print("[train] Fitting stylometry standardizer on train split ...")
    train_matrix = extract_matrix(train_df["text"].tolist())
    style_stats = StandardizerStats.fit(train_matrix)

    from rfcd.data.stylometry import N_FEATURES
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(cfg.model.backbone)
    paraphraser = Paraphraser(
        methods=list(cfg.attacks.methods),
        synonym_rate=cfg.attacks.synonym_rate,
        seed=cfg.seed,
    )

    ckpt_dir = ensure_dir(cfg.paths.checkpoint_dir)
    suffix = "_smoke" if args.smoke else ""
    histories = {}

    for vname in args.variants:
        if vname not in VARIANTS:
            print(f"[train] unknown variant '{vname}', skipping")
            continue
        print(f"\n{'='*60}\n[train] Training variant: {vname}\n{'='*60}")
        set_seed(cfg.seed)  # same init across variants for fair comparison
        model = build_model(cfg, n_style_features=N_FEATURES)
        trainer = RFCDTrainer(cfg, model, tokenizer, VARIANTS[vname], device,
                              paraphraser=paraphraser)
        hist = trainer.fit(train_df, val_df, style_stats)
        histories[vname] = hist
        trainer.save(os.path.join(ckpt_dir, f"{vname}{suffix}.pt"))

    save_json(
        {"histories": histories, "style_stats": style_stats.to_dict()},
        os.path.join(cfg.paths.results_dir, f"train_history{suffix}.json"),
    )
    print("\n[train] Done. Checkpoints in", ckpt_dir)


if __name__ == "__main__":
    main()
