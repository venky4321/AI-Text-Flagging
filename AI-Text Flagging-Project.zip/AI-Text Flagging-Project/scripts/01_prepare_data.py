"""Step 1: download real datasets from the internet and build the unified dataset.

Usage:
    python scripts/01_prepare_data.py            # full data
    python scripts/01_prepare_data.py --smoke    # tiny subset, fast
"""
import argparse

import _bootstrap  # noqa: F401

from rfcd.config import load_config, apply_smoke
from rfcd.utils import set_seed
from rfcd.data.build_dataset import build_and_save


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--smoke", action="store_true", help="small fast subset")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.smoke:
        apply_smoke(cfg)
    set_seed(cfg.seed)
    build_and_save(cfg, smoke=args.smoke)


if __name__ == "__main__":
    main()
