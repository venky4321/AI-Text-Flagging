"""Step 3: evaluate every trained variant on clean and paraphrase-attacked test set.

Produces:
    results/metrics{suffix}.json           - full nested metrics per variant
    results/summary{suffix}.csv            - paper-ready table
    results/fairness_under_attack{suffix}.csv
    results/figures/*.png                  - FPR-by-group, fairness-under-attack, ROC

Usage:
    python scripts/03_evaluate.py [--smoke] [--variants rfcd vanilla ...]
"""
import argparse
import os

import _bootstrap  # noqa: F401

import numpy as np
import pandas as pd

from rfcd.config import load_config, apply_smoke
from rfcd.utils import set_seed, get_device, save_json, ensure_dir
from rfcd.data.build_dataset import load_saved
from rfcd.data.stylometry import StandardizerStats, N_FEATURES
from rfcd.attacks.paraphrase import Paraphraser
from rfcd.models.rfcd_model import build_model
from rfcd.eval.predict import score_dataframe
from rfcd.eval.metrics import evaluate_split, summarize_for_paper
from rfcd.report.figures import make_all_figures


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--variants", nargs="*", default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.smoke:
        apply_smoke(cfg)
    set_seed(cfg.seed)
    device = get_device()
    suffix = "_smoke" if args.smoke else ""

    df = load_saved(cfg, smoke=args.smoke)
    test_df = df[df.split == "test"].reset_index(drop=True)
    labels = test_df["label"].to_numpy()
    groups = test_df["group"].to_numpy()

    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(cfg.model.backbone)
    paraphraser = Paraphraser(
        methods=list(cfg.attacks.methods),
        synonym_rate=cfg.attacks.synonym_rate,
        seed=cfg.seed + 1,  # different seed than training-time paraphraser
    )

    ckpt_dir = cfg.paths.checkpoint_dir
    import torch

    variants = args.variants
    if variants is None:
        variants = [
            f[:-len(suffix + ".pt")] if suffix else f[:-3]
            for f in os.listdir(ckpt_dir)
            if f.endswith(f"{suffix}.pt") and (suffix or "_smoke" not in f)
        ]
        variants = sorted(set(variants))
    print(f"[eval] variants: {variants}")

    all_results = {}
    for vname in variants:
        ckpt_path = os.path.join(ckpt_dir, f"{vname}{suffix}.pt")
        if not os.path.exists(ckpt_path):
            print(f"[eval] missing checkpoint {ckpt_path}, skipping")
            continue
        print(f"[eval] Evaluating {vname} ...")
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        style_stats = StandardizerStats.from_dict(ckpt["style_stats"])
        model = build_model(cfg, n_style_features=N_FEATURES).to(device)
        model.load_state_dict(ckpt["model_state"])

        scores_clean = score_dataframe(model, tokenizer, test_df, style_stats,
                                       cfg, device, paraphraser=None)
        scores_att = score_dataframe(model, tokenizer, test_df, style_stats,
                                     cfg, device, paraphraser=paraphraser)

        res = evaluate_split(scores_clean, scores_att, labels, groups,
                             fpr_target=cfg.eval.fpr_target)
        # keep scores for ROC figure
        res["_scores_clean"] = scores_clean.tolist()
        all_results[vname] = res

    # ---- save metrics ----
    results_dir = ensure_dir(cfg.paths.results_dir)
    clean_results = {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")}
                     for k, v in all_results.items()}
    save_json(clean_results, os.path.join(results_dir, f"metrics{suffix}.json"))

    # ---- paper summary table ----
    rows = summarize_for_paper(clean_results)
    summary = pd.DataFrame(rows)
    summary.to_csv(os.path.join(results_dir, f"summary{suffix}.csv"), index=False)
    print("\n[eval] Summary table:\n")
    print(summary.to_string(index=False))

    # ---- fairness-under-attack table ----
    fua_rows = []
    for vname, res in clean_results.items():
        fua = res.get("fairness_under_attack", {})
        if fua:
            fua_rows.append({"variant": vname, **fua})
    if fua_rows:
        pd.DataFrame(fua_rows).to_csv(
            os.path.join(results_dir, f"fairness_under_attack{suffix}.csv"),
            index=False,
        )

    # ---- figures ----
    try:
        fig_dir = ensure_dir(os.path.join(results_dir, "figures"))
        make_all_figures(all_results, labels, fig_dir, suffix)
        print(f"[eval] Figures written to {fig_dir}")
    except Exception as exc:  # noqa: BLE001
        print(f"[eval] Figure generation skipped: {exc}")

    print("\n[eval] Done.")


if __name__ == "__main__":
    main()
