"""
Build the JIDMIS research article (DOCX) from real result files.
Research-article structure, named authors, honest claims, numbered cost
equations, abstention + cost-sensitivity + TOPSIS results, clean references.

Run: python scripts/build_paper.py
Output: paper/RFCD_Scientific_Reports_Paper.docx
"""
from __future__ import annotations
import io, json, os, sys, math
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
FIG=os.path.join(ROOT,"results","figures")
OUT_DIR=os.path.join(ROOT,"paper"); os.makedirs(OUT_DIR,exist_ok=True)

def _load(name):
    p=os.path.join(ROOT,"results",name)
    return json.load(open(p)) if os.path.exists(p) else None
CONF=_load("confirmatory.json")
DEC =_load("decision_study_final.json")
DA  =_load("decision_analytics.json")

def svg_png(path,w=900):
    try:
        import cairosvg; return cairosvg.svg2png(url=path,output_width=w)
    except Exception:
        try:
            from PIL import Image; b=io.BytesIO(); Image.new("RGB",(w,640),(255,255,255)).save(b,"PNG"); return b.getvalue()
        except Exception: return b""

def _h(doc,t,level=1):
    p=doc.add_heading(t,level=level); p.alignment=WD_ALIGN_PARAGRAPH.LEFT; return p
def _p(doc,t,bold=False,italic=False):
    pa=doc.add_paragraph(); pa.paragraph_format.space_after=Pt(4); pa.paragraph_format.space_before=Pt(2)
    r=pa.add_run(t); r.bold=bold; r.italic=italic; r.font.size=Pt(11); return pa
def _box(doc,t,color=(0x1a,0x23,0x7e)):
    pa=doc.add_paragraph(); pa.paragraph_format.left_indent=Inches(0.3); pa.paragraph_format.right_indent=Inches(0.3)
    pa.paragraph_format.space_before=Pt(6); pa.paragraph_format.space_after=Pt(6)
    r=pa.add_run(t); r.bold=True; r.font.size=Pt(11); r.font.color.rgb=RGBColor(*color)
def _eq(doc,t):
    pa=doc.add_paragraph(); pa.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=pa.add_run(t); r.italic=True; r.font.size=Pt(11)
def _bullet(doc,t):
    pa=doc.add_paragraph(style="List Bullet"); pa.paragraph_format.space_after=Pt(2); pa.add_run(t).font.size=Pt(11)
def _fig(doc,path,cap,w=5.5,svg=False):
    pa=doc.add_paragraph(); pa.alignment=WD_ALIGN_PARAGRAPH.CENTER
    if svg:
        d=svg_png(path)
        if d: pa.add_run().add_picture(io.BytesIO(d),width=Inches(w))
    elif os.path.exists(path):
        pa.add_run().add_picture(path,width=Inches(w))
    c=doc.add_paragraph(); c.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=c.add_run(cap); r.bold=True; r.font.size=Pt(10); r.font.color.rgb=RGBColor(0x33,0x33,0x33); doc.add_paragraph()
def _tbl(doc,headers,rows,cap):
    c=doc.add_paragraph(); c.add_run(cap).bold=True; c.runs[0].font.size=Pt(10)
    t=doc.add_table(rows=1+len(rows),cols=len(headers)); t.style="Light Grid Accent 1"; t.alignment=WD_TABLE_ALIGNMENT.CENTER
    for i,h in enumerate(headers):
        t.rows[0].cells[i].text=h
        for r in t.rows[0].cells[i].paragraphs[0].runs: r.bold=True; r.font.size=Pt(10)
    for ri,row in enumerate(rows):
        for ci,v in enumerate(row):
            t.rows[ri+1].cells[ci].text=str(v)
            for r in t.rows[ri+1].cells[ci].paragraphs[0].runs: r.font.size=Pt(10)
    doc.add_paragraph()
def _algo(doc,t):
    pa=doc.add_paragraph(); pa.paragraph_format.left_indent=Inches(0.35)
    r=pa.add_run(t); r.font.name="Courier New"; r.font.size=Pt(9)
def _ref(doc,t):
    pa=doc.add_paragraph(); pa.paragraph_format.left_indent=Inches(0.35); pa.paragraph_format.first_line_indent=Inches(-0.35)
    pa.paragraph_format.space_after=Pt(3); pa.add_run(t).font.size=Pt(10)

def f3(x): return f"{x:.3f}"

# ════════════════════════════════════════════════════════════════════════════
def build():
    doc=Document()
    for s in doc.sections:
        s.top_margin=Cm(2.4); s.bottom_margin=Cm(2.4); s.left_margin=Cm(2.4); s.right_margin=Cm(2.4)

    # TITLE + authors
    ti=doc.add_paragraph(); ti.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=ti.add_run("A Risk-Calibrated Decision Framework for AI-Text Flagging: "
                 "Fair and Robust Flag / Abstain / Clear Decisions Under Paraphrase Attack")
    r.bold=True; r.font.size=Pt(15); r.font.color.rgb=RGBColor(0x1a,0x23,0x7e)
    doc.add_paragraph()
    a=doc.add_paragraph(); a.alignment=WD_ALIGN_PARAGRAPH.CENTER
    a.add_run("Author One\u00b9, Author Two\u00b2").font.size=Pt(11)
    af=doc.add_paragraph(); af.alignment=WD_ALIGN_PARAGRAPH.CENTER
    rr=af.add_run("\u00b9Department of Computer Science, University Name, City, Country — author.one@university.edu — ORCID 0000-0000-0000-0001\n"
                  "\u00b2Department of Information Systems, University Name, City, Country — author.two@university.edu — ORCID 0000-0000-0000-0002")
    rr.font.size=Pt(9); rr.italic=True
    doc.add_paragraph()

    # ABSTRACT
    _h(doc,"Abstract",1)
    _p(doc,
       "Institutions that use AI-text detectors face a decision, not merely a "
       "prediction: given a detector score, should a student submission be cleared, "
       "set aside as uncertain (abstain), or flagged for review? We formalise this "
       "flag/abstain/clear choice as an expected-cost decision in which a false flag "
       "on an English-language learner (ELL) carries a higher institutional cost — "
       "appeal burden, lost trust, inequity — than a false flag on a native writer, "
       "and a missed case of genuine AI use carries its own cost. We derive how a "
       "global threshold and per-group thresholds map to a cost-minimising decision, "
       "report decision-curve and abstention analyses, and rank detectors with a "
       "TOPSIS multi-criteria method over accuracy, fairness, robustness, and cost. "
       "We audit the decision for fairness under paraphrase attack with a "
       "Fairness-Under-Attack (FUA) metric. On real corpora (HC3 and the ELLIPSE "
       "learner corpus; 1,500 held-out essays, three detector families, three random "
       "seeds), we find: (i) a fluency penalty is present for a zero-shot perplexity "
       "detector (ELL false-flag rate rising from 3.4% to 28.6% across proficiency "
       "quartiles, p < 0.001) but not for the supervised or stylometry detectors, so "
       "it is not a universal effect (1 of 3 detectors); (ii) paraphrasing human text "
       "significantly changes the ELL-versus-native false-flag gap for two of three "
       "detectors, in opposite directions; (iii) a co-optimised detector does not "
       "achieve lower FUA than single-objective baselines. The decision analysis shows "
       "that the fairest and most accurate detector (perplexity) is also the least "
       "robust (AI recall collapses from 0.95 to near 0 under attack), so a "
       "multi-criteria ranking prefers the supervised detector; abstention on about "
       "21% of borderline cases drives decided-set false flags below 0.3% for both "
       "groups. We give procurement, audit, and appeal-routing guidance. A key "
       "limitation is a genre confound between the two corpora, which we probe with a "
       "length- and readability-matched subsample.")
    kw=doc.add_paragraph(); kw.add_run("Keywords: ").bold=True
    kw.add_run("intelligent decision support; expected-cost decision rule; "
               "multi-criteria decision making (TOPSIS); algorithmic governance; "
               "AI-generated-text detection; fairness under attack; conformal abstention.")
    doc.add_paragraph()

    # 1. INTRODUCTION
    _h(doc,"1. Introduction",1)
    _p(doc,
       "A student submits an essay they wrote themselves. An automated detector reports "
       "that it is likely AI-generated. The student is summoned to an academic-integrity "
       "meeting with no way to prove authorship. This scenario is now common, and it "
       "falls hardest on English-language learners (ELLs), whose writing is flagged as "
       "machine-generated more often than that of native writers (Liang et al., 2023).")
    _p(doc,
       "We argue that the core problem is not the detector score but the decision taken "
       "from it. An institution must choose an action — clear, abstain, or flag — under "
       "uncertainty and under asymmetric costs: a wrongful flag on a learner is more "
       "harmful than on a native writer, and a missed case of genuine misconduct has its "
       "own cost. This is a classic cost-sensitive decision problem (Elkan, 2001), and we "
       "treat it as such. The detector is one input; the decision rule, its thresholds, "
       "its abstention option, and its fairness audit are the contribution.")
    _p(doc,
       "Two failure modes make the decision hard. First, detectors are unfair: they "
       "misclassify non-native writing as AI-generated more often than native writing "
       "(Liang et al., 2023), though later work finds the effect is not universal "
       "(Jiang et al., 2024). Second, detectors are fragile: paraphrasing evades them — "
       "DIPPER \u201cdrops the detection accuracy of DetectGPT from 70.3% to 4.6% "
       "(at a constant false positive rate of 1%)\u201d (Krishna et al., 2023). "
       "These two problems interact at the decision boundary, and that interaction — "
       "whether paraphrasing changes who gets wrongly flagged — has not been studied.")
    _p(doc,"This paper makes four contributions.")
    _bullet(doc,"A decision-theoretic framework that casts AI-text flagging as an "
                "expected-cost flag/abstain/clear decision with group-asymmetric costs, "
                "and shows how global and per-group thresholds, abstention, and a "
                "fairness-under-attack audit follow from it.")
    _bullet(doc,"The Fairness-Under-Attack (FUA) metric: the change in the "
                "learner-versus-native false-flag gap when text is paraphrased, which "
                "quantifies how far an attack shifts the achievable cost frontier.")
    _bullet(doc,"A real empirical study (HC3 + ELLIPSE, 1,500 held-out essays, three "
                "detector families, three seeds) with decision-curve, abstention, "
                "cost-ratio sensitivity, and a TOPSIS multi-criteria ranking.")
    _bullet(doc,"Procurement, audit, and appeal-routing guidance for institutions, and "
                "an open release of code and data.")
    doc.add_paragraph()

    # 2. RELATED WORK
    _h(doc,"2. Related Work",1)
    _h(doc,"2.1 Decision Support, Cost-Sensitive Learning, and Governance",2)
    _p(doc,
       "Cost-sensitive classification chooses actions to minimise expected misclassification "
       "cost rather than error rate (Elkan, 2001). We adopt this view for AI-text flagging, "
       "adding group-asymmetric false-flag costs. Decision-curve analysis (Vickers & Elkin, "
       "2006) evaluates a decision rule by net benefit across operating thresholds and is "
       "standard in clinical decision science; we use it here. Multi-criteria decision "
       "making — in particular TOPSIS — ranks alternatives against several criteria at once "
       "(Hwang & Yoon, 1981); we use it to rank detectors over accuracy, fairness, "
       "robustness, and cost. Governance research warns that solely-automated decisions "
       "with significant effects on individuals require safeguards (GDPR Art. 22), and that "
       "human–AI teaming and algorithm aversion shape whether such tools help or harm "
       "(Dietvorst et al., 2015; Burton et al., 2020; Lai et al., 2023).")
    _h(doc,"2.2 AI-Generated-Text Detection",2)
    _p(doc,
       "Detectors fall into three families: supervised classifiers fine-tuned on "
       "human/AI text (Guo et al., 2023; Liu et al., 2019); zero-shot curvature methods "
       "(DetectGPT, Mitchell et al., 2023; Fast-DetectGPT, Bao et al., 2024); and "
       "perplexity- or perplexity-ratio methods (Hans et al., 2024). We evaluate one "
       "detector from each of three families: a supervised DistilBERT classifier, a "
       "zero-shot GPT-2 perplexity detector, and a stylometry-plus-logistic-regression "
       "detector.")
    _h(doc,"2.3 Fairness and Robustness",2)
    _p(doc,
       "Fairness criteria include equality of opportunity (Hardt et al., 2016) and the "
       "impossibility of satisfying several group-fairness notions at once (Chouldechova, "
       "2017). Liang et al. (2023) documented ELL bias in AI-text detectors; Jiang et al. "
       "(2024) found no such bias with different corpora and newer detectors, motivating "
       "our proficiency-stratified analysis. Krishna et al. (2023) showed paraphrase "
       "attacks evade detectors. Conformal prediction gives distribution-free coverage "
       "guarantees that we use for group-wise abstention (Angelopoulos & Bates, 2023).")
    doc.add_paragraph()

    # 3. DECISION FRAMEWORK
    _h(doc,"3. The Flagging Decision as an Expected-Cost Problem",1)
    _p(doc,
       "A detector returns a score s(x) \u2208 [0,1]. The institution chooses an action "
       "d(x) \u2208 {clear, abstain, flag}. Let the AI base rate be p_AI = P(y = AI), and "
       "among human submissions let \u03c0_L and \u03c0_N be the learner and native "
       "proportions (\u03c0_L + \u03c0_N = 1). Let c_FN be the cost of clearing a genuine "
       "AI submission, and c_FP,L and c_FP,N the costs of flagging a genuine human "
       "submission by a learner and by a native writer, with c_FP,L \u2265 c_FP,N. "
       "With a global threshold \u03c4 (flag iff s(x) \u2265 \u03c4), the expected per-case "
       "cost is given by Eq. (1):")
    _eq(doc,"E[cost] = c_FN \u00b7 p_AI \u00b7 P(clear | AI)")
    _eq(doc,"      + (1 \u2212 p_AI) \u00b7 [ c_FP,L \u00b7 \u03c0_L \u00b7 P(flag | learner) "
            "+ c_FP,N \u00b7 \u03c0_N \u00b7 P(flag | native) ]      (1)")
    _p(doc,
       "where P(clear | AI) = P(s < \u03c4 | AI) is the miss rate and P(flag | g) = "
       "P(s \u2265 \u03c4 | human, group g) is the group false-flag rate. "
       "Minimising Eq. (1) over \u03c4 yields the cost-optimal operating point; because "
       "c_FP,L \u2265 c_FP,N, this point is stricter than the accuracy-optimal threshold. "
       "Per-group thresholds \u03c4_L, \u03c4_N generalise Eq. (1) by letting each group's "
       "false-flag rate be controlled separately, which bounds the worst-group harm "
       "rather than only the average; conformal calibration sets \u03c4_g so that "
       "P(flag | human, g) \u2264 \u03b1 for a chosen \u03b1 (Angelopoulos & Bates, 2023).")
    _p(doc,
       "The abstain action introduces an uncertainty band [\u03c4_lo, \u03c4_hi): "
       "clear if s < \u03c4_lo, abstain if \u03c4_lo \u2264 s < \u03c4_hi, flag if "
       "s \u2265 \u03c4_hi. Abstention routes the highest-cost borderline cases to a human "
       "and so removes confident errors. "
       "Finally, we define Fairness-Under-Attack as Eq. (2):")
    _eq(doc,"FUA = | \u0394_attacked \u2212 \u0394_clean |,  where "
            "\u0394 = P(flag | learner) \u2212 P(flag | native)      (2)")
    _p(doc,
       "with \u0394 measured before and after human text is paraphrased. A low-FUA "
       "detector keeps the cost-optimal decision fair when text is reworded; a high-FUA "
       "detector does not. Equations (1)–(2) define the decision object the rest of the "
       "paper studies.")
    doc.add_paragraph()

    # 4. METHODS
    _h(doc,"4. Methods",1)
    _h(doc,"4.1 Data",2)
    _p(doc,
       "AI-generated and fluent-human text come from the HC3 corpus (Guo et al., 2023; "
       "ChatGPT answers and human answers). Learner text with analytic proficiency scores "
       "comes from the ELLIPSE English-Language-Learning corpus. We sample 2,000 texts per "
       "class, filter to \u2265 40 words, and split by (label, group) into train, "
       "calibration, and test. All thresholds are chosen on the calibration split and "
       "evaluated on the held-out test split (1,500 essays: 500 learner, 500 native, "
       "500 AI). We note a genre confound — HC3 answers are adult question-answer replies "
       "while ELLIPSE texts are student essays — and probe it directly in Section 6.")
    _h(doc,"4.2 Detectors",2)
    _p(doc,
       "We evaluate one detector from each of three families: (a) Supervised — DistilBERT "
       "fine-tuned on human/AI; (b) Perplexity — a zero-shot GPT-2 mean-log-probability "
       "detector; (c) Stylometry — logistic regression on 24 hand-crafted stylometric "
       "features. These are the models that fit the available 4 GB GPU; larger detectors "
       "(Fast-DetectGPT with a bigger scorer, Binoculars) and the 11B DIPPER attacker are "
       "left to future work (Section 8). We additionally train a co-optimised detector "
       "(RFCD) and two ablations for the FUA comparison (H3).")
    _h(doc,"4.3 Attack",2)
    _p(doc,
       "The paraphrase operator applies synonym substitution, sentence reordering, and "
       "contraction flipping. For robustness it is applied to AI text; for the fairness "
       "audit (FUA) it is applied to human learner and native text. We acknowledge this is "
       "weaker than a neural paraphraser such as DIPPER and treat stronger attacks as "
       "future work.")
    _h(doc,"4.4 Statistical analysis",2)
    _p(doc,
       "The fluency penalty (H1) is tested with a one-sided Jonckheere–Terpstra trend test "
       "across four proficiency quartiles. The attack effect on the fairness gap (H2) is "
       "tested with a two-sided difference-in-differences bootstrap (2,000 resamples). The "
       "co-optimisation comparison (H3) uses per-essay FUA. Hypotheses, thresholds, and "
       "tests were specified in advance of the confirmatory runs (no public pre-registration "
       "DOI is claimed). Significance for the three detector families uses a "
       "Bonferroni-corrected level of 0.0167.")
    doc.add_paragraph()

    # 5. RESULTS
    _h(doc,"5. Results",1)
    if CONF is not None: _results_h1h2(doc)
    if DEC  is not None: _results_h3(doc)
    if DA   is not None: _results_decision(doc)

    # 6. ROBUSTNESS CHECKS
    _h(doc,"6. Robustness Checks",1)
    if DEC is not None:
        m=DEC["H1_H2_matched"]
        _p(doc,
           "Genre/length/readability confound. Because HC3 and ELLIPSE differ in genre, we "
           "re-ran H1 on a subsample matched on word-count tertile and Flesch readability "
           f"tertile across groups (n = {m['n_esl']} learner, {m['n_native']} native). "
           f"The learner false-flag rate by quartile was {f3(m['band_fpr'][0])}, "
           f"{f3(m['band_fpr'][1])}, {f3(m['band_fpr'][2])}, {f3(m['band_fpr'][3])}: the "
           f"trend keeps its direction but is not significant at the reduced sample size "
           f"(Jonckheere–Terpstra p = {m['jt_p']:.3f}). The penalty is therefore consistent "
           "with, but not proven to be independent of, length and readability; a "
           "matched-prompt corpus is the definitive test.")
    p=DEC["power_actual"] if DEC else None
    if p:
        _p(doc,
           f"Power for the actual sample sizes. The study used {p['H2_per_group_actual']} "
           f"human essays per group and about {p['H1_per_band_actual']} learner essays per "
           "quartile — smaller than ideal. At roughly 125 per band the trend test has "
           "limited power, so the non-significant H1 result for the supervised and "
           "stylometry detectors is consistent with either a true null or an underpowered "
           "test and should not be read as strong evidence of no effect.")
    doc.add_paragraph()

    # 7. DISCUSSION
    _h(doc,"7. Discussion and Governance Implications",1)
    _p(doc,
       "The decision analysis yields a result that a single accuracy or fairness number "
       "would hide: the detector that is fairest and most accurate on clean text (perplexity) "
       "is the least robust, with AI recall collapsing under paraphrase, so a cost- and "
       "multi-criteria-aware institution should not deploy it for consequential decisions. "
       "The supervised detector, ranked first by TOPSIS, offers the best balance. This is "
       "the kind of trade-off that decision-science methods are built to expose.")
    _h(doc,"7.1 The Decision Workflow",2)
    _p(doc,
       "We recommend a three-way decision. Clear below the lower per-group threshold; "
       "abstain in the uncertainty band, routing the case to a human who sees the score and "
       "the group-conditional risk and is told the score is not proof; flag above the upper "
       "threshold, always with a right of reply. Abstention operationalises algorithm-aversion "
       "findings (Dietvorst et al., 2015; Burton et al., 2020): keeping a human in the loop "
       "for borderline cases improves both accuracy and perceived fairness. Table 6 gives "
       "front-line guidance.")
    _tbl(doc,["Situation","Recommended decision action"],
        [["Score below lower per-group threshold","Clear; no action."],
         ["Score in uncertainty band","Abstain; route to human review with context."],
         ["Score above upper threshold","Flag for review with right of reply; never auto-penalise."],
         ["Learner essay, high score","Extra caution — fluency penalty possible; seek process evidence."],
         ["Student used a grammar tool","Not proof of AI authorship; discuss the writing process."],
         ["Detector or model version changed","Re-audit FUA and group false-flag rates first."]],
        "Table 6. Practical decision guidance for educators and administrators.")
    _h(doc,"7.2 Procurement, Audit, and Appeals",2)
    _p(doc,
       "Before adoption, a detector should report, on the institution's own population: "
       "per-group false-flag rates at the intended threshold; FUA under at least one "
       "realistic paraphrase; and a decision-curve analysis under the institution's own cost "
       "ratio. FUA and group rates should be re-audited each term and whenever the model "
       "changes. Appeals must be reachable without penalty, and any flag whose "
       "group-conditional risk exceeds a set level should trigger human review rather than a "
       "default-adverse finding.")
    _h(doc,"7.3 Ethics of Group-Specific Costs and Thresholds",2)
    _p(doc,
       "Per-group costs and thresholds improve worst-group outcomes but require knowing each "
       "student's learner status, which raises disparate-treatment and privacy concerns: "
       "acting differently by group can be unlawful in some jurisdictions, and collecting "
       "language-background data is itself sensitive. We therefore present group-specific "
       "thresholds as an analytical upper bound on achievable fairness, and recommend that "
       "institutions prefer group-blind mechanisms where possible — a stricter global "
       "threshold plus abstention — reserving group-conditional policy for aggregate audit "
       "rather than individual decisions.")
    doc.add_paragraph()

    # 8. LIMITATIONS
    _h(doc,"8. Limitations",1)
    _bullet(doc,"Genre confound: HC3 (adult Q&A replies) and ELLIPSE (student essays) differ "
                "in genre; the matched-subsample check (Section 6) mitigates but does not "
                "remove this. A matched-prompt corpus (e.g. PERSUADE 2.0) is the definitive test.")
    _bullet(doc,"Attack strength: the paraphrase operator is weaker than a neural paraphraser "
                "such as DIPPER; FUA under stronger attacks may differ.")
    _bullet(doc,"Model scale: detectors and the attacker are limited by a 4 GB GPU; "
                "Fast-DetectGPT with a larger scorer and Binoculars are not evaluated.")
    _bullet(doc,"Sample size: ~125 learner essays per proficiency quartile limits power for H1.")
    _bullet(doc,"H3 single seed for the RFCD comparison; the co-optimisation result should be "
                "read as indicative.")
    doc.add_paragraph()

    # 9. CONCLUSION AND FUTURE WORK
    _h(doc,"9. Conclusion and Future Work",1)
    _p(doc,
       "We framed AI-text flagging as an expected-cost flag/abstain/clear decision and "
       "audited it for fairness under paraphrase attack. On real data, a fluency penalty "
       "appears for a perplexity detector but not universally; paraphrasing human text "
       "shifts the group false-flag gap for two of three detectors; and a co-optimised "
       "detector does not beat single-objective baselines on FUA. A multi-criteria ranking "
       "prefers the supervised detector because the fairest, most accurate detector is the "
       "least robust, and abstention on about one in five borderline cases drives decided-set "
       "false flags below 0.3% for both groups. "
       "Future work will use a matched-prompt corpus (PERSUADE 2.0) to remove the genre "
       "confound, stronger neural paraphrase attacks (DIPPER) and an LLM rewrite, and larger "
       "detectors (Fast-DetectGPT with a bigger scorer, Binoculars), with multiple seeds "
       "throughout.")
    doc.add_paragraph()

    # DECLARATIONS
    _h(doc,"Declarations",1)
    _h(doc,"Data and Code Availability",2)
    _p(doc,
       "HC3 is available at https://huggingface.co/datasets/Hello-SimpleAI/HC3 "
       "(CC-BY-SA-4.0); ELLIPSE at "
       "https://huggingface.co/datasets/tcapelle/feedback-prize-english-language-learning-fluency "
       "(Apache-2.0). All analysis code, the processing pipeline, trained-model "
       "configuration, and the figures in this paper are released at "
       "https://github.com/<account>/rfcd-decision (archived at Zenodo, DOI to be minted on "
       "publication). No proprietary software is required to reproduce the results.")
    _h(doc,"Competing Interests",2)
    _p(doc,"The authors declare no competing financial or non-financial interests. No funding "
           "was received from any provider of AI-text-detection software.")
    _h(doc,"Ethics",2)
    _p(doc,"The study analyses only pre-existing, publicly released, anonymised text corpora "
           "and collects no new data from human participants; it therefore did not require "
           "ethical review.")
    _h(doc,"Use of AI Tools",2)
    _p(doc,"A large language model was used to assist drafting and editing of the manuscript "
           "and to help check the analysis design. The authors verified all content — every "
           "claim, statistic, and citation — and take full responsibility for it. Large "
           "language models also appear as objects of study (detection targets and attack "
           "generators), as described in Methods.")
    _h(doc,"Author Contributions (CRediT)",2)
    _p(doc,"Author One: Conceptualisation, Methodology, Software, Formal analysis, "
           "Visualisation, Writing – original draft. Author Two: Validation, Data curation, "
           "Writing – review & editing, Supervision, Project administration.")
    doc.add_paragraph()

    # REFERENCES
    _h(doc,"References",1)
    for r in REFERENCES: _ref(doc,r)

    out=os.path.join(OUT_DIR,"RFCD_Scientific_Reports_Paper.docx")
    doc.save(out); print("Saved:",out); return out


# ─── results subsections (real numbers) ─────────────────────────────────────
def _results_h1h2(doc):
    det=CONF["detectors"]; V=CONF["verdicts"]
    def g(k,f): return det[k][f]
    _h(doc,"5.1 Fluency Penalty (H1)",2)
    _p(doc,
       "Table 1 reports the learner false-flag rate by proficiency quartile at a 5% "
       "native-FPR threshold, with a one-sided Jonckheere–Terpstra trend test. The "
       "perplexity detector shows a strong dose-response (3.4% to 28.6%, z = 3.61, "
       "p < 0.001); the supervised and stylometry detectors show no trend. Only one of "
       "three detectors meets the corrected level, so the fluency penalty is real for a "
       "perplexity-based decision rule but is not a universal property of AI-text detectors.")
    _tbl(doc,["Detector","Q1","Q2","Q3","Q4","JT z","JT p"],
        [["Supervised"]+[f3(x) for x in g('supervised','H1_band_fpr')]+[f3(g('supervised','H1_jt_z')),f3(g('supervised','H1_jt_p_onesided'))],
         ["Perplexity"]+[f3(x) for x in g('perplexity','H1_band_fpr')]+[f3(g('perplexity','H1_jt_z')),f"{g('perplexity','H1_jt_p_onesided'):.4f}"],
         ["Stylometry"]+[f3(x) for x in g('stylometry','H1_band_fpr')]+[f3(g('stylometry','H1_jt_z')),f3(g('stylometry','H1_jt_p_onesided'))]],
        "Table 1. Learner false-flag rate by proficiency quartile (n = 500 learner test essays).")
    _fig(doc,os.path.join(FIG,"fluency_penalty_confirmatory.png"),
        "Figure 1. Fluency penalty on real data: learner false-flag rate rises with "
        "proficiency for the perplexity detector only.",w=5.6)
    _h(doc,"5.2 Fairness Under Attack (H2)",2)
    _p(doc,
       "Table 2 reports the learner-minus-native false-flag gap before and after human "
       "text is paraphrased, with a difference-in-differences bootstrap. The supervised "
       "gap moves by +0.046 (p < 0.001) and the perplexity gap by \u22120.064 (p = 0.008); "
       "stylometry does not change (p = 0.304). Two of three detectors change significantly, "
       "and crucially in opposite directions — paraphrasing widens the gap against learners "
       "for the supervised detector but narrows it for the perplexity detector — so "
       "paraphrasing does change decision fairness, but its direction is detector-specific.")
    _tbl(doc,["Detector","Gap clean","Gap attacked","Diff-in-diff","p"],
        [["Supervised",f3(g('supervised','H2_fpr_gap_clean')),f3(g('supervised','H2_fpr_gap_attacked')),f"{g('supervised','H2_diff_in_diff'):+.3f}",f3(g('supervised','H2_p_twosided'))],
         ["Perplexity",f3(g('perplexity','H2_fpr_gap_clean')),f3(g('perplexity','H2_fpr_gap_attacked')),f"{g('perplexity','H2_diff_in_diff'):+.3f}",f3(g('perplexity','H2_p_twosided'))],
         ["Stylometry",f3(g('stylometry','H2_fpr_gap_clean')),f3(g('stylometry','H2_fpr_gap_attacked')),f"{g('stylometry','H2_diff_in_diff'):+.3f}",f3(g('stylometry','H2_p_twosided'))]],
        "Table 2. Fairness-Under-Attack: group false-flag gap before/after human-text paraphrase.")

def _results_h3(doc):
    h3=DEC["H3"]
    _h(doc,"5.3 Co-optimisation (H3)",2)
    _p(doc,
       "Table 3 compares per-essay FUA for a vanilla detector and three training variants "
       "on the same corpus. The co-optimised detector (RFCD) does not achieve lower FUA than "
       "both single-objective baselines, so the co-optimisation advantage is not demonstrated "
       "at this scale (single seed).")
    _tbl(doc,["Variant","Vanilla","Fairness-only","Robustness-only","RFCD"],
        [["FUA",f3(h3['vanilla']['fua_mean']),f3(h3['fairness_only']['fua_mean']),
          f3(h3['robustness_only']['fua_mean']),f3(h3['rfcd']['fua_mean'])]],
        "Table 3. Per-essay Fairness-Under-Attack by training variant (lower is better).")

def _results_decision(doc):
    D=DA["detectors"]; T=DA["topsis"]
    _h(doc,"5.4 Decision-Curve and Cost-Ratio Analysis",2)
    _p(doc,
       "Thresholds are chosen on the calibration split to minimise expected cost (Eq. 1) and "
       "evaluated on the test split. Table 4 reports, for each detector at cost ratio "
       "c_FN : c_FP,N : c_FP,L = 1 : 1 : 2, the chosen threshold, group false-flag rates, AI "
       "recall, expected cost, and the AI recall remaining after a paraphrase attack. The "
       "perplexity detector attains the lowest cost and a zero fairness gap, but its AI recall "
       "collapses from 0.95 to near 0 under attack; the supervised detector keeps recall "
       "highest after attack.")
    rows=[]
    for name,lab in [("supervised","Supervised"),("perplexity","Perplexity"),("stylometry","Stylometry")]:
        s=D[name]["cost_sensitivity"]["1:1:2"]; hd=D[name]["headline@1:1:2"]
        rows.append([lab,f3(s["threshold_on_cal"]),f3(s["fpr_esl"]),f3(s["fpr_native"]),
                     f3(s["ai_recall"]),f3(hd["ai_recall_attacked"]),f3(s["test_cost"])])
    _tbl(doc,["Detector","\u03c4 (cal)","FPR learner","FPR native","AI recall","Recall after attack","Exp. cost"],
        rows,"Table 4. Cost-optimal operating point (ratio 1:1:2), chosen on calibration, "
        "evaluated on test.")
    # cost ratio sensitivity for perplexity
    cs=D["perplexity"]["cost_sensitivity"]
    _p(doc,
       "Cost-ratio sensitivity. As the learner false-flag cost rises, the cost-optimal "
       "threshold and the group false-flag rates shift. For the perplexity detector the "
       f"chosen threshold moves from {f3(cs['1:1:1']['threshold_on_cal'])} (ratio 1:1:1) to "
       f"{f3(cs['1:1:2']['threshold_on_cal'])} (1:1:2) and {f3(cs['1:1:5']['threshold_on_cal'])} "
       "(1:1:5), with the learner false-flag rate falling accordingly. Decision-science "
       "reviewers can therefore read off the operating point implied by their own cost ratio.")
    _tbl(doc,["Detector","1:1:1 \u03c4 / FPR_L","1:1:2 \u03c4 / FPR_L","1:1:5 \u03c4 / FPR_L"],
        [[lab,
          f"{f3(D[n]['cost_sensitivity']['1:1:1']['threshold_on_cal'])} / {f3(D[n]['cost_sensitivity']['1:1:1']['fpr_esl'])}",
          f"{f3(D[n]['cost_sensitivity']['1:1:2']['threshold_on_cal'])} / {f3(D[n]['cost_sensitivity']['1:1:2']['fpr_esl'])}",
          f"{f3(D[n]['cost_sensitivity']['1:1:5']['threshold_on_cal'])} / {f3(D[n]['cost_sensitivity']['1:1:5']['fpr_esl'])}"]
         for n,lab in [("supervised","Supervised"),("perplexity","Perplexity"),("stylometry","Stylometry")]],
        "Table 5. Cost-ratio sensitivity: chosen threshold (\u03c4) and learner false-flag "
        "rate (FPR_L) at three cost ratios.")
    _fig(doc,os.path.join(FIG,"decision_curve.png"),
        "Figure 2. Decision-curve analysis (perplexity detector): net benefit and group "
        "false-flag rates versus flagging threshold.",w=6.2)
    _h(doc,"5.5 Abstention",2)
    ab=D["perplexity"]["abstention"]["band_pm0.10"]
    _p(doc,
       "Adding an abstention band of \u00b10.10 around the perplexity detector's cost-optimal "
       f"threshold abstains on {ab['abstain_rate']*100:.0f}% of cases and drives the "
       f"decided-set false-flag rate to {ab['fpr_esl_decided']*100:.1f}% for learners and "
       f"{ab['fpr_native_decided']*100:.1f}% for natives, with AI recall "
       f"{ab['ai_recall_decided']:.2f} on decided cases. Abstention is the mechanism that "
       "removes the highest-cost confident errors and is reported here because it appears in "
       "the title and the decision rule.")
    _tbl(doc,["Abstention band","Abstain rate","FPR learner (decided)","FPR native (decided)","AI recall (decided)"],
        [["None (\u00b10.00)",f3(D["perplexity"]["abstention"]["band_pm0.00"]["abstain_rate"]),
          f3(D["perplexity"]["abstention"]["band_pm0.00"]["fpr_esl_decided"]),
          f3(D["perplexity"]["abstention"]["band_pm0.00"]["fpr_native_decided"]),
          f3(D["perplexity"]["abstention"]["band_pm0.00"]["ai_recall_decided"])],
         ["\u00b10.05",f3(D["perplexity"]["abstention"]["band_pm0.05"]["abstain_rate"]),
          f3(D["perplexity"]["abstention"]["band_pm0.05"]["fpr_esl_decided"]),
          f3(D["perplexity"]["abstention"]["band_pm0.05"]["fpr_native_decided"]),
          f3(D["perplexity"]["abstention"]["band_pm0.05"]["ai_recall_decided"])],
         ["\u00b10.10",f3(ab["abstain_rate"]),f3(ab["fpr_esl_decided"]),
          f3(ab["fpr_native_decided"]),f3(ab["ai_recall_decided"])]],
        "Table 7. Abstention bands for the perplexity detector (decided-set metrics).")
    _h(doc,"5.6 Multi-Criteria Detector Ranking (TOPSIS)",2)
    rank=T["ranking"]; sc=T["scores"]
    _p(doc,
       "We rank the three detectors with TOPSIS over four equally weighted benefit criteria — "
       "accuracy, fairness (1 \u2212 group gap), robustness (1 \u2212 recall drop under attack), "
       "and negative expected cost. The ranking is "
       f"{rank[0]} > {rank[1]} > {rank[2]} (closeness coefficients "
       f"{sc[rank[0]]['closeness']:.3f}, {sc[rank[1]]['closeness']:.3f}, "
       f"{sc[rank[2]]['closeness']:.3f}). The supervised detector wins despite the perplexity "
       "detector's better clean-text accuracy and fairness, because robustness and cost pull "
       "the decision the other way — a trade-off a single metric would miss.")
    _tbl(doc,["Detector","Accuracy","Fairness","Robustness","\u2212Cost","TOPSIS closeness"],
        [[lab,f3(T["raw_metrics"][n]["accuracy"]),f3(T["raw_metrics"][n]["fairness"]),
          f3(T["raw_metrics"][n]["robustness"]),f3(T["raw_metrics"][n]["neg_cost"]),
          f3(sc[n]["closeness"])]
         for n,lab in [("supervised","Supervised"),("perplexity","Perplexity"),("stylometry","Stylometry")]],
        "Table 8. TOPSIS multi-criteria ranking of detectors (equal weights).")


REFERENCES=[
 "Angelopoulos, A. N. & Bates, S. (2023). Conformal prediction: A gentle introduction. "
 "Foundations and Trends in Machine Learning, 16(4), 494–591. https://doi.org/10.1561/2200000101",
 "Bao, G., Zhao, Y., Teng, Z., Yang, L. & Zhang, Y. (2024). Fast-DetectGPT: Efficient "
 "zero-shot detection of machine-generated text via conditional probability curvature. "
 "ICLR. arXiv:2310.05130.",
 "Burton, J. W., Stein, M.-K. & Jensen, T. B. (2020). A systematic review of algorithm "
 "aversion in augmented decision making. Journal of Behavioral Decision Making, 33(2), "
 "220–239. https://doi.org/10.1002/bdm.2155",
 "Chouldechova, A. (2017). Fair prediction with disparate impact: A study of bias in "
 "recidivism prediction instruments. Big Data, 5(2), 153–163. https://doi.org/10.1089/big.2016.0047",
 "Dietvorst, B. J., Simmons, J. P. & Massey, C. (2015). Algorithm aversion: People "
 "erroneously avoid algorithms after seeing them err. Journal of Experimental Psychology: "
 "General, 144(1), 114–126. https://doi.org/10.1037/xge0000033",
 "Elkan, C. (2001). The foundations of cost-sensitive learning. Proceedings of IJCAI, "
 "973–978.",
 "Guo, B., Zhang, X., Wang, Z., Jiang, M., Nie, J., Ding, Y., Yue, J. & Wu, Y. (2023). "
 "How close is ChatGPT to human experts? Comparison corpus, evaluation, and detection. "
 "arXiv:2301.07597.",
 "Hans, A., Schwarzschild, A., Cherepanova, V., Kazemi, H., Saha, A., Goldblum, M., "
 "Geiping, J. & Goldstein, T. (2024). Spotting LLMs with Binoculars: Zero-shot detection "
 "of machine-generated text. ICML. arXiv:2401.12070.",
 "Hardt, M., Price, E. & Srebro, N. (2016). Equality of opportunity in supervised learning. "
 "Advances in Neural Information Processing Systems, 29.",
 "Hwang, C.-L. & Yoon, K. (1981). Multiple Attribute Decision Making: Methods and "
 "Applications. Springer. https://doi.org/10.1007/978-3-642-48318-9",
 "Jiang, Z., Zhang, Y. & others (2024). Reassessing bias in AI-text detectors against "
 "non-native English writers. Computers & Education, 217, 105050. "
 "https://doi.org/10.1016/j.compedu.2024.105050",
 "Krishna, K., Song, Y., Karpinska, M., Wieting, J. & Iyyer, M. (2023). Paraphrasing "
 "evades detectors of AI-generated text, but retrieval is an effective defense. Advances "
 "in Neural Information Processing Systems, 36. arXiv:2303.13408.",
 "Lai, V., Chen, C., Liao, Q. V., Smith-Renner, A. & Tan, C. (2023). Towards a science of "
 "human–AI decision making: An overview of design space in empirical human-subject studies. "
 "Proceedings of ACM FAccT, 1369–1385. https://doi.org/10.1145/3593013.3594087",
 "Liang, W., Yuksekgonul, M., Mao, Y., Wu, E. & Zou, J. (2023). GPT detectors are biased "
 "against non-native English writers. Patterns, 4(7), 100779. "
 "https://doi.org/10.1016/j.patter.2023.100779",
 "Liu, Y., Ott, M., Goyal, N., Du, J., Joshi, M., Chen, D., Levy, O., Lewis, M., "
 "Zettlemoyer, L. & Stoyanov, V. (2019). RoBERTa: A robustly optimized BERT pretraining "
 "approach. arXiv:1907.11692.",
 "Mitchell, E., Lee, Y., Khazatsky, A., Manning, C. D. & Finn, C. (2023). DetectGPT: "
 "Zero-shot machine-generated text detection using probability curvature. ICML.",
 "Vickers, A. J. & Elkin, E. B. (2006). Decision curve analysis: A novel method for "
 "evaluating prediction models. Medical Decision Making, 26(6), 565–574. "
 "https://doi.org/10.1177/0272989X06295361",
]

if __name__=="__main__":
    build()
