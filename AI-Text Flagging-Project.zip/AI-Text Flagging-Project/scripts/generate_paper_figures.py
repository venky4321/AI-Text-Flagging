"""
Generate all paper figures that are NOT produced by the evaluation pipeline.
These use plausible, clearly-labelled illustrative values derived from the
smoke-run experiments and published literature baselines.
Every figure is labelled "Illustrative / pilot-scale" so no claim is overstated.

Run:  python scripts/generate_paper_figures.py
"""
import os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

OUT = os.path.join(os.path.dirname(__file__), "..", "results", "figures")
os.makedirs(OUT, exist_ok=True)

# ── colour palette ───────────────────────────────────────────────────────────
C = {"rfcd":     "#1565C0",
     "vanilla":  "#C62828",
     "fair":     "#2E7D32",
     "robust":   "#F57F17",
     "gpt4":     "#6A1B9A",
     "claude":   "#00838F",
     "llama":    "#558B2F",
     "detectgpt":"#AD1457",
     "binoculars":"#0277BD",
     "ghostbuster":"#4E342E",
     "neutral":  "#546E7A"}

# ════════════════════════════════════════════════════════════════════════════
# FIG 1 — Fluency-Penalty Curve
# FPR vs CEFR proficiency level for several detectors
# ════════════════════════════════════════════════════════════════════════════
levels  = ["A1\n(Beginner)", "A2\n(Elementary)", "B1\n(Intermediate)",
           "B2\n(Upper-Int.)", "C1\n(Advanced)", "C2\n(Proficient)"]
x       = np.arange(len(levels))

# Illustrative values derived from smoke experiment + Liang et al. literature trend
vanilla_fpr     = [0.00, 0.03, 0.08, 0.18, 0.38, 0.55]
fair_fpr        = [0.00, 0.02, 0.05, 0.10, 0.20, 0.32]
rfcd_fpr        = [0.00, 0.01, 0.04, 0.09, 0.17, 0.28]
commercial_fpr  = [0.02, 0.08, 0.18, 0.35, 0.52, 0.63]  # from Liang et al. [4]

fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(x, commercial_fpr, "s--", color=C["detectgpt"], lw=2,
        label="Commercial detector (Liang et al. [4])", markersize=8)
ax.plot(x, vanilla_fpr,    "o-",  color=C["vanilla"],  lw=2,
        label="Vanilla (ours, pilot)", markersize=7)
ax.plot(x, fair_fpr,       "^-",  color=C["fair"],     lw=2,
        label="Fairness-only (ours, pilot)", markersize=7)
ax.plot(x, rfcd_fpr,       "D-",  color=C["rfcd"],     lw=2.5,
        label="RFCD (ours, pilot)", markersize=7)
ax.axhline(0.05, color="grey", lw=1, ls=":", label="5% FPR target")
ax.fill_between(x, commercial_fpr, rfcd_fpr, alpha=0.08, color=C["rfcd"])
ax.set_xticks(x); ax.set_xticklabels(levels, fontsize=10)
ax.set_ylabel("False Positive Rate (ESL → flagged as AI)", fontsize=11)
ax.set_xlabel("ESL Writing Proficiency Level (CEFR)", fontsize=11)
ax.set_title("The Fluency Penalty: FPR rises with ESL proficiency\n"
             "(Illustrative / pilot-scale — full data ongoing)", fontsize=12)
ax.legend(fontsize=9); ax.grid(alpha=0.3); ax.set_ylim(-0.02, 0.72)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "fluency_penalty.png"), dpi=150)
plt.close(fig)
print("Saved: fluency_penalty.png")

# ════════════════════════════════════════════════════════════════════════════
# FIG 2 — FUA Curves Across Attack Strength
# ════════════════════════════════════════════════════════════════════════════
attack_labels = ["Clean", "Rule-based\n(ours)", "DIPPER\nlow", "DIPPER\nmid",
                 "DIPPER\nhigh", "GPT-4\nrewrite"]
xa = np.arange(len(attack_labels))

# FUA = |Δ_attacked − Δ_clean|; higher = fairness eroded more
fua_vanilla = [0.000, 0.067, 0.120, 0.175, 0.230, 0.310]
fua_fair    = [0.000, 0.044, 0.088, 0.130, 0.175, 0.250]
fua_robust  = [0.000, 0.044, 0.066, 0.095, 0.130, 0.210]
fua_rfcd    = [0.000, 0.044, 0.062, 0.088, 0.120, 0.185]

fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(xa, fua_vanilla, "o--", color=C["vanilla"],  lw=2, label="Vanilla")
ax.plot(xa, fua_fair,    "s-",  color=C["fair"],     lw=2, label="Fairness-only")
ax.plot(xa, fua_robust,  "^-",  color=C["robust"],   lw=2, label="Robustness-only")
ax.plot(xa, fua_rfcd,    "D-",  color=C["rfcd"],     lw=2.5, label="RFCD (ours)")
ax.axvline(1.5, color="grey", ls=":", lw=1.2, label="Seen in training (left) / unseen (right)")
ax.set_xticks(xa); ax.set_xticklabels(attack_labels, fontsize=10)
ax.set_ylabel("FUA — |FPR gap change under attack|", fontsize=11)
ax.set_xlabel("Attack Strength", fontsize=11)
ax.set_title("FUA Curves Across Attack Strength\n"
             "(Illustrative / pilot-scale — DIPPER & GPT-4 results planned)", fontsize=12)
ax.legend(fontsize=9); ax.grid(alpha=0.3); ax.set_ylim(-0.02, 0.38)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "fua_attack_strength.png"), dpi=150)
plt.close(fig)
print("Saved: fua_attack_strength.png")

# ════════════════════════════════════════════════════════════════════════════
# FIG 3 — 6-Detector Audit Heatmap: AUC × Attack condition × Group
# ════════════════════════════════════════════════════════════════════════════
detectors   = ["DetectGPT\n[10]", "Fast-Det.\n[12]", "Binoculars\n[11]",
               "RoBERTa\nbaseline", "Ghostbuster\n[lit.]", "RFCD\n(ours)"]
conditions  = ["Clean\nAUC", "Attacked\nAUC", "ESL FPR\n(clean)",
               "ESL FPR\n(attacked)", "FUA"]

# Illustrative values; lit. figures from papers + smoke-run for RFCD
data = np.array([
    # DetectGPT
    [0.950, 0.620, 0.18, 0.22, 0.040],
    # Fast-DetectGPT
    [0.960, 0.680, 0.15, 0.20, 0.050],
    # Binoculars
    [0.952, 0.710, 0.12, 0.17, 0.050],
    # RoBERTa baseline (vanilla fine-tune)
    [0.990, 0.650, 0.10, 0.15, 0.067],
    # Ghostbuster
    [0.940, 0.750, 0.08, 0.12, 0.040],
    # RFCD (ours, smoke)
    [0.984, 0.967, 0.00, 0.00, 0.044],
])

fig, ax = plt.subplots(figsize=(8, 5))
im = ax.imshow(data, cmap="RdYlGn", aspect="auto",
               vmin=0.0, vmax=1.0)
ax.set_xticks(range(len(conditions))); ax.set_xticklabels(conditions, fontsize=10)
ax.set_yticks(range(len(detectors)));  ax.set_yticklabels(detectors, fontsize=10)
for i in range(len(detectors)):
    for j in range(len(conditions)):
        v = data[i, j]
        ax.text(j, i, f"{v:.3f}", ha="center", va="center",
                fontsize=9, color="black" if 0.25 < v < 0.75 else "white")
plt.colorbar(im, ax=ax, label="Score (AUC / FPR / FUA)")
ax.set_title("6-Detector Fairness-Under-Attack Audit\n"
             "(Illustrative — lit. figures + pilot results; full audit ongoing)",
             fontsize=12)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "detector_audit_heatmap.png"), dpi=150)
plt.close(fig)
print("Saved: detector_audit_heatmap.png")

# ════════════════════════════════════════════════════════════════════════════
# FIG 4 — Threshold Sensitivity (FPR target 1%, 5%, 10%)
# ════════════════════════════════════════════════════════════════════════════
thresholds  = [0.01, 0.05, 0.10]
th_labels   = ["1% FPR\ntarget", "5% FPR\ntarget", "10% FPR\ntarget"]
# [vanilla_recall_clean, rfcd_recall_clean, vanilla_fua, rfcd_fua]
results = {
    0.01: dict(van_cl=0.756, rfc_cl=0.778, van_fua=0.089, rfc_fua=0.056),
    0.05: dict(van_cl=0.889, rfc_cl=0.844, van_fua=0.067, rfc_fua=0.044),
    0.10: dict(van_cl=0.933, rfc_cl=0.911, van_fua=0.044, rfc_fua=0.022),
}

xl = np.arange(3); w = 0.22
van_cl = [results[t]["van_cl"] for t in thresholds]
rfc_cl = [results[t]["rfc_cl"] for t in thresholds]
van_fu = [results[t]["van_fua"] for t in thresholds]
rfc_fu = [results[t]["rfc_fua"] for t in thresholds]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
ax1.bar(xl - w/2, van_cl, w, label="Vanilla", color=C["vanilla"], alpha=0.85)
ax1.bar(xl + w/2, rfc_cl, w, label="RFCD",    color=C["rfcd"],    alpha=0.85)
ax1.set_xticks(xl); ax1.set_xticklabels(th_labels)
ax1.set_ylabel("AI Recall (clean)"); ax1.set_title("Clean-Set Recall vs FPR Target")
ax1.legend(); ax1.grid(axis="y", alpha=0.3); ax1.set_ylim(0.6, 1.0)

ax2.bar(xl - w/2, van_fu, w, label="Vanilla", color=C["vanilla"], alpha=0.85)
ax2.bar(xl + w/2, rfc_fu, w, label="RFCD",    color=C["rfcd"],    alpha=0.85)
ax2.set_xticks(xl); ax2.set_xticklabels(th_labels)
ax2.set_ylabel("FUA (↓ lower = fairer under attack)")
ax2.set_title("FUA vs FPR Target\n(Illustrative / pilot-scale)")
ax2.legend(); ax2.grid(axis="y", alpha=0.3)
fig.suptitle("Threshold Sensitivity Analysis", fontsize=13, fontweight="bold")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "threshold_sensitivity.png"), dpi=150)
plt.close(fig)
print("Saved: threshold_sensitivity.png")

# ════════════════════════════════════════════════════════════════════════════
# FIG 5 — ESL-FUA Bench schematic
# ════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(10, 5))
ax.axis("off")
ax.set_xlim(0, 10); ax.set_ylim(0, 6)

def box(ax, x, y, w, h, label, sub, fc, ec):
    ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h,
        boxstyle="round,pad=0.1", fc=fc, ec=ec, lw=1.5))
    ax.text(x+w/2, y+h*0.65, label, ha="center", va="center",
            fontsize=9, fontweight="bold", color="black")
    ax.text(x+w/2, y+h*0.28, sub, ha="center", va="center",
            fontsize=8, color="#333333")

# Row 1: sources
box(ax,0.2,3.8,2.2,1.8,"PERSUADE 2.0","Student essays\nESL labels","#E3F2FD","#1565C0")
box(ax,2.7,3.8,2.2,1.8,"TOEFL11","11 L1s\nProf. levels","#E8F5E9","#2E7D32")
box(ax,5.2,3.8,2.2,1.8,"Native essays","Same prompts\nas PERSUADE","#FFF9C4","#F57F17")
box(ax,7.7,3.8,2.2,1.8,"LLM essays","GPT-4o,Claude,\nLlama,Qwen","#FCE4EC","#C62828")

# Row 2: middle step
box(ax,2.5,2.0,2.2,1.3,"AI-Polish class","ESL → Grammarly\n/ LLM rewrite","#F3E5F5","#6A1B9A")
box(ax,5.5,2.0,2.2,1.3,"Paraphrase\nAttacks","Rule, DIPPER,\nGPT-4 rewrite","#E0F7FA","#006064")

# Row 3: benchmark
box(ax,3.5,0.3,3.2,1.2,"ESL-FUA Bench","Open benchmark — 5 classes × 4 proficiency levels","#FFFDE7","#F57F17")

for src in [1.3, 3.8, 6.3, 8.8]:
    ax.annotate("", xy=(5.2 if src<5 else 5.2, 0.3+1.2),
                xytext=(src, 3.8),
                arrowprops=dict(arrowstyle="-|>", color="#555", lw=1.2))
ax.annotate("", xy=(5.2, 2.0), xytext=(4.0, 3.8),
            arrowprops=dict(arrowstyle="-|>", color="#6A1B9A", lw=1.2))
ax.annotate("", xy=(5.15, 0.3+1.2), xytext=(3.6, 2.0),
            arrowprops=dict(arrowstyle="-|>", color="#6A1B9A", lw=1.2))

ax.set_title("ESL-FUA Bench: Proposed Open Benchmark Construction",
             fontsize=12, fontweight="bold", pad=8)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "eslfua_bench_schematic.png"), dpi=150)
plt.close(fig)
print("Saved: eslfua_bench_schematic.png")

print("\nAll figures done.")
