"""
Monte-Carlo power analysis for the three registered hypotheses.
Runs real simulations and writes results/power_analysis.json.

H1: Jonckheere-Terpstra trend across 4 proficiency bands (one-sided).
H2: difference-in-differences on the FPR gap, human paraphrase (two-sided).
H3: essay-level paired bootstrap on per-essay FUA contribution (one-sided),
    with a secondary Wilcoxon test on fold×prompt aggregates.

Run: python scripts/run_power_analysis.py
"""
import json, os, math
import numpy as np
from scipy import stats

OUT = os.path.join(os.path.dirname(__file__), "..", "results", "power_analysis.json")
RNG = np.random.default_rng(20260925)
N_REP = 10000

# ── assumed rates (matched to the real design sizes) ────────────────────────
# Design: 1,000 ELL essays => 250 per proficiency band; 1,000 per group; all
# 1,000 essays scored via cross-fitting.
H1_FAMILIES   = 3
H1_ALPHA      = 0.05 / H1_FAMILIES         # Bonferroni across detector families
H1_N_PER_BAND = 250                        # 1,000 ELL / 4 bands
# Two effect profiles: primary (large) and a sensitivity check (smaller effect)
H1_BAND_FPR_PRIMARY = [0.02, 0.06, 0.12, 0.20]  # pilot floor rising toward Liang
H1_BAND_FPR_SMALL   = [0.03, 0.06, 0.10, 0.13]  # smaller monotone effect

# H2: FPR gap before/after human paraphrase (Route A)
H2_GAP_CLEAN   = -0.05    # learner favoured before attack
H2_GAP_ATTACK  =  0.03    # gap widens against learners after attack (|Δ| = 0.08)
H2_N_PER_GROUP = 1000     # all human essays per group scored via cross-fitting
H2_ALPHA       = 0.05 / H1_FAMILIES

# H3: per-essay FUA contribution; RFCD mean lower than baseline by the MDE
H3_MDE          = 0.05    # smallest FUA difference of interest
H3_SD           = 0.18    # per-essay FUA contribution SD (from pilot spread)
H3_N_ESSAYS     = 1000    # all test essays scored via cross-fitting
H3_ALPHA        = 0.05 / 2   # two RFCD-vs-baseline comparisons


def sim_h1(band_fpr):
    hits = 0
    for _ in range(N_REP):
        groups = []
        for fpr in band_fpr:
            groups.append(RNG.binomial(1, fpr, H1_N_PER_BAND))
        # Jonckheere-Terpstra via scipy (ordered alternative, one-sided)
        try:
            res = stats.jonckheere_terpstra_test  # not in older scipy
        except Exception:
            res = None
        # implement JT statistic manually (increasing alternative)
        stat = 0
        n_total = 0
        for i in range(len(groups)):
            for j in range(i + 1, len(groups)):
                a = groups[i][:, None]; b = groups[j][None, :]
                stat += np.sum(b > a) + 0.5 * np.sum(b == a)
                n_total += 1
        # normal approximation for JT under H0
        ns = [len(g) for g in groups]
        N = sum(ns)
        mean = (N**2 - sum(n*n for n in ns)) / 4.0
        var = (N**2 * (2*N + 3) - sum(n*n*(2*n+3) for n in ns)) / 72.0
        z = (stat - mean) / math.sqrt(var) if var > 0 else 0.0
        p = 1 - stats.norm.cdf(z)   # one-sided increasing
        if p < H1_ALPHA:
            hits += 1
    return hits / N_REP


def sim_h2():
    hits = 0
    reps = 3000   # fewer outer reps; nested bootstrap is expensive but stable
    for _ in range(reps):
        # native and learner human essays, clean and attacked
        # gap = FPR(learner) - FPR(native); model native fixed at 0.05
        fpr_nat_clean = 0.05
        fpr_ell_clean = fpr_nat_clean + H2_GAP_CLEAN
        fpr_nat_att   = 0.05
        fpr_ell_att   = fpr_nat_att + H2_GAP_ATTACK
        ell_clean = RNG.binomial(1, max(0,fpr_ell_clean), H2_N_PER_GROUP)
        nat_clean = RNG.binomial(1, fpr_nat_clean, H2_N_PER_GROUP)
        ell_att   = RNG.binomial(1, max(0,fpr_ell_att), H2_N_PER_GROUP)
        nat_att   = RNG.binomial(1, fpr_nat_att, H2_N_PER_GROUP)
        gap_clean = ell_clean.mean() - nat_clean.mean()
        gap_att   = ell_att.mean()   - nat_att.mean()
        dind = gap_att - gap_clean
        # bootstrap CI for difference-in-differences (two-sided)
        B = 400
        boot = np.empty(B)
        for b in range(B):
            i1 = RNG.integers(0, H2_N_PER_GROUP, H2_N_PER_GROUP)
            i2 = RNG.integers(0, H2_N_PER_GROUP, H2_N_PER_GROUP)
            i3 = RNG.integers(0, H2_N_PER_GROUP, H2_N_PER_GROUP)
            i4 = RNG.integers(0, H2_N_PER_GROUP, H2_N_PER_GROUP)
            gc = ell_clean[i1].mean() - nat_clean[i2].mean()
            ga = ell_att[i3].mean()   - nat_att[i4].mean()
            boot[b] = ga - gc
        lo, hi = np.percentile(boot, [2.5, 97.5])   # two-sided 95%
        if lo > 0 or hi < 0:
            hits += 1
    return hits / reps


def sim_h3():
    # essay-level paired bootstrap: per-essay FUA contribution,
    # RFCD mean lower than baseline by MDE
    hits = 0
    reps = 3000
    for _ in range(reps):
        diff = RNG.normal(H3_MDE, H3_SD, H3_N_ESSAYS)  # baseline - RFCD per essay
        B = 500
        means = np.empty(B)
        for b in range(B):
            idx = RNG.integers(0, H3_N_ESSAYS, H3_N_ESSAYS)
            means[b] = diff[idx].mean()
        lo = np.percentile(means, 100 * H3_ALPHA)   # one-sided lower bound
        if lo > 0:
            hits += 1
    return hits / reps


def main():
    print("Running H1 primary (0.02->0.20) ...")
    p1a = sim_h1(H1_BAND_FPR_PRIMARY)
    print(f"  H1 primary power = {p1a:.3f}")
    print("Running H1 sensitivity (0.03->0.13) ...")
    p1b = sim_h1(H1_BAND_FPR_SMALL)
    print(f"  H1 sensitivity power = {p1b:.3f}")
    print("Running H2 (difference-in-differences bootstrap, two-sided) ...")
    p2 = sim_h2()
    print(f"  H2 power = {p2:.3f}")
    print("Running H3 (essay-level paired bootstrap) ...")
    p3 = sim_h3()
    print(f"  H3 power = {p3:.3f}")

    out = {
        "n_replicates": N_REP,
        "H1_primary": {"test":"Jonckheere-Terpstra (one-sided, increasing)",
               "band_fpr":H1_BAND_FPR_PRIMARY, "n_per_band":H1_N_PER_BAND,
               "alpha":H1_ALPHA, "power":round(p1a,3)},
        "H1_sensitivity": {"test":"Jonckheere-Terpstra (one-sided, increasing)",
               "band_fpr":H1_BAND_FPR_SMALL, "n_per_band":H1_N_PER_BAND,
               "alpha":H1_ALPHA, "power":round(p1b,3)},
        "H2": {"test":"difference-in-differences on FPR gap, bootstrap 95% CI (two-sided)",
               "gap_clean":H2_GAP_CLEAN, "gap_attacked":H2_GAP_ATTACK,
               "n_per_group":H2_N_PER_GROUP, "alpha":H2_ALPHA, "power":round(p2,3)},
        "H3": {"test":"essay-level paired bootstrap (one-sided); Wilcoxon secondary",
               "mde":H3_MDE, "per_essay_sd":H3_SD, "n_essays":H3_N_ESSAYS,
               "alpha":H3_ALPHA, "power":round(p3,3)},
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f: json.dump(out, f, indent=2)
    print(f"\nSaved {OUT}")


if __name__ == "__main__":
    main()
