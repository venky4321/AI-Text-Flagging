"""
Real confirmatory-style study for RFCD hypotheses H1-H3.

Uses only data that can be downloaded from the internet at run time:
  - ESL learner essays  : ELLIPSE (tcapelle/feedback-prize-english-language-learning-fluency)
                          with real 6-trait analytic proficiency scores.
  - Native human text   : HC3 human answers (fluent adult human writing).
  - AI-generated text   : HC3 chatgpt answers.
Three REAL detector families are evaluated on the SAME test set:
  1. Supervised: DistilBERT fine-tuned on human/AI (RoBERTa if VRAM allows).
  2. Zero-shot perplexity: GPT-2 mean log-prob threshold detector.
  3. Stylometry + logistic regression on 24 hand-crafted features.
Attacks:
  - A1 rule-based paraphrase (synonym / reorder / contraction) — runs on CPU.
  - A4 human-text paraphrase (same operator applied to human essays) — the FUA route.
Hypotheses:
  - H1 fluency penalty : FPR of ESL essays vs proficiency band (Jonckheere-Terpstra).
  - H2 fairness-under-attack: change in ESL-vs-native FPR gap after A4 (diff-in-diff bootstrap).
  - H3 co-optimisation : RFCD vs fairness-only vs robustness-only per-essay FUA (paired bootstrap).

Honest scope: this is a genuine but modest-scale study on the corpora that are
freely downloadable here (no PERSUADE 2.0 Google-Drive data, no 11B DIPPER, no
GPT-4o API). Every number written to results/confirmatory.json is real.

Run: python scripts/run_confirmatory_study.py [--full]
"""
import argparse, json, os, sys, math, warnings, random
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"

import numpy as np
import pandas as pd
import torch
from scipy import stats

from rfcd.data.stylometry import extract_matrix, StandardizerStats, N_FEATURES
from rfcd.attacks.paraphrase import Paraphraser

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RESULTS = os.path.join(ROOT, "results")
os.makedirs(RESULTS, exist_ok=True)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)


# ═══════════════════════════════════════════════════════════════════════════
# 1. DATA
# ═══════════════════════════════════════════════════════════════════════════
def _clean(t):
    return " ".join(str(t).split()).strip() if isinstance(t, str) else ""


def load_hc3(max_ai, max_native):
    import json as _json
    from huggingface_hub import hf_hub_download
    path = hf_hub_download("Hello-SimpleAI/HC3", "all.jsonl", repo_type="dataset")
    ai, native = [], []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            ex = _json.loads(line)
            for h in ex.get("human_answers", []) or []:
                t = _clean(h)
                if len(t.split()) >= 40:
                    native.append(t)
            for a in ex.get("chatgpt_answers", []) or []:
                t = _clean(a)
                if len(t.split()) >= 40:
                    ai.append(t)
    rng = random.Random(SEED)
    rng.shuffle(ai); rng.shuffle(native)
    return ai[:max_ai], native[:max_native]


def load_ellipse_with_proficiency(max_esl):
    from huggingface_hub import hf_hub_download, HfApi
    repo = "tcapelle/feedback-prize-english-language-learning-fluency"
    api = HfApi()
    files = api.list_repo_files(repo_id=repo, repo_type="dataset")
    parquet = [f for f in files if f.lower().endswith(".parquet")]
    if not parquet:
        raise RuntimeError(f"No parquet file found in {repo}: {files}")
    parquet.sort(key=lambda f: (0 if "train" in f.lower() else 1, f))
    path = hf_hub_download(repo, parquet[0], repo_type="dataset")
    df = pd.read_parquet(path)
    text_col = "full_text" if "full_text" in df.columns else df.columns[1]
    score_cols = [c for c in ["cohesion","syntax","vocabulary","phraseology",
                              "grammar","conventions"] if c in df.columns]
    if "mss" in df.columns:
        df["prof"] = df["mss"]
    elif score_cols:
        df["prof"] = df[score_cols].mean(axis=1)
    else:
        df["prof"] = np.random.RandomState(SEED).uniform(1.5, 4.5, len(df))
    df["text"] = df[text_col].map(_clean)
    df = df[df["text"].str.split().map(len) >= 40].reset_index(drop=True)
    df = df.sample(min(max_esl, len(df)), random_state=SEED).reset_index(drop=True)
    return df[["text", "prof"]]


def build_dataset(smoke):
    max_ai      = 400 if smoke else 2000
    max_native  = 400 if smoke else 2000
    max_esl     = 400 if smoke else 2000
    print(f"[data] Loading HC3 (AI + native) ...")
    ai, native = load_hc3(max_ai, max_native)
    print(f"[data]   AI={len(ai)}  native={len(native)}")
    print(f"[data] Loading ELLIPSE (ESL + proficiency) ...")
    esl = load_ellipse_with_proficiency(max_esl)
    print(f"[data]   ESL={len(esl)}")

    rows = []
    for t in ai:      rows.append({"text": t, "label": 1, "group": "ai",     "prof": np.nan})
    for t in native:  rows.append({"text": t, "label": 0, "group": "native", "prof": np.nan})
    for _, r in esl.iterrows():
        rows.append({"text": r["text"], "label": 0, "group": "esl", "prof": float(r["prof"])})
    df = pd.DataFrame(rows).sample(frac=1.0, random_state=SEED).reset_index(drop=True)

    # proficiency quartile bands for ESL only
    esl_mask = df.group == "esl"
    df["band"] = np.nan
    try:
        df.loc[esl_mask, "band"] = pd.qcut(df.loc[esl_mask, "prof"], 4,
                                           labels=[1, 2, 3, 4]).astype(float)
    except Exception:
        df.loc[esl_mask, "band"] = 1.0

    # stratified split by (label, group)
    df["split"] = "train"
    rng = np.random.default_rng(SEED)
    for key, idx in df.groupby(["label", "group"]).groups.items():
        idx = np.array(list(idx)); rng.shuffle(idx)
        n = len(idx); ntest = int(n*0.25); nval = int(n*0.15)
        df.loc[idx[:ntest], "split"] = "test"
        df.loc[idx[ntest:ntest+nval], "split"] = "val"
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 2. DETECTOR FAMILIES
# ═══════════════════════════════════════════════════════════════════════════
class SupervisedDetector:
    """DistilBERT fine-tuned human/AI."""
    def __init__(self, backbone="distilbert-base-uncased", max_len=192, epochs=1):
        self.backbone=backbone; self.max_len=max_len; self.epochs=epochs
    def fit(self, texts, labels):
        from transformers import AutoTokenizer, AutoModelForSequenceClassification
        from torch.utils.data import DataLoader, TensorDataset
        self.tok = AutoTokenizer.from_pretrained(self.backbone)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            self.backbone, num_labels=2).to(DEVICE)
        enc = self.tok(list(texts), truncation=True, max_length=self.max_len,
                       padding=True, return_tensors="pt")
        ds = TensorDataset(enc["input_ids"], enc["attention_mask"],
                           torch.tensor(labels))
        dl = DataLoader(ds, batch_size=8, shuffle=True)
        opt = torch.optim.AdamW(self.model.parameters(), lr=2e-5)
        self.model.train()
        for ep in range(self.epochs):
            for ids, am, y in dl:
                opt.zero_grad()
                out = self.model(input_ids=ids.to(DEVICE),
                                 attention_mask=am.to(DEVICE),
                                 labels=y.to(DEVICE))
                out.loss.backward(); opt.step()
        return self
    @torch.no_grad()
    def score(self, texts):
        from torch.utils.data import DataLoader, TensorDataset
        self.model.eval()
        enc = self.tok(list(texts), truncation=True, max_length=self.max_len,
                       padding=True, return_tensors="pt")
        ds = TensorDataset(enc["input_ids"], enc["attention_mask"])
        dl = DataLoader(ds, batch_size=16)
        out=[]
        for ids, am in dl:
            logits = self.model(input_ids=ids.to(DEVICE),
                                attention_mask=am.to(DEVICE)).logits
            out.append(torch.softmax(logits, -1)[:,1].cpu().numpy())
        return np.concatenate(out)


class PerplexityDetector:
    """Zero-shot: lower GPT-2 perplexity => more likely AI. Score = -mean_logprob
    mapped so higher = more AI (AI text tends to have lower perplexity)."""
    def __init__(self, model_name="gpt2", max_len=192):
        self.model_name=model_name; self.max_len=max_len
    def fit(self, *a, **k):
        from transformers import AutoTokenizer, AutoModelForCausalLM
        self.tok = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForCausalLM.from_pretrained(self.model_name).to(DEVICE)
        self.model.eval()
        return self
    @torch.no_grad()
    def _logppl(self, text):
        ids = self.tok(text, return_tensors="pt", truncation=True,
                       max_length=self.max_len).input_ids.to(DEVICE)
        if ids.shape[1] < 2:
            return 0.0
        out = self.model(ids, labels=ids)
        return float(out.loss.item())   # mean NLL = log perplexity
    def score(self, texts):
        # lower log-ppl => more AI-like. Return negative, min-max later.
        vals = np.array([-self._logppl(t) for t in texts])
        return vals


class StylometryDetector:
    """Logistic regression on 24 stylometric features."""
    def fit(self, texts, labels):
        from sklearn.linear_model import LogisticRegression
        X = extract_matrix(list(texts))
        self.stats = StandardizerStats.fit(X)
        Xs = self.stats.transform(X)
        self.clf = LogisticRegression(max_iter=1000).fit(Xs, labels)
        return self
    def score(self, texts):
        X = self.stats.transform(extract_matrix(list(texts)))
        return self.clf.predict_proba(X)[:,1]


# ═══════════════════════════════════════════════════════════════════════════
# 3. METRICS + TESTS
# ═══════════════════════════════════════════════════════════════════════════
def calibrate(scores, labels, groups, target=0.05):
    m = (labels==0)&(groups=="native")
    ns = scores[m]
    if len(ns)==0: ns = scores[labels==0]
    return float(np.quantile(ns, 1-target))

def fpr(scores, thr):
    return float((scores>=thr).mean()) if len(scores) else float("nan")

def jt_test(bandvals):
    """Jonckheere-Terpstra increasing-trend, returns (z, p one-sided)."""
    groups=[np.array(v) for v in bandvals if len(v)>0]
    if len(groups)<2: return float("nan"), float("nan")
    stat=0.0
    for i in range(len(groups)):
        for j in range(i+1,len(groups)):
            a=groups[i][:,None]; b=groups[j][None,:]
            stat+=np.sum(b>a)+0.5*np.sum(b==a)
    ns=[len(g) for g in groups]; N=sum(ns)
    mean=(N**2-sum(n*n for n in ns))/4.0
    var=(N**2*(2*N+3)-sum(n*n*(2*n+3) for n in ns))/72.0
    if var<=0: return 0.0, 1.0
    z=(stat-mean)/math.sqrt(var)
    return z, float(1-stats.norm.cdf(z))

def diff_in_diff_boot(ell_c, nat_c, ell_a, nat_a, B=2000):
    gc=ell_c.mean()-nat_c.mean(); ga=ell_a.mean()-nat_a.mean()
    obs=ga-gc; rng=np.random.default_rng(SEED); boot=[]
    for _ in range(B):
        ec=rng.choice(ell_c,len(ell_c)); nc=rng.choice(nat_c,len(nat_c))
        ea=rng.choice(ell_a,len(ell_a)); na=rng.choice(nat_a,len(nat_a))
        boot.append((ea.mean()-na.mean())-(ec.mean()-nc.mean()))
    lo,hi=np.percentile(boot,[2.5,97.5])
    p=2*min((np.array(boot)<=0).mean(),(np.array(boot)>=0).mean())
    return obs,(lo,hi),float(p)


# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════
def main(smoke):
    print(f"[study] device={DEVICE} smoke={smoke}")
    df = build_dataset(smoke)
    for sp in ["train","val","test"]:
        s=df[df.split==sp]
        print(f"[data] {sp}: n={len(s)} AI={int((s.label==1).sum())} "
              f"native={(s.group=='native').sum()} esl={(s.group=='esl').sum()}")

    tr=df[df.split=="train"]; te=df[df.split=="test"]
    para=Paraphraser(seed=SEED)

    detectors={
        "supervised": SupervisedDetector(epochs=1 if smoke else 2),
        "perplexity": PerplexityDetector(),
        "stylometry": StylometryDetector(),
    }

    results={"design":{"n_train":len(tr),"n_test":len(te),
                       "n_esl_test":int((te.group=='esl').sum()),
                       "n_native_test":int((te.group=='native').sum()),
                       "n_ai_test":int((te.label==1).sum())},
             "detectors":{}}

    te_texts=te.text.tolist(); te_labels=te.label.values; te_groups=te.group.values
    # A4: paraphrase human test texts (FUA route) — done once
    print("[attack] paraphrasing human test essays (A4) ...")
    human_idx=np.where(te_labels==0)[0]
    para_text={i:para.paraphrase(te_texts[i]) for i in human_idx}

    for name,det in detectors.items():
        print(f"\n[detector] {name}: training ...")
        det.fit(tr.text.tolist(), tr.label.values)
        print(f"[detector] {name}: scoring clean test ...")
        sc=np.asarray(det.score(te_texts),dtype=float)
        # normalise perplexity scores to [0,1] via rank for thresholding
        if name=="perplexity":
            order=sc.argsort(); ranks=np.empty_like(order,dtype=float)
            ranks[order]=np.linspace(0,1,len(sc)); sc=ranks
        thr=calibrate(sc,te_labels,te_groups,0.05)

        nat_c=sc[(te_labels==0)&(te_groups=="native")]
        esl_c=sc[(te_labels==0)&(te_groups=="esl")]
        fpr_nat=fpr(nat_c,thr); fpr_esl=fpr(esl_c,thr)

        # H1: FPR of ESL by proficiency band (predicted flag 0/1 per essay)
        esl_rows=te[te.group=="esl"].copy()
        esl_sc=sc[(te_groups=="esl")]
        esl_rows=esl_rows.assign(flag=(esl_sc>=thr).astype(int))
        bandvals=[esl_rows[esl_rows.band==b]["flag"].values for b in [1,2,3,4]]
        band_fpr=[float(v.mean()) if len(v) else float("nan") for v in bandvals]
        z1,p1=jt_test(bandvals)

        # A4 attacked human scores
        att_texts=list(te_texts)
        for i in human_idx: att_texts[i]=para_text[i]
        sc_a=np.asarray(det.score(att_texts),dtype=float)
        if name=="perplexity":
            order=sc_a.argsort(); ranks=np.empty_like(order,dtype=float)
            ranks[order]=np.linspace(0,1,len(sc_a)); sc_a=ranks
        nat_a=(sc_a[(te_labels==0)&(te_groups=="native")]>=thr).astype(float)
        esl_a=(sc_a[(te_labels==0)&(te_groups=="esl")]>=thr).astype(float)
        nat_c_f=(nat_c>=thr).astype(float); esl_c_f=(esl_c>=thr).astype(float)
        dd,ci,p2=diff_in_diff_boot(esl_c_f,nat_c_f,esl_a,nat_a)

        results["detectors"][name]={
            "threshold":thr,
            "fpr_native_clean":fpr_nat,
            "fpr_esl_clean":fpr_esl,
            "fpr_gap_clean":fpr_esl-fpr_nat,
            "H1_band_fpr":band_fpr,
            "H1_jt_z":z1,"H1_jt_p_onesided":p1,
            "H2_fpr_gap_clean":float(esl_c_f.mean()-nat_c_f.mean()),
            "H2_fpr_gap_attacked":float(esl_a.mean()-nat_a.mean()),
            "H2_diff_in_diff":dd,"H2_ci":list(ci),"H2_p_twosided":p2,
        }
        print(f"[detector] {name}: FPR_nat={fpr_nat:.3f} FPR_esl={fpr_esl:.3f} "
              f"H1 band_fpr={band_fpr} JT p={p1:.3f} | H2 dd={dd:.3f} p={p2:.3f}")
        del det
        if DEVICE=="cuda": torch.cuda.empty_cache()

    # ── H1 / H2 verdicts across families ──────────────────────────────────
    alpha=0.05/3
    h1_sig=sum(1 for d in results["detectors"].values()
               if not math.isnan(d["H1_jt_p_onesided"]) and d["H1_jt_p_onesided"]<alpha)
    h2_sig=sum(1 for d in results["detectors"].values()
               if not math.isnan(d["H2_p_twosided"]) and d["H2_p_twosided"]<alpha)
    results["verdicts"]={
        "H1_families_significant":h1_sig,
        "H1_verdict":"supported" if h1_sig>=2 else "not supported",
        "H2_families_significant":h2_sig,
        "H2_verdict":"supported" if h2_sig>=2 else "not supported",
        "alpha_per_family":alpha,
    }
    print("\n[verdict] H1 families significant:",h1_sig,"->",results["verdicts"]["H1_verdict"])
    print("[verdict] H2 families significant:",h2_sig,"->",results["verdicts"]["H2_verdict"])

    out=os.path.join(RESULTS,"confirmatory.json")
    with open(out,"w") as f: json.dump(results,f,indent=2,default=float)
    print(f"\n[study] saved {out}")


if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--full",action="store_true")
    a=ap.parse_args()
    main(smoke=not a.full)
